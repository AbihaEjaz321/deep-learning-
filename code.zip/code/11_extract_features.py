"""
Step 11: cache frozen ImageNet-pretrained encoder token maps for every candidate slice.

For each patient, view (detail / context) and modality (CT 2-channel windows, PET 2-channel SUV) we store
  feat/<pid>/<view>_<mod>.npy  float16 (n_slices, n_versions, 49, C)   C = 1280 for EfficientNet-B0
version 0 = canonical evaluation crop, 1 = horizontally flipped, 2.. = random training-style augmentations.
Training the fusion / MIL head on these features takes seconds, so hyper-parameters can be chosen on the
inner folds without over-fitting the backbones to 284 training patients.

  python 11_extract_features.py --n_aug 6 --backbone tf_efficientnet_b0.ns_jft_in1k
"""
import argparse
import json
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

from common import BagDataset, load_cohort, Encoder, HERE, VIEWS, _view_rels

FEAT = HERE / "feat"


class _AugSampler(BagDataset):
    """Reuses BagDataset's crop/augmentation code to produce fixed sets of versions per slice."""
    def versions(self, rec, k, view, n_aug):
        outs = []
        for v in range(2 + n_aug):
            if v == 0:
                (rel, dx, dy), angle, flip, gamma, gain = _view_rels(view, False, self.rng), 0.0, False, 1.0, 1.0
            elif v == 1:
                (rel, dx, dy), angle, flip, gamma, gain = _view_rels(view, False, self.rng), 0.0, True, 1.0, 1.0
            else:
                rel, dx, dy = _view_rels(view, True, self.rng)
                angle = self.rng.uniform(-10, 10) if self.rng.random() < 0.6 else 0.0
                flip = self.rng.random() < 0.5
                gamma = self.rng.uniform(0.85, 1.15) if self.rng.random() < 0.3 else 1.0
                gain = self.rng.uniform(0.85, 1.15) if self.rng.random() < 0.3 else 1.0
            outs.append(self._one_view(rec, k, view, rel, dx, dy, angle, flip, gamma, gain))
        return outs


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--backbone", default="tf_efficientnet_b0.ns_jft_in1k")
    ap.add_argument("--tag", default="b0")
    ap.add_argument("--n_aug", type=int, default=6)
    ap.add_argument("--pool", type=int, default=7, help="spatial token grid kept (7 = full 7x7, 4 = 4x4 adaptive pool)")
    ap.add_argument("--pids", nargs="*", default=None)
    ap.add_argument("--batch", type=int, default=96)
    ap.add_argument("--views", nargs="*", default=["detail", "context", "whole"])
    args = ap.parse_args()
    device = torch.device("cuda")
    out_root = FEAT / args.tag; out_root.mkdir(parents=True, exist_ok=True)
    is_vit = "vit" in args.backbone or "dino" in args.backbone
    if is_vit:
        import timm

        class _ViTEnc(torch.nn.Module):
            def __init__(self):
                super().__init__()
                self.net = timm.create_model(args.backbone, pretrained=True, in_chans=2, num_classes=0, img_size=224)
                self.out_dim = self.net.num_features
        enc_ct = _ViTEnc().to(device).eval(); enc_pt = _ViTEnc().to(device).eval()
    else:
        enc_ct = Encoder(args.backbone, 2, pretrained=True, drop_path=0.0).to(device).eval()
        enc_pt = Encoder(args.backbone, 2, pretrained=True, drop_path=0.0).to(device).eval()
    recs = load_cohort(args.pids, verbose=True)
    sampler = _AugSampler(recs, train=True, seed=1234)
    t0 = time.time()
    meta = {"backbone": args.backbone, "n_versions": 2 + args.n_aug, "pool": args.pool, "dim": enc_ct.out_dim}
    json.dump(meta, open(out_root / "meta.json", "w"), indent=1)

    @torch.no_grad()
    def run(enc, x):
        outs = []
        for i in range(0, len(x), args.batch):
            xb = torch.from_numpy(np.stack(x[i:i + args.batch])).to(device)
            with torch.autocast("cuda", dtype=torch.bfloat16):
                f = enc.net.forward_features(xb)
                if f.dim() == 3:                                    # ViT: (b, prefix + h*w, C) -> (b, C, h, w)
                    n_prefix = getattr(enc.net, "num_prefix_tokens", 1)
                    f = f[:, n_prefix:]; s = int(round(f.shape[1] ** 0.5))
                    f = f.transpose(1, 2).reshape(f.shape[0], f.shape[2], s, s)
                if args.pool != f.shape[-1]:
                    f = F.adaptive_avg_pool2d(f, args.pool)
                f = f.flatten(2).transpose(1, 2)                   # (b, T, C)
            outs.append(f.float().cpu().numpy().astype(np.float16))
        return np.concatenate(outs)

    for n, rec in enumerate(recs):
        pdir = out_root / rec.pid; pdir.mkdir(exist_ok=True)
        todo = [v for v in args.views if not ((pdir / f"{v}_ct.npy").exists() and (not rec.has_pet or (pdir / f"{v}_pt.npy").exists()))]
        if not todo:
            continue
        for view in todo:
            ct_imgs, pt_imgs = [], []
            for k in range(rec.n_slices):
                for c, p in sampler.versions(rec, k, view, args.n_aug):
                    ct_imgs.append(c); pt_imgs.append(p)
            nv = 2 + args.n_aug
            f_ct = run(enc_ct, ct_imgs).reshape(rec.n_slices, nv, -1, enc_ct.out_dim)
            np.save(pdir / f"{view}_ct.npy", f_ct)
            if rec.has_pet:
                f_pt = run(enc_pt, pt_imgs).reshape(rec.n_slices, nv, -1, enc_pt.out_dim)
                np.save(pdir / f"{view}_pt.npy", f_pt)
        if (n + 1) % 25 == 0:
            print(f"  {n + 1}/{len(recs)} patients ({time.time() - t0:.0f}s)", flush=True)
    print(f"done in {time.time() - t0:.0f}s -> {out_root}")


if __name__ == "__main__":
    main()
