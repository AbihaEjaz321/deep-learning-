"""
Step 9: compile all evaluated experiments into one comparison table (docs/results_summary.csv / .md).
Runs 05_evaluate for any experiment that has predictions but no eval/metrics.json yet.
"""
import json
import subprocess
import sys
from pathlib import Path

import pandas as pd

HERE = Path(__file__).resolve().parent
RESULTS = HERE / "results"; DOCS = HERE / "docs"; DOCS.mkdir(exist_ok=True)

names = [p.name for p in sorted(RESULTS.iterdir()) if (p / "oof_predictions.csv").exists() and not p.name.startswith("debug")]
missing = [n for n in names if not (RESULTS / n / "eval" / "metrics.json").exists()]
if missing:
    subprocess.run([sys.executable, str(HERE / "05_evaluate.py"), "--names", *missing], check=False)

rows = []
for n in names:
    mp = RESULTS / n / "eval" / "metrics.json"
    if not mp.exists():
        continue
    m = json.load(open(mp, encoding="utf-8"))
    cfg = json.load(open(RESULTS / n / "folds.json", encoding="utf-8"))["config"]
    oy = m["operating_points"].get("thr_youden", {}); os80 = m["operating_points"].get("thr_sens80", {})
    f = lambda d, k: f"{d[k]['value']:.3f} ({d[k]['ci'][0]:.2f}-{d[k]['ci'][1]:.2f})" if k in d else ""
    rows.append({
        "experiment": n, "fusion": cfg["fusion"], "cohort": cfg["cohort"] + (f" LOMO={cfg['lomo']}" if cfg.get("lomo") else ""),
        "loss": cfg["loss"], "n_patients": m["n_patients"], "n_SCLC": m["n_sclc"], "repeats": m["n_repeats"],
        "AUC (DeLong 95% CI)": f"{m['auc']['value']:.3f} ({m['auc']['delong_ci'][0]:.2f}-{m['auc']['delong_ci'][1]:.2f})",
        "AUPRC": f"{m['auprc']['value']:.3f} ({m['auprc']['bootstrap_ci'][0]:.2f}-{m['auprc']['bootstrap_ci'][1]:.2f})",
        "Sens@Youden": f(oy, "sensitivity"), "Spec@Youden": f(oy, "specificity"), "BACC@Youden": f(oy, "balanced_accuracy"),
        "Acc@Youden": f(oy, "accuracy"), "MacroF1@Youden": f(oy, "macro_f1"), "PPV@Youden": f(oy, "ppv"), "NPV@Youden": f(oy, "npv"),
        "Sens@sens80": f(os80, "sensitivity"), "Spec@sens80": f(os80, "specificity"), "BACC@sens80": f(os80, "balanced_accuracy"),
        "Brier": f"{m['calibration']['brier']['value']:.3f} ({m['calibration']['brier']['ci'][0]:.3f}-{m['calibration']['brier']['ci'][1]:.3f})",
        "Cal. slope": f"{m['calibration']['calibration_slope']['value']:.2f} ({m['calibration']['calibration_slope']['ci'][0]:.2f}-{m['calibration']['calibration_slope']['ci'][1]:.2f})",
        "Cal. intercept": f"{m['calibration']['calibration_intercept']['value']:.2f} ({m['calibration']['calibration_intercept']['ci'][0]:.2f}-{m['calibration']['calibration_intercept']['ci'][1]:.2f})",
        "fold AUC mean±SD": f"{m['per_fold_mean_sd']['auc'][0]:.3f}±{m['per_fold_mean_sd']['auc'][1]:.3f}",
        "fold BACC mean±SD": f"{m['per_fold_mean_sd']['balanced_accuracy'][0]:.3f}±{m['per_fold_mean_sd']['balanced_accuracy'][1]:.3f}",
        "confusion@Youden (tn,fp,fn,tp)": str(tuple(oy.get("confusion", {}).get(k, "") for k in ["tn", "fp", "fn", "tp"])),
    })
df = pd.DataFrame(rows)
df.to_csv(DOCS / "results_summary.csv", index=False)
with open(DOCS / "results_summary.md", "w", encoding="utf-8") as fh:
    cols = list(df.columns)
    fh.write("| " + " | ".join(cols) + " |\n|" + "---|" * len(cols) + "\n")
    for _, r in df.iterrows():
        fh.write("| " + " | ".join(str(r[c]) for c in cols) + " |\n")
pd.set_option("display.width", 250); pd.set_option("display.max_columns", 40)
print(df[["experiment", "n_patients", "n_SCLC", "AUC (DeLong 95% CI)", "Sens@Youden", "Spec@Youden", "BACC@Youden", "MacroF1@Youden", "Sens@sens80", "Spec@sens80", "Brier", "Cal. slope"]].to_string(index=False))
