"""
Step 5: evaluate pooled out-of-fold predictions of one or more experiments.

  python 05_evaluate.py --names proposed_all ct_only_all            # metrics + figures per experiment
  python 05_evaluate.py --compare proposed_all ct_only_all          # paired DeLong test + bootstrap differences

Outputs per experiment (results/<name>/eval/):
  metrics.json, metrics_table.csv, per_fold.csv, roc.png, pr.png, calibration.png, dca.png, confusion.png
All CIs are 95% percentile intervals from 2000 patient-level (cluster) bootstrap resamples unless stated;
AUC additionally gets a DeLong CI.
"""
import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy import stats
from sklearn.metrics import (roc_auc_score, average_precision_score, roc_curve, precision_recall_curve, brier_score_loss,
                             confusion_matrix, matthews_corrcoef, f1_score)
from sklearn.linear_model import LogisticRegression

HERE = Path(__file__).resolve().parent
RESULTS = HERE / "results"
N_BOOT = 1000
RNG = np.random.default_rng(2026)


# ------------------------------------------------------------------ DeLong (Sun & Xu 2014)
def _compute_midrank(x):
    J = np.argsort(x); Z = x[J]; N = len(x); T = np.zeros(N, dtype=float); i = 0
    while i < N:
        j = i
        while j < N and Z[j] == Z[i]:
            j += 1
        T[i:j] = 0.5 * (i + j - 1)
        i = j
    T2 = np.empty(N, dtype=float); T2[J] = T + 1
    return T2


def delong_auc_var(y, s):
    y = np.asarray(y).astype(int); s = np.asarray(s, float)
    pos = s[y == 1]; neg = s[y == 0]; m = len(pos); n = len(neg)
    allx = np.concatenate([pos, neg])
    tx = _compute_midrank(pos); ty = _compute_midrank(neg); tz = _compute_midrank(allx)
    auc = (tz[:m].sum() - m * (m + 1) / 2.0) / (m * n)
    v01 = (tz[:m] - tx) / n; v10 = 1.0 - (tz[m:] - ty) / m
    var = np.var(v01, ddof=1) / m + np.var(v10, ddof=1) / n
    return auc, var, v01, v10


def delong_ci(y, s, alpha=0.95):
    auc, var, _, _ = delong_auc_var(y, s)
    se = np.sqrt(var); z = stats.norm.ppf(0.5 + alpha / 2)
    return auc, max(0.0, auc - z * se), min(1.0, auc + z * se), se


def delong_paired_test(y, s1, s2):
    auc1, var1, a01, a10 = delong_auc_var(y, s1)
    auc2, var2, b01, b10 = delong_auc_var(y, s2)
    m = len(a01); n = len(a10)
    cov = np.cov(a01, b01, ddof=1)[0, 1] / m + np.cov(a10, b10, ddof=1)[0, 1] / n
    var = var1 + var2 - 2 * cov
    z = (auc1 - auc2) / np.sqrt(max(var, 1e-12))
    p = 2 * (1 - stats.norm.cdf(abs(z)))
    return auc1, auc2, auc1 - auc2, z, p


# ------------------------------------------------------------------ metrics
def binary_metrics(y, p, thr):
    y = np.asarray(y).astype(int); pred = (np.asarray(p) >= np.asarray(thr)).astype(int)
    tp = int(np.sum((pred == 1) & (y == 1))); fn = int(np.sum((pred == 0) & (y == 1)))
    tn = int(np.sum((pred == 0) & (y == 0))); fp = int(np.sum((pred == 1) & (y == 0)))
    sens = tp / max(tp + fn, 1); spec = tn / max(tn + fp, 1)
    ppv = tp / max(tp + fp, 1); npv = tn / max(tn + fn, 1)
    f1_pos = 2 * tp / max(2 * tp + fp + fn, 1); f1_neg = 2 * tn / max(2 * tn + fn + fp, 1)
    denom = np.sqrt(float(tp + fp) * (tp + fn) * (tn + fp) * (tn + fn))
    mcc = ((tp * tn - fp * fn) / denom) if denom > 0 else 0.0
    return {"sensitivity": sens, "specificity": spec, "ppv": ppv, "npv": npv,
            "accuracy": (tp + tn) / len(y), "balanced_accuracy": (sens + spec) / 2,
            "f1_sclc": f1_pos, "macro_f1": (f1_pos + f1_neg) / 2, "mcc": mcc,
            "tp": tp, "fp": fp, "tn": tn, "fn": fn}


def calibration_metrics(y, p):
    y = np.asarray(y).astype(int); p = np.clip(np.asarray(p, float), 1e-6, 1 - 1e-6)
    logit = np.log(p / (1 - p))
    lr = LogisticRegression(C=1e6, solver="lbfgs", max_iter=1000).fit(logit.reshape(-1, 1), y)
    slope = float(lr.coef_[0][0])
    # calibration-in-the-large: intercept of logit(y) ~ offset(logit) + a
    a = 0.0
    for _ in range(100):      # Newton steps for the offset model
        q = 1 / (1 + np.exp(-(logit + a)))
        g = np.sum(y - q); h = -np.sum(q * (1 - q))
        if abs(h) < 1e-12:
            break
        step = g / h; a -= step
        if abs(step) < 1e-10:
            break
    bins = np.quantile(p, np.linspace(0, 1, 11)); bins[0] = 0; bins[-1] = 1
    idx = np.clip(np.digitize(p, bins[1:-1]), 0, 9)
    ece = 0.0
    for b in range(10):
        m = idx == b
        if m.any():
            ece += m.mean() * abs(p[m].mean() - y[m].mean())
    return {"brier": float(brier_score_loss(y, p)), "calibration_slope": slope, "calibration_intercept": float(a), "ece_10bin": float(ece)}


def net_benefit(y, p, pts):
    y = np.asarray(y).astype(int); p = np.asarray(p, float); N = len(y); prev = y.mean()
    nb_model, nb_all = [], []
    for t in pts:
        pred = p >= t
        tp = np.sum(pred & (y == 1)); fp = np.sum(pred & (y == 0))
        nb_model.append(tp / N - fp / N * t / (1 - t))
        nb_all.append(prev - (1 - prev) * t / (1 - t))
    return np.array(nb_model), np.array(nb_all)


def cluster_bootstrap(df, fn, n_boot=N_BOOT, seed=2026):
    """Resample patients (all repeat rows of a patient move together); return percentile CI of fn(df).
    Array-based for speed: fn receives a DataFrame built from integer row indices."""
    rng = np.random.default_rng(seed)
    df = df.reset_index(drop=True)
    codes, uniq = pd.factorize(df["pid"])
    rows_by_pid = [np.flatnonzero(codes == i) for i in range(len(uniq))]
    labels = df["label"].values
    vals = []
    for _ in range(n_boot):
        samp = rng.integers(0, len(uniq), len(uniq))
        idx = np.concatenate([rows_by_pid[s] for s in samp])
        if labels[idx].min() == labels[idx].max():
            continue
        vals.append(fn(df.iloc[idx]))
    vals = np.array(vals, dtype=float)
    return np.nanpercentile(vals, 2.5, axis=0), np.nanpercentile(vals, 97.5, axis=0), vals


def point_and_ci(df, fn, n_boot=N_BOOT):
    pt = fn(df); lo, hi, _ = cluster_bootstrap(df, fn, n_boot)
    return pt, lo, hi


def evaluate(name, thr_key="thr_youden", prob_key="prob_cal"):
    out_dir = RESULTS / name / "eval"; out_dir.mkdir(parents=True, exist_ok=True)
    df = pd.read_csv(RESULTS / name / "oof_predictions.csv")
    n_rep = df["rep"].nunique()
    y = df["label"].values; p = df[prob_key].values
    res = {"name": name, "n_rows": len(df), "n_patients": int(df["pid"].nunique()), "n_repeats": int(n_rep),
           "n_sclc": int(df.drop_duplicates("pid")["label"].sum()), "prob_key": prob_key, "threshold_key": thr_key}

    # ---- discrimination
    auc, lo, hi, se = delong_ci(y, p)
    res["auc"] = {"value": auc, "delong_ci": [lo, hi], "se": se}
    _, blo, bhi = point_and_ci(df, lambda d: roc_auc_score(d["label"], d[prob_key]))
    res["auc"]["bootstrap_ci"] = [blo, bhi]
    ap, alo, ahi = point_and_ci(df, lambda d: average_precision_score(d["label"], d[prob_key]))
    res["auprc"] = {"value": ap, "bootstrap_ci": [alo, ahi]}

    # ---- operating points
    ops = {}
    for key in [thr_key, "thr_sens80", "thr_f1max"]:
        if key not in df:
            continue
        m = binary_metrics(y, p, df[key].values)
        names = ["sensitivity", "specificity", "ppv", "npv", "accuracy", "balanced_accuracy", "f1_sclc", "macro_f1", "mcc"]
        lo_, hi_, _ = cluster_bootstrap(df, lambda d: [binary_metrics(d["label"], d[prob_key], d[key].values)[k] for k in names])
        ops[key] = {k: {"value": float(m[k]), "ci": [float(lo_[i]), float(hi_[i])]} for i, k in enumerate(names)}
        ops[key]["confusion"] = {k: m[k] for k in ["tp", "fp", "tn", "fn"]}
        ops[key]["mean_threshold"] = float(df[key].mean())
    m05 = binary_metrics(y, p, 0.5); ops["fixed_0.5"] = {k: {"value": float(v)} for k, v in m05.items()}
    res["operating_points"] = ops

    # ---- calibration
    cal = calibration_metrics(y, p)
    lo_, hi_, _ = cluster_bootstrap(df, lambda d: list(calibration_metrics(d["label"], d[prob_key]).values()), n_boot=1000)
    res["calibration"] = {k: {"value": v, "ci": [float(lo_[i]), float(hi_[i])]} for i, (k, v) in enumerate(cal.items())}
    res["calibration_raw_probs"] = calibration_metrics(y, df["prob_raw"].values) if "prob_raw" in df else None

    # ---- per fold / per repeat
    per_fold = []
    for (rep, fold), d in df.groupby(["rep", "fold"]):
        mm = binary_metrics(d["label"], d[prob_key], d[thr_key].values)
        per_fold.append({"rep": rep, "fold": fold, "n": len(d), "n_sclc": int(d["label"].sum()),
                         "auc": roc_auc_score(d["label"], d[prob_key]) if d["label"].nunique() > 1 else np.nan,
                         **{k: mm[k] for k in ["sensitivity", "specificity", "balanced_accuracy", "accuracy", "macro_f1"]}})
    pf = pd.DataFrame(per_fold); pf.to_csv(out_dir / "per_fold.csv", index=False)
    res["per_fold_mean_sd"] = {c: [float(pf[c].mean()), float(pf[c].std(ddof=1))] for c in ["auc", "sensitivity", "specificity", "balanced_accuracy", "accuracy", "macro_f1"]}
    per_rep = []
    for rep, d in df.groupby("rep"):
        mm = binary_metrics(d["label"], d[prob_key], d[thr_key].values)
        per_rep.append({"rep": rep, "auc": roc_auc_score(d["label"], d[prob_key]), **{k: mm[k] for k in ["sensitivity", "specificity", "balanced_accuracy", "accuracy", "macro_f1"]}})
    pr = pd.DataFrame(per_rep)
    res["per_repeat_mean_sd"] = {c: [float(pr[c].mean()), float(pr[c].std(ddof=1)) if len(pr) > 1 else 0.0] for c in pr.columns if c != "rep"}

    # ---- subgroups
    sub = {}
    for key, label in [("has_pet", "with_PET"), ("manufacturer", "manufacturer"), ("group", "histology")]:
        if key in df:
            for val, d in df.groupby(key):
                if d["label"].nunique() > 1 and len(d) >= 10:
                    mm = binary_metrics(d["label"], d[prob_key], d[thr_key].values)
                    sub[f"{label}={val}"] = {"n": len(d), "n_sclc": int(d["label"].sum()), "auc": roc_auc_score(d["label"], d[prob_key]),
                                             "sensitivity": mm["sensitivity"], "specificity": mm["specificity"]}
                elif len(d) >= 10:
                    sub[f"{label}={val}"] = {"n": len(d), "n_sclc": int(d["label"].sum()),
                                             "mean_prob": float(d[prob_key].mean())}
    res["subgroups"] = sub

    # ---- decision curve
    pts = np.arange(0.01, 0.61, 0.01)
    nb_m, nb_all = net_benefit(y, p, pts)
    res["dca"] = {"thresholds": pts.tolist(), "net_benefit_model": nb_m.tolist(), "net_benefit_treat_all": nb_all.tolist()}

    with open(out_dir / "metrics.json", "w", encoding="utf-8") as f:
        json.dump(res, f, indent=1, default=float)

    # ---- flat table
    flat = [{"metric": "AUC", "value": auc, "ci_low": lo, "ci_high": hi, "ci_type": "DeLong"},
            {"metric": "AUPRC", "value": ap, "ci_low": alo, "ci_high": ahi, "ci_type": "bootstrap"}]
    for key, o in ops.items():
        for k, v in o.items():
            if isinstance(v, dict) and "value" in v:
                flat.append({"metric": f"{k} @ {key}", "value": v["value"], "ci_low": v.get("ci", [np.nan, np.nan])[0],
                             "ci_high": v.get("ci", [np.nan, np.nan])[1], "ci_type": "bootstrap"})
    for k, v in res["calibration"].items():
        flat.append({"metric": k, "value": v["value"], "ci_low": v["ci"][0], "ci_high": v["ci"][1], "ci_type": "bootstrap"})
    pd.DataFrame(flat).to_csv(out_dir / "metrics_table.csv", index=False)

    # ---- figures
    fpr, tpr, _ = roc_curve(y, p)
    plt.figure(figsize=(4.2, 4.2)); plt.plot(fpr, tpr, lw=2, label=f"AUC {auc:.3f} ({lo:.3f}-{hi:.3f})")
    plt.plot([0, 1], [0, 1], "k--", lw=1); plt.xlabel("1 - specificity"); plt.ylabel("Sensitivity (SCLC)")
    plt.title(f"ROC: {name}"); plt.legend(loc="lower right", fontsize=8); plt.tight_layout(); plt.savefig(out_dir / "roc.png", dpi=300); plt.close()

    prec, rec, _ = precision_recall_curve(y, p)
    plt.figure(figsize=(4.2, 4.2)); plt.plot(rec, prec, lw=2, label=f"AUPRC {ap:.3f}")
    plt.axhline(y.mean(), color="k", ls="--", lw=1, label=f"prevalence {y.mean():.2f}")
    plt.xlabel("Recall (SCLC)"); plt.ylabel("Precision"); plt.title(f"PR: {name}"); plt.legend(fontsize=8); plt.tight_layout()
    plt.savefig(out_dir / "pr.png", dpi=300); plt.close()

    bins = np.quantile(p, np.linspace(0, 1, 9)); bins[0] = 0; bins[-1] = 1
    idx = np.clip(np.digitize(p, bins[1:-1]), 0, 7)
    xs = [p[idx == b].mean() for b in range(8) if (idx == b).any()]
    ys = [y[idx == b].mean() for b in range(8) if (idx == b).any()]
    ns = [(idx == b).sum() for b in range(8) if (idx == b).any()]
    err = [1.96 * np.sqrt(max(o * (1 - o), 1e-6) / n) for o, n in zip(ys, ns)]
    plt.figure(figsize=(4.2, 4.2)); plt.errorbar(xs, ys, yerr=err, fmt="o-", capsize=3, label="model (quantile bins)")
    plt.plot([0, 1], [0, 1], "k--", lw=1, label="perfect")
    plt.xlabel("Predicted probability of SCLC"); plt.ylabel("Observed proportion SCLC")
    plt.title(f"Calibration: slope {cal['calibration_slope']:.2f}, intercept {cal['calibration_intercept']:.2f}\nBrier {cal['brier']:.3f}", fontsize=9)
    plt.legend(fontsize=8); plt.tight_layout(); plt.savefig(out_dir / "calibration.png", dpi=300); plt.close()

    plt.figure(figsize=(4.6, 4.0)); plt.plot(pts, nb_m, lw=2, label="MIL fusion model"); plt.plot(pts, nb_all, lw=1.5, ls="--", label="treat all as SCLC")
    plt.axhline(0, color="k", lw=1, label="treat none"); plt.ylim(min(-0.02, nb_m.min() - 0.01), max(nb_all.max(), nb_m.max()) + 0.02)
    plt.xlabel("Threshold probability"); plt.ylabel("Net benefit"); plt.title(f"Decision curve: {name}"); plt.legend(fontsize=8); plt.tight_layout()
    plt.savefig(out_dir / "dca.png", dpi=300); plt.close()

    cm = np.array([[ops[thr_key]["confusion"]["tn"], ops[thr_key]["confusion"]["fp"]], [ops[thr_key]["confusion"]["fn"], ops[thr_key]["confusion"]["tp"]]])
    plt.figure(figsize=(3.6, 3.4)); plt.imshow(cm, cmap="Blues"); plt.xticks([0, 1], ["NSCLC", "SCLC"]); plt.yticks([0, 1], ["NSCLC", "SCLC"])
    for i in range(2):
        for j in range(2):
            plt.text(j, i, cm[i, j], ha="center", va="center", color="white" if cm[i, j] > cm.max() / 2 else "black")
    plt.xlabel("Predicted"); plt.ylabel("True"); plt.title(f"Confusion ({thr_key})", fontsize=9); plt.tight_layout(); plt.savefig(out_dir / "confusion.png", dpi=300); plt.close()

    print(f"\n==== {name}: n={res['n_patients']} patients (SCLC {res['n_sclc']}), repeats={n_rep}")
    print(f"AUC {auc:.3f} (DeLong {lo:.3f}-{hi:.3f}; boot {blo:.3f}-{bhi:.3f})   AUPRC {ap:.3f} ({alo:.3f}-{ahi:.3f})")
    for key, o in ops.items():
        if key == "fixed_0.5":
            continue
        print(f"  [{key}] sens {o['sensitivity']['value']:.3f} ({o['sensitivity']['ci'][0]:.2f}-{o['sensitivity']['ci'][1]:.2f}) "
              f"spec {o['specificity']['value']:.3f} bacc {o['balanced_accuracy']['value']:.3f} acc {o['accuracy']['value']:.3f} "
              f"macroF1 {o['macro_f1']['value']:.3f} PPV {o['ppv']['value']:.3f} NPV {o['npv']['value']:.3f}  conf={o['confusion']}")
    print(f"  calibration: {cal}")
    print(f"  per-fold mean±sd: " + ", ".join(f"{k}={v[0]:.3f}±{v[1]:.3f}" for k, v in res["per_fold_mean_sd"].items()))
    if sub:
        print("  subgroups:", json.dumps(sub, default=float))
    return res


def compare(a, b, prob_key="prob_cal", thr_key="thr_youden"):
    da = pd.read_csv(RESULTS / a / "oof_predictions.csv"); db = pd.read_csv(RESULTS / b / "oof_predictions.csv")
    da = da[da["rep"] == 0]; db = db[db["rep"] == 0]
    m = da.merge(db, on="pid", suffixes=("_a", "_b"))
    y = m["label_a"].values
    auc1, auc2, diff, z, p = delong_paired_test(y, m[f"{prob_key}_a"].values, m[f"{prob_key}_b"].values)
    print(f"\n==== {a} vs {b} on {len(m)} common patients (SCLC {int(y.sum())})")
    print(f"AUC {auc1:.4f} vs {auc2:.4f}  diff={diff:+.4f}  DeLong z={z:.2f} p={p:.4f}")
    rng = np.random.default_rng(7); diffs = []
    for _ in range(N_BOOT):
        i = rng.integers(0, len(m), len(m))
        if len(np.unique(y[i])) < 2:
            continue
        ma = binary_metrics(y[i], m[f"{prob_key}_a"].values[i], m[f"{thr_key}_a"].values[i])
        mb = binary_metrics(y[i], m[f"{prob_key}_b"].values[i], m[f"{thr_key}_b"].values[i])
        diffs.append([ma["balanced_accuracy"] - mb["balanced_accuracy"], ma["sensitivity"] - mb["sensitivity"], ma["macro_f1"] - mb["macro_f1"]])
    diffs = np.array(diffs)
    for i, k in enumerate(["balanced_accuracy", "sensitivity", "macro_f1"]):
        print(f"  diff {k}: {np.mean(diffs[:, i]):+.3f} (95% CI {np.percentile(diffs[:, i], 2.5):+.3f} to {np.percentile(diffs[:, i], 97.5):+.3f})")
    out = {"a": a, "b": b, "n": int(len(m)), "auc_a": auc1, "auc_b": auc2, "auc_diff": diff, "delong_z": z, "delong_p": p,
           "bootstrap_diffs": {k: [float(np.mean(diffs[:, i])), float(np.percentile(diffs[:, i], 2.5)), float(np.percentile(diffs[:, i], 97.5))]
                               for i, k in enumerate(["balanced_accuracy", "sensitivity", "macro_f1"])}}
    (RESULTS / a / "eval").mkdir(parents=True, exist_ok=True)
    with open(RESULTS / a / "eval" / f"compare_vs_{b}.json", "w", encoding="utf-8") as f:
        json.dump(out, f, indent=1, default=float)
    return out


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--names", nargs="*", default=[])
    ap.add_argument("--compare", nargs=2, default=None)
    ap.add_argument("--thr", default="thr_youden")
    ap.add_argument("--prob", default="prob_cal")
    args = ap.parse_args()
    for n in args.names:
        evaluate(n, args.thr, args.prob)
    if args.compare:
        compare(args.compare[0], args.compare[1], args.prob, args.thr)
