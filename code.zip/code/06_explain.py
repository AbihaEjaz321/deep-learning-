"""
Step 6: interpretability figures (fine-tuned models from 04_train_cv.py or frozen-head models from 12_train_frozen.py).

For patients of an outer test fold (never seen by the fold's models):
  * MIL attention weight of every slice in the bag (and how much attention mass lands on radiologist-annotated slices)
  * Grad-CAM (penultimate EfficientNet stage, stride 16) on the CT encoder and on the PET encoder for the top slices
  * CT->PET cross-attention maps (where the CT tokens look inside the PET feature map)

  python 06_explain.py --name ft_ctx --fold 0 --inner 0 --n_per_class 3
  python 06_explain.py --name final_b0_xattn --fold 0 --inner 0 --n_per_class 3     # frozen encoders + trained head
"""
import argparse
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import cv2

from common import BagDataset, MILFusionNet, Encoder, load_cohort, HERE, SUV_SCALES, VIEWS

RESULTS = HERE / "results"


class FrozenCombined(nn.Module):
    """Frozen ImageNet encoders + trained FrozenFusionHead, exposing the same interface as MILFusionNet."""
    def __init__(self, backbone, head, pool):
        super().__init__()
        self.enc_ct = Encoder(backbone, 2, pretrained=True, drop_path=0.0)
        self.enc_pt = Encoder(backbone, 2, pretrained=True, drop_path=0.0)
        self.head = head; self.pool = pool; self.fusion = head.fusion

    def tokens(self, enc, x):                       # (N, C, H, W) -> (N, T, D) with optional pooling
        f = enc.net.forward_features(x)
        if self.pool != f.shape[-1]:
            f = F.adaptive_avg_pool2d(f, self.pool)
        return f.flatten(2).transpose(1, 2)

    def forward(self, ct, pt, pet_mask, slice_mask, geom=None, return_attn=False):
        B, K, V = ct.shape[:3]
        t_ct = self.tokens(self.enc_ct, ct.flatten(0, 2)).view(B, K, V, -1, self.enc_ct.out_dim)
        t_pt = self.tokens(self.enc_pt, pt.flatten(0, 2)).view(B, K, V, -1, self.enc_pt.out_dim)
        return self.head(t_ct, t_pt, pet_mask, slice_mask, geom, return_attn=return_attn)


def load_model(name, fold, inner, device):
    cfg = json.load(open(RESULTS / name / "folds.json", encoding="utf-8"))["config"]
    view = cfg.get("view", "detail")
    sd = torch.load(RESULTS / name / "models" / f"r0f{fold}i{inner}.pt", map_location="cpu")
    sd = {k: v.float() if v.is_floating_point() else v for k, v in sd.items()}
    if str(cfg.get("backbone", "")).startswith("frozen:"):
        sys.path.insert(0, str(HERE))
        from importlib import import_module
        mod = import_module("12_train_frozen") if False else None
        import importlib.util
        spec = importlib.util.spec_from_file_location("trainfrozen", HERE / "12_train_frozen.py"); tf = importlib.util.module_from_spec(spec); spec.loader.exec_module(tf)
        fmeta = json.load(open(HERE / "feat" / cfg["tag"] / "meta.json"))
        head = tf.FrozenFusionHead(fmeta["dim"], cfg["fusion"], cfg["d"], cfg["heads"], cfg["dropout"], cfg["token_drop"], len(VIEWS[view]), cfg.get("geom", False))
        head.load_state_dict(sd)
        model = FrozenCombined(fmeta["backbone"], head, fmeta["pool"])
    else:
        model = MILFusionNet(cfg["backbone"], fusion=cfg["fusion"], pretrained=False, views=len(VIEWS[view]), use_geom=cfg.get("geom", False))
        model.load_state_dict(sd)
    return model.to(device).eval(), cfg


def grad_cam(model, enc_name, ct, pt, pm, mask, geom):
    """Grad-CAM of the bag logit w.r.t. the penultimate EfficientNet stage (14x14). Returns (K*V, h, w) maps."""
    enc = getattr(model, enc_name)
    acts = {}

    def fwd_hook(m, i, o):
        o.retain_grad(); acts["a"] = o
    h = enc.net.blocks[-2].register_forward_hook(fwd_hook)
    model.zero_grad(set_to_none=True)
    logit, attn, xw = model(ct, pt, pm, mask, geom, return_attn=True)
    logit.sum().backward()
    h.remove()
    a = acts["a"]; g = a.grad
    w = g.mean(dim=(2, 3), keepdim=True)
    cam = F.relu((w * a).sum(1))
    cam[:, 0, :] = 0; cam[:, -1, :] = 0; cam[:, :, 0] = 0; cam[:, :, -1] = 0      # suppress padding-border artefacts
    cam = cam / (cam.amax(dim=(1, 2), keepdim=True) + 1e-8)
    return cam.detach().cpu().numpy(), float(torch.sigmoid(logit).item()), attn[0].detach().cpu().numpy(), xw


def overlay(base_gray, heat, alpha=0.45, cmap=cv2.COLORMAP_JET):
    base = (np.clip(base_gray, 0, 1) * 255).astype(np.uint8)
    heat_u8 = (np.clip(heat, 0, 1) * 255).astype(np.uint8)
    hm = cv2.applyColorMap(cv2.resize(heat_u8, (base.shape[1], base.shape[0]), interpolation=cv2.INTER_CUBIC), cmap)
    hm = cv2.cvtColor(hm, cv2.COLOR_BGR2RGB)
    rgb = np.stack([base] * 3, -1)
    return (rgb * (1 - alpha) + hm * alpha).astype(np.uint8)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--name", required=True); ap.add_argument("--fold", type=int, default=0); ap.add_argument("--inner", type=int, default=0)
    ap.add_argument("--n_per_class", type=int, default=3); ap.add_argument("--top_slices", type=int, default=3)
    ap.add_argument("--pids", nargs="*", default=None)
    args = ap.parse_args()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    out_dir = RESULTS / args.name / "explain"; out_dir.mkdir(parents=True, exist_ok=True)
    model, cfg = load_model(args.name, args.fold, args.inner, device)
    view = cfg.get("view", "detail"); V = len(VIEWS[view]); v_show = 0
    oof = pd.read_csv(RESULTS / args.name / "oof_predictions.csv")
    test = oof[(oof["rep"] == 0) & (oof["fold"] == args.fold)].copy()
    if args.pids:
        sel = test[test["pid"].isin(args.pids)]
    else:
        pet_pref = test[test["has_pet"]] if test["has_pet"].any() else test
        sel = pd.concat([
            pet_pref[pet_pref["label"] == 1].sort_values("prob_cal", ascending=False).head(args.n_per_class),
            test[test["label"] == 1].sort_values("prob_cal", ascending=False).head(args.n_per_class),
            pet_pref[pet_pref["label"] == 0].sort_values("prob_cal").head(args.n_per_class),
            test[test["label"] == 1].sort_values("prob_cal").head(1),
        ]).drop_duplicates("pid")
    recs = {r.pid: r for r in load_cohort(sorted(sel["pid"].tolist()), verbose=False)}
    ds = BagDataset(list(recs.values()), train=False, use_pet=True, eval_max_slices=48, view=view)
    attention_stats = []
    for i in range(len(ds)):
        ct, pt, pm, y, pid, ks, geom = ds[i]
        rec = recs[pid]
        ctd = ct.unsqueeze(0).to(device); ptd = pt.unsqueeze(0).to(device); pmd = pm.view(1).to(device); gd = geom.view(1, -1).to(device)
        mask = torch.ones(1, ct.shape[1], dtype=torch.bool, device=device)
        has_pet = bool(pm.item()) and cfg["fusion"] in ("xattn", "concat", "early")
        enc_name = "enc_ct" if hasattr(model, "enc_ct") else "enc"
        cam_ct, prob, attn, xw = grad_cam(model, enc_name, ctd, ptd, pmd, mask, gd)
        cam_ct = cam_ct.reshape(ct.shape[0], V, *cam_ct.shape[1:])[:, v_show]
        cam_pt = None
        if has_pet and hasattr(model, "enc_pt"):
            c = grad_cam(model, "enc_pt", ctd, ptd, pmd, mask, gd)[0]
            cam_pt = c.reshape(ct.shape[0], V, *c.shape[1:])[:, v_show]
        ks_np = ks.numpy(); ann = rec.annotated[ks_np]
        attention_stats.append({"pid": pid, "label": int(y.item()), "prob": prob, "n_slices": len(ks_np), "n_annotated": int(ann.sum()),
                                "attention_on_annotated": float(attn[ann].sum()) if ann.any() else np.nan,
                                "uniform_expectation": float(ann.mean()) if len(ann) else np.nan,
                                "attention_max": float(attn.max()), "attention_entropy_ratio": float(-(attn * np.log(attn + 1e-9)).sum() / np.log(len(attn)))})
        order = np.argsort(-attn)[: args.top_slices]
        ncol = 5 if cam_pt is not None else 3
        fig, axes = plt.subplots(len(order), ncol, figsize=(2.6 * ncol, 2.7 * len(order)))
        axes = np.atleast_2d(axes)
        for r_, k in enumerate(order):
            lung = ct[k, v_show, 0].numpy(); med = ct[k, v_show, 1].numpy()
            axes[r_, 0].imshow(lung, cmap="gray"); axes[r_, 0].set_title(f"CT lung | slice {ks_np[k]} | a={attn[k]:.2f}{' *ann' if ann[k] else ''}", fontsize=7)
            axes[r_, 1].imshow(med, cmap="gray"); axes[r_, 1].set_title("CT mediastinal", fontsize=7)
            axes[r_, 2].imshow(overlay(lung, cam_ct[k])); axes[r_, 2].set_title("Grad-CAM (CT encoder)", fontsize=7)
            if cam_pt is not None:
                suv = pt[k, v_show, 0].numpy() * SUV_SCALES[0]
                axes[r_, 3].imshow(lung, cmap="gray"); axes[r_, 3].imshow(np.ma.masked_less(suv, 1.5), cmap="hot", alpha=0.6, vmin=0, vmax=10)
                axes[r_, 3].set_title("PET SUV (>1.5) on CT", fontsize=7)
                axes[r_, 4].imshow(overlay(np.clip(suv / 10, 0, 1), cam_pt[k])); axes[r_, 4].set_title("Grad-CAM (PET encoder)", fontsize=7)
            for a_ in axes[r_]:
                a_.axis("off")
        fig.suptitle(f"{pid} | true={'SCLC' if y.item() == 1 else 'NSCLC'} | p(SCLC)={prob:.2f} | PET {'used' if has_pet else 'absent'} | {args.name}", fontsize=9)
        fig.tight_layout(); fig.savefig(out_dir / f"{pid}_gradcam.png", dpi=200); plt.close(fig)

        fig, ax = plt.subplots(figsize=(5, 2.2))
        ax.bar(range(len(attn)), attn, color=["tab:red" if a_ else "tab:gray" for a_ in ann])
        ax.set_xlabel("slice index in bag (red = radiologist-annotated tumour slice)"); ax.set_ylabel("MIL attention")
        ax.set_title(f"{pid}: attention mass on annotated slices = {attention_stats[-1]['attention_on_annotated']:.2f} "
                     f"(uniform would be {attention_stats[-1]['uniform_expectation']:.2f})", fontsize=8)
        fig.tight_layout(); fig.savefig(out_dir / f"{pid}_attention.png", dpi=200); plt.close(fig)

        if xw is not None and xw[0] is not None and has_pet:
            k = order[0]
            w_ct = xw[0][k * V + v_show].detach().float().cpu().numpy()
            t = int(np.sqrt(w_ct.shape[1]))
            received = w_ct.mean(0).reshape(t, t)
            fig, ax = plt.subplots(1, 2, figsize=(5.2, 2.7))
            ax[0].imshow(ct[k, v_show, 0].numpy(), cmap="gray"); ax[0].set_title("CT (top-attention slice)", fontsize=8)
            ax[1].imshow(overlay(np.clip(pt[k, v_show, 0].numpy(), 0, 1), received / received.max())); ax[1].set_title("PET positions attended by CT queries", fontsize=8)
            for a_ in ax:
                a_.axis("off")
            fig.tight_layout(); fig.savefig(out_dir / f"{pid}_crossattention.png", dpi=200); plt.close(fig)
        print(f"{pid}: label={int(y.item())} p={prob:.3f} attention on annotated={attention_stats[-1]['attention_on_annotated']:.2f} "
              f"(uniform {attention_stats[-1]['uniform_expectation']:.2f}) max_attn={attention_stats[-1]['attention_max']:.2f}")
    pd.DataFrame(attention_stats).to_csv(out_dir / f"attention_stats_fold{args.fold}.csv", index=False)


if __name__ == "__main__":
    main()
