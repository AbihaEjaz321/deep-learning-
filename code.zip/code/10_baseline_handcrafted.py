"""
Step 10: hand-crafted reference baselines evaluated with exactly the same nested patient-level CV protocol.

Features per patient (from the cached boxes/HU/SUV, no deep learning):
  lesion geometry: log max diameter (mm), log cranio-caudal extent (mm), log max box area (cm2)
  CT intensity in the box: mean HU, HU std, solid fraction (HU > -300), 90th percentile HU
  PET in the box (when available): SUVmax, SUVmean, SUVpeak-ish (mean of top 5%), + has_pet indicator
Models: logistic regression (L2) and gradient boosting, inner 3-fold for threshold/temperature as in 04.
Writes results/<name>/oof_predictions.csv + folds.json so 05_evaluate.py / 09_summary.py can treat them like any experiment.
"""
import json
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import RepeatedStratifiedKFold, StratifiedKFold
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

from common import fit_temperature, select_thresholds, HERE

RESULTS = HERE / "results"
CACHE = HERE / "cache"


def features_for(pid):
    m = json.load(open(CACHE / pid / "meta.json", encoding="utf-8"))
    ct = np.load(CACHE / pid / "ct_hu.npy"); pet = np.load(CACHE / pid / "pet_suv.npy").astype(np.float32) if (CACHE / pid / "pet_suv.npy").exists() else None
    ps = float(m["ct_spacing_row_col"][0])
    diam, area, hu_vals, suv_vals, pos = [], [], [], [], []
    for k, s in enumerate(m["slices"]):
        for b in s["boxes"]:
            x0, y0, x1, y1 = [int(v) for v in b[:4]]
            diam.append(max(x1 - x0, y1 - y0) * ps); area.append((x1 - x0) * (y1 - y0) * ps * ps / 100.0); pos.append(s["pos"])
            hu_vals.append(ct[k, y0:y1, x0:x1].astype(np.float32).ravel())
            if pet is not None:
                suv_vals.append(pet[k, y0:y1, x0:x1].ravel())
    if not diam:
        return None
    hu = np.concatenate(hu_vals)
    f = {"pid": pid, "label": int(m["label"]), "group": m["group"], "has_pet": bool(pet is not None),
         "log_diam": np.log(max(diam)), "log_extent": np.log((max(pos) - min(pos)) + m["ct_effective_dz"]), "log_area": np.log(max(area)),
         "hu_mean": float(hu.mean()), "hu_std": float(hu.std()), "solid_frac": float((hu > -300).mean()), "hu_p90": float(np.percentile(hu, 90)),
         "n_boxes": len(diam), "manufacturer": m.get("ct_manufacturer", "")}
    if pet is not None and suv_vals:
        sv = np.concatenate(suv_vals)
        f.update({"suv_max": float(sv.max()), "suv_mean": float(sv.mean()), "suv_top5": float(np.mean(np.sort(sv)[-max(1, len(sv) // 20):]))})
    else:
        f.update({"suv_max": np.nan, "suv_mean": np.nan, "suv_top5": np.nan})
    return f


def run(name, feature_cols, model_fn, df, folds=5, repeats=1, inner=3, seed=42):
    out = RESULTS / name; out.mkdir(parents=True, exist_ok=True)
    y = df["label"].values
    rskf = RepeatedStratifiedKFold(n_splits=folds, n_repeats=repeats, random_state=seed)
    rows, finfo = [], []
    for i, (tr, te) in enumerate(rskf.split(np.zeros(len(df)), y)):
        rep, fold = i // folds, i % folds
        Xtr = df.iloc[tr][feature_cols].copy(); Xte = df.iloc[te][feature_cols].copy()
        med = Xtr.median()
        Xtr = Xtr.fillna(med); Xte = Xte.fillna(med)
        skf = StratifiedKFold(n_splits=inner, shuffle=True, random_state=seed + 1000 * rep + fold)
        inner_oof = np.zeros(len(tr)); test_logit = []
        for itr, iva in skf.split(np.zeros(len(tr)), y[tr]):
            mdl = model_fn().fit(Xtr.iloc[itr], y[tr][itr])
            p = np.clip(mdl.predict_proba(Xtr.iloc[iva])[:, 1], 1e-5, 1 - 1e-5); inner_oof[iva] = np.log(p / (1 - p))
            pt = np.clip(mdl.predict_proba(Xte)[:, 1], 1e-5, 1 - 1e-5); test_logit.append(np.log(pt / (1 - pt)))
        T = fit_temperature(inner_oof, y[tr])
        thr = select_thresholds(1 / (1 + np.exp(-inner_oof / T)), y[tr], 0.80)
        pd.DataFrame({"pid": df.iloc[tr]["pid"].values, "label": y[tr], "rep": rep, "fold": fold, "logit": inner_oof,
                      "prob_cal": 1 / (1 + np.exp(-inner_oof / T))}).to_csv(out / f"inner_oof_r{rep}f{fold}.csv", index=False)
        tl = np.stack(test_logit); p_cal = (1 / (1 + np.exp(-tl / T))).mean(0); p_raw = (1 / (1 + np.exp(-tl))).mean(0)
        finfo.append({"rep": rep, "fold": fold, "temperature": T, "thresholds": thr, "inner_oof_auc": float(roc_auc_score(y[tr], inner_oof)),
                      "test_auc": float(roc_auc_score(y[te], p_cal)) if len(np.unique(y[te])) > 1 else None})
        for k, idx in enumerate(te):
            r = df.iloc[idx]
            rows.append({"pid": r["pid"], "label": int(r["label"]), "group": r["group"], "rep": rep, "fold": fold, "prob_cal": float(p_cal[k]),
                         "prob_raw": float(p_raw[k]), "logit_mean": float(tl[:, k].mean()), "temperature": T, "thr_youden": thr["youden"],
                         "thr_f1max": thr["f1max"], "thr_sens80": thr["sens80"], "has_pet": bool(r["has_pet"]), "pet_used": bool(r["has_pet"]),
                         "manufacturer": r["manufacturer"], "n_slices": int(r["n_boxes"]), "fallback_roi": False})
    pd.DataFrame(rows).to_csv(out / "oof_predictions.csv", index=False)
    cfg = {"name": name, "fusion": "handcrafted:" + model_fn().__class__.__name__, "cohort": "all", "loss": "n/a", "lomo": None,
           "inner": inner, "folds": folds, "repeats": repeats, "features": feature_cols, "view": "n/a", "no_pet": False, "backbone": "n/a", "final_eval_slices": 0}
    with open(out / "folds.json", "w", encoding="utf-8") as f:
        json.dump({"config": cfg, "folds": finfo}, f, indent=1)
    d = pd.DataFrame(rows)
    print(f"{name}: pooled OOF AUC = {roc_auc_score(d['label'], d['prob_cal']):.3f}  inner-OOF AUC mean = {np.mean([f['inner_oof_auc'] for f in finfo]):.3f}")


if __name__ == "__main__":
    pids = sorted(p.name for p in CACHE.iterdir() if (p / "meta.json").exists())
    feats = [f for f in (features_for(p) for p in pids) if f is not None]
    df = pd.DataFrame(feats); df.to_csv(HERE / "index" / "handcrafted_features.csv", index=False)
    print("patients with features:", len(df))
    geom = ["log_diam", "log_extent", "log_area"]
    ct_feats = geom + ["hu_mean", "hu_std", "solid_frac", "hu_p90"]
    all_feats = ct_feats + ["suv_max", "suv_mean", "suv_top5", "has_pet"]
    df["has_pet"] = df["has_pet"].astype(float)
    lr = lambda: make_pipeline(StandardScaler(), LogisticRegression(C=0.5, class_weight="balanced", max_iter=2000))
    gb = lambda: GradientBoostingClassifier(n_estimators=150, max_depth=2, learning_rate=0.05, subsample=0.8, random_state=0)
    run("baseline_geometry_logreg", geom, lr, df)
    run("baseline_ct_handcrafted_logreg", ct_feats, lr, df)
    run("baseline_ctpet_handcrafted_logreg", all_feats, lr, df)
    run("baseline_ctpet_handcrafted_gbm", all_feats, gb, df)
