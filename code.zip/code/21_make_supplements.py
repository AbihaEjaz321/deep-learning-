# -*- coding: utf-8 -*-
"""
Step 21: build the revision package next to the manuscript:
  Revision_package/Response_to_Reviewers.docx        (from docs/response_to_reviewers.md)
  Revision_package/S1_Table_TRIPOD_AI_checklist.docx (from docs/tripod_checklist.md)
  Revision_package/S2_Text_sample_size.docx          (from docs/sample_size_note.md)
  Revision_package/S3_Table_thresholds_recalibration.xlsx
  Revision_package/S4_Table_inner_fold_selection.xlsx
  Revision_package/S5_Table_all_results.xlsx
  Revision_package/Figures/Fig4..Fig6, S1_Fig, S2_Fig (PNG)
  Revision_package/S1_Data/ (code, OOF predictions, fold assignments, alignment QC)
"""
import json
import re
import shutil
from pathlib import Path

import pandas as pd
from docx import Document
from docx.shared import Pt

HERE = Path(__file__).resolve().parent
RESULTS = HERE / "results"; DOCS = HERE / "docs"
PKG = HERE.parent / "Revision_package"; PKG.mkdir(exist_ok=True)
(PKG / "Figures").mkdir(exist_ok=True); (PKG / "S1_Data").mkdir(exist_ok=True)


def md_to_docx(md_path, out_path, title=None):
    doc = Document()
    style = doc.styles["Normal"]; style.font.name = "Calibri"; style.font.size = Pt(11)
    if title:
        doc.add_heading(title, level=0)
    table_buf = []

    def flush_table():
        nonlocal table_buf
        rows = [r for r in table_buf if not re.match(r"^\|\s*-+", r)]
        cells = [[c.strip() for c in r.strip().strip("|").split("|")] for r in rows]
        if cells:
            t = doc.add_table(rows=len(cells), cols=len(cells[0])); t.style = "Table Grid"
            for i, r in enumerate(cells):
                for j, c in enumerate(r[: len(cells[0])]):
                    cell = t.cell(i, j); cell.text = ""
                    run = cell.paragraphs[0].add_run(c.replace("**", "")); run.font.size = Pt(8); run.bold = (i == 0)
        table_buf = []

    def add_rich(par, text):
        parts = re.split(r"(\*\*[^*]+\*\*|\*[^*]+\*|`[^`]+`)", text)
        for p in parts:
            if not p:
                continue
            if p.startswith("**"):
                par.add_run(p[2:-2]).bold = True
            elif p.startswith("*"):
                par.add_run(p[1:-1]).italic = True
            elif p.startswith("`"):
                r = par.add_run(p[1:-1]); r.font.name = "Consolas"
            else:
                par.add_run(p)

    for line in Path(md_path).read_text(encoding="utf-8").splitlines():
        if line.startswith("|"):
            table_buf.append(line); continue
        if table_buf:
            flush_table()
        s = line.rstrip()
        if not s:
            continue
        if s.startswith("# "):
            doc.add_heading(s[2:], level=1)
        elif s.startswith("## "):
            doc.add_heading(s[3:], level=2)
        elif s.startswith("### "):
            doc.add_heading(s[4:], level=3)
        elif s.startswith("> "):
            p = doc.add_paragraph(); r = p.add_run(s[2:].replace("*", "")); r.italic = True
        elif s.startswith("- "):
            add_rich(doc.add_paragraph(style="List Bullet"), s[2:])
        elif re.match(r"^\d+\. ", s):
            add_rich(doc.add_paragraph(style="List Number"), re.sub(r"^\d+\. ", "", s))
        elif s == "---":
            doc.add_paragraph()
        else:
            add_rich(doc.add_paragraph(), s)
    if table_buf:
        flush_table()
    doc.save(out_path); print("wrote", out_path)


md_to_docx(DOCS / "response_to_reviewers.md", PKG / "Response_to_Reviewers.docx")
md_to_docx(DOCS / "cover_letter.md", PKG / "Cover_letter.docx")
md_to_docx(DOCS / "tripod_checklist.md", PKG / "S1_Table_TRIPOD_AI_checklist.docx", "S1 Table. TRIPOD+AI checklist")
md_to_docx(DOCS / "sample_size_note.md", PKG / "S2_Text_sample_size.docx", "S2 Text. Sample-size and precision considerations")

# ---- S3: thresholds and recalibration per fold
rows = []
for name in ["ens_ft_frz_platt", "ft_ctx_platt", "ft_early_ctx_platt", "final_b0_xattn_platt", "final_b0_xattn_geom_platt", "final_b0_concat_platt",
             "final_b0_ct_only_platt", "final_b0_xattn_bce_platt", "baseline_ctpet_handcrafted_logreg_platt", "stage_TN_logreg", "fusion_img_TN"]:
    fj = json.load(open(RESULTS / name / "folds.json", encoding="utf-8"))
    for f in fj["folds"]:
        rows.append({"model": name, "repeat": f["rep"], "fold": f["fold"], "platt_a": f.get("platt_a"), "platt_b": f.get("platt_b"),
                     "threshold_youden": f["thresholds"]["youden"], "threshold_f1max": f["thresholds"]["f1max"], "threshold_sens80": f["thresholds"]["sens80"],
                     "inner_oof_auc": f.get("inner_oof_auc"), "test_fold_auc": f.get("test_auc")})
pd.DataFrame(rows).to_excel(PKG / "S3_Table_thresholds_recalibration.xlsx", index=False)

# ---- S4: inner-fold selection of views / features / fusion (screening runs, repeat 0)
sel = []
screen_dirs = [p for root in (RESULTS, HERE / "results_v1_before_alignment_fix") if root.exists() for p in sorted(root.iterdir())]
for p in screen_dirs:
    if p.name.startswith(("frz_", "frzd_")) and (p / "folds.json").exists() and (p / "oof_predictions.csv").exists():
        fj = json.load(open(p / "folds.json", encoding="utf-8")); cfg = fj["config"]
        inner = [f["inner_oof_auc"] for f in fj["folds"] if f.get("inner_oof_auc") is not None]
        oof = pd.read_csv(p / "oof_predictions.csv")
        from sklearn.metrics import roc_auc_score
        sel.append({"run": p.name, "features": cfg.get("tag"), "view": cfg.get("view"), "fusion": cfg.get("fusion"), "geometry": cfg.get("geom", False),
                    "selection": cfg.get("select", "best"), "mean_inner_fold_AUC": sum(inner) / len(inner), "pooled_outer_AUC (not used for selection)": roc_auc_score(oof["label"], oof["prob_cal"])})
pd.DataFrame(sel).sort_values("mean_inner_fold_AUC", ascending=False).to_excel(PKG / "S4_Table_inner_fold_selection.xlsx", index=False)
print("S4 rows:", len(sel), "(screening runs were performed before the PET alignment correction; selection used inner-fold AUC only)")

# ---- S5: all results
pd.read_csv(DOCS / "results_summary.csv").to_excel(PKG / "S5_Table_all_results.xlsx", index=False)

# ---- figures
fig = DOCS / "figures"
shutil.copy(fig / "fig_roc_main.png", PKG / "Figures" / "Fig4A_ROC.png")
shutil.copy(fig / "fig_ablation_auc.png", PKG / "Figures" / "Fig4B_AUC_forest.png")
shutil.copy(fig / "fig_calibration_dca.png", PKG / "Figures" / "Fig5_calibration_DCA.png")
shutil.copy(fig / "fig_operating_points.png", PKG / "Figures" / "SFig_operating_points.png")
ex = RESULTS / "ft_ctx" / "explain"
for n in ["B0012", "B0013", "A0192", "B0036"]:
    for suffix in ["gradcam", "attention", "crossattention"]:
        f = ex / f"{n}_{suffix}.png"
        if f.exists():
            shutil.copy(f, PKG / "Figures" / f"Fig6_{n}_{suffix}.png")
for f in sorted((HERE / "cache" / "_qa").glob("mosaic_registered_*.png"))[:2] + sorted((HERE / "cache" / "_qa").glob("mosaic_flagged_*.png"))[:1]:
    shutil.copy(f, PKG / "Figures" / f"S1_Fig_{f.name}")

# ---- S1 Data: code + predictions + QC
code = PKG / "S1_Data" / "code"; code.mkdir(exist_ok=True)
for f in sorted(HERE.glob("*.py")):
    shutil.copy(f, code / f.name)
pred = PKG / "S1_Data" / "predictions"; pred.mkdir(exist_ok=True)
for name in ["ens_ft_frz_platt", "ft_ctx_platt", "ft_early_ctx_platt", "final_b0_xattn_platt", "final_b0_xattn_geom_platt", "final_b0_concat_platt",
             "final_b0_ct_only_platt", "final_b0_xattn_bce_platt", "baseline_ctpet_handcrafted_logreg_platt", "baseline_geometry_logreg_platt",
             "stage_TN_logreg", "fusion_img_TN", "final_b0_paired_xattn_platt", "final_b0_paired_ct_only_platt", "final_b0_paired_pet_only_platt",
             "final_b0_paired_concat_platt", "final_b0_lomo_GE_platt", "final_b0_lomo_SIEMENS_platt", "final_b0_lomo_Philips_platt"]:
    shutil.copy(RESULTS / name / "oof_predictions.csv", pred / f"{name}_oof_predictions.csv")
shutil.copy(RESULTS / "ft_ctx" / "robustness" / "summary.csv", pred / "robustness_ft_ctx.csv")
shutil.copy(HERE / "index" / "cache_summary.csv", PKG / "S1_Data" / "alignment_qc_and_series_selection.csv")
shutil.copy(DOCS / "cohort_table.csv", PKG / "S1_Data" / "participant_characteristics.csv")
print("package at", PKG)
