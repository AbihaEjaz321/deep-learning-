"""
Step 15: manuscript-style summary figures from the out-of-fold predictions.
  fig_roc_main.png        ROC curves of the main model, the OOF ensemble, CT-only ablation and the hand-crafted baseline
  fig_ablation_auc.png    AUC with DeLong CIs for all experiments (forest plot)
  fig_calibration_dca.png reliability diagram + decision curve for the ensemble and the main model
  fig_operating_points.png sensitivity / specificity at the two frozen operating points
Usage: python 15_figures.py --main final_b0_xattn --ensemble ens_all5
"""
import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve, roc_auc_score

HERE = Path(__file__).resolve().parent
RESULTS = HERE / "results"; DOCS = HERE / "docs"; FIG = DOCS / "figures"; FIG.mkdir(parents=True, exist_ok=True)

LABELS = {
    "final_b0_xattn": "Proposed: frozen dual EfficientNet-B0 + cross-attention MIL (context view)",
    "final_b0_ct_only": "CT-only (same head)", "final_b0_concat": "Dual-stream concatenation (no cross-attention)",
    "final_b0_xattn_bce": "Proposed, weighted BCE loss", "final_b0_xattn_geom": "Proposed + lesion geometry descriptors",
    "ft_ctx": "End-to-end fine-tuned dual EfficientNet-B0 + cross-attention MIL", "ft_early_ctx": "End-to-end pixel-level early fusion",
    "baseline_geometry_logreg": "Lesion geometry + logistic regression", "baseline_ct_handcrafted_logreg": "CT hand-crafted features + LR",
    "baseline_ctpet_handcrafted_logreg": "CT+PET hand-crafted features + LR", "baseline_ctpet_handcrafted_gbm": "CT+PET hand-crafted features + GBM",
    "ens_all5": "OOF ensemble (2 fine-tuned + 3 frozen-head models)", "ens_frozen3": "OOF ensemble (3 frozen-head models)",
    "ens_ft_frz": "OOF ensemble (fine-tuned + frozen main)", "ens_deep_ft2_frz2": "OOF ensemble (4 deep models)",
    "final_b0_paired_xattn": "Paired subset: CT+PET cross-attention", "final_b0_paired_ct_only": "Paired subset: CT-only",
    "final_b0_paired_pet_only": "Paired subset: PET-only", "final_b0_paired_concat": "Paired subset: concatenation",
    "final_b0_lomo_GE": "Leave-GE-out (test on GE CTs)", "final_b0_lomo_SIEMENS": "Leave-Siemens-out", "final_b0_lomo_Philips": "Leave-Philips-out",
}


def load(name):
    d = pd.read_csv(RESULTS / name / "oof_predictions.csv")
    m = json.load(open(RESULTS / name / "eval" / "metrics.json")) if (RESULTS / name / "eval" / "metrics.json").exists() else None
    return d, m


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--main", default="final_b0_xattn"); ap.add_argument("--ensemble", default="ens_all5")
    args = ap.parse_args()

    # ---------------- ROC
    plt.figure(figsize=(4.8, 4.6))
    for name, color in [(args.ensemble, "tab:red"), (args.main, "tab:blue"), ("final_b0_ct_only", "tab:green"), ("baseline_ctpet_handcrafted_logreg", "tab:gray")]:
        if not (RESULTS / name / "oof_predictions.csv").exists():
            continue
        d, m = load(name); d = d[d["rep"] == 0]
        fpr, tpr, _ = roc_curve(d["label"], d["prob_cal"]); auc = roc_auc_score(d["label"], d["prob_cal"])
        ci = f" ({m['auc']['delong_ci'][0]:.2f}-{m['auc']['delong_ci'][1]:.2f})" if m else ""
        plt.plot(fpr, tpr, color=color, lw=2, label=f"{LABELS.get(name, name)[:46]}\nAUC {auc:.3f}{ci}")
    plt.plot([0, 1], [0, 1], "k--", lw=1); plt.xlabel("1 - specificity"); plt.ylabel("Sensitivity (SCLC)")
    plt.title("Patient-level ROC, pooled out-of-fold (n = 355, 38 SCLC)", fontsize=9); plt.legend(fontsize=6.5, loc="lower right"); plt.tight_layout()
    plt.savefig(FIG / "fig_roc_main.png", dpi=300); plt.close()

    # ---------------- forest plot of AUCs
    rows = []
    for p in sorted(RESULTS.iterdir()):
        mp = p / "eval" / "metrics.json"
        if mp.exists() and not p.name.startswith("debug"):
            m = json.load(open(mp))
            rows.append({"name": p.name, "auc": m["auc"]["value"], "lo": m["auc"]["delong_ci"][0], "hi": m["auc"]["delong_ci"][1], "n": m["n_patients"], "n_sclc": m["n_sclc"]})
    df = pd.DataFrame(rows)
    order = [n for n in LABELS if n in set(df["name"])] + [n for n in df["name"] if n not in LABELS]
    df = df.set_index("name").loc[order].reset_index()
    fig, ax = plt.subplots(figsize=(8.5, 0.32 * len(df) + 1.2))
    y = np.arange(len(df))[::-1]
    ax.errorbar(df["auc"], y, xerr=[df["auc"] - df["lo"], df["hi"] - df["auc"]], fmt="o", color="tab:blue", ecolor="gray", capsize=2)
    ax.axvline(0.5, color="k", lw=0.8, ls=":")
    ax.set_yticks(y); ax.set_yticklabels([f"{LABELS.get(n, n)[:62]}  (n={r.n}, SCLC={r.n_sclc})" for n, r in zip(df["name"], df.itertuples())], fontsize=7)
    ax.set_xlabel("AUC (DeLong 95% CI), pooled out-of-fold"); ax.set_xlim(0.35, 1.0); ax.grid(axis="x", alpha=0.3)
    fig.tight_layout(); fig.savefig(FIG / "fig_ablation_auc.png", dpi=300); plt.close(fig)
    df.to_csv(FIG / "auc_forest_data.csv", index=False)

    # ---------------- calibration + DCA for ensemble and main
    fig, axes = plt.subplots(1, 2, figsize=(9, 4))
    for name, color in [(args.ensemble, "tab:red"), (args.main, "tab:blue")]:
        if not (RESULTS / name / "eval" / "metrics.json").exists():
            continue
        d, m = load(name); d = d[d["rep"] == 0]; y_ = d["label"].values; p_ = d["prob_cal"].values
        bins = np.quantile(p_, np.linspace(0, 1, 9)); bins[0] = 0; bins[-1] = 1
        idx = np.clip(np.digitize(p_, bins[1:-1]), 0, 7)
        xs = [p_[idx == b].mean() for b in range(8) if (idx == b).any()]; ys = [y_[idx == b].mean() for b in range(8) if (idx == b).any()]
        ns = [(idx == b).sum() for b in range(8) if (idx == b).any()]
        axes[0].errorbar(xs, ys, yerr=[1.96 * np.sqrt(max(o * (1 - o), 1e-6) / n) for o, n in zip(ys, ns)], fmt="o-", color=color, capsize=3,
                         label=f"{LABELS.get(name, name)[:40]}\nslope {m['calibration']['calibration_slope']['value']:.2f}, intercept {m['calibration']['calibration_intercept']['value']:.2f}, Brier {m['calibration']['brier']['value']:.3f}")
        dca = m["dca"]; axes[1].plot(dca["thresholds"], dca["net_benefit_model"], color=color, lw=2, label=LABELS.get(name, name)[:40])
        if name == args.ensemble:
            axes[1].plot(dca["thresholds"], dca["net_benefit_treat_all"], "k--", lw=1.2, label="treat all as SCLC"); axes[1].axhline(0, color="k", lw=0.8, label="treat none")
    axes[0].plot([0, 1], [0, 1], "k--", lw=1); axes[0].set_xlabel("Predicted probability of SCLC"); axes[0].set_ylabel("Observed SCLC fraction"); axes[0].set_title("Calibration (quantile bins)", fontsize=9); axes[0].legend(fontsize=6)
    axes[1].set_xlabel("Threshold probability"); axes[1].set_ylabel("Net benefit"); axes[1].set_title("Decision curve", fontsize=9); axes[1].legend(fontsize=6); axes[1].set_ylim(-0.02, 0.13)
    fig.tight_layout(); fig.savefig(FIG / "fig_calibration_dca.png", dpi=300); plt.close(fig)

    # ---------------- operating points
    names = [n for n in [args.ensemble, args.main, "ft_ctx", "final_b0_ct_only", "baseline_ctpet_handcrafted_logreg"] if (RESULTS / n / "eval" / "metrics.json").exists()]
    fig, ax = plt.subplots(figsize=(7.5, 3.4)); w = 0.2; x = np.arange(len(names))
    for j, (key, lab) in enumerate([("thr_youden", "Youden"), ("thr_sens80", "sens>=0.80 target")]):
        sens = []; spec = []; es = []; ep = []
        for n in names:
            m = json.load(open(RESULTS / n / "eval" / "metrics.json"))["operating_points"][key]
            sens.append(m["sensitivity"]["value"]); spec.append(m["specificity"]["value"])
            es.append([m["sensitivity"]["value"] - m["sensitivity"]["ci"][0], m["sensitivity"]["ci"][1] - m["sensitivity"]["value"]])
            ep.append([m["specificity"]["value"] - m["specificity"]["ci"][0], m["specificity"]["ci"][1] - m["specificity"]["value"]])
        ax.bar(x + (2 * j - 1.5) * w, sens, w, yerr=np.array(es).T, capsize=2, label=f"Sensitivity @ {lab}", color=["tab:red", "tab:orange"][j])
        ax.bar(x + (2 * j - 0.5) * w, spec, w, yerr=np.array(ep).T, capsize=2, label=f"Specificity @ {lab}", color=["tab:blue", "tab:cyan"][j])
    ax.set_xticks(x); ax.set_xticklabels([LABELS.get(n, n)[:28] for n in names], fontsize=7, rotation=12); ax.set_ylim(0, 1.05); ax.legend(fontsize=6, ncol=2)
    ax.set_title("Frozen operating points (thresholds chosen on inner folds)", fontsize=9); fig.tight_layout(); fig.savefig(FIG / "fig_operating_points.png", dpi=300); plt.close(fig)
    print("figures written to", FIG)


if __name__ == "__main__":
    main()
