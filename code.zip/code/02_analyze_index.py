"""
Step 2: Summarise the DICOM index per series and per patient, and work out how
annotations, PET series and CT series relate to each other.

Outputs (revision_experiments/index/):
  series_summary.csv    one row per series
  patient_summary.csv   one row per patient
Prints diagnostics used to design the cohort/series selection rules.
"""
from pathlib import Path
import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
IDX = HERE / "index"

pd.set_option("display.width", 200)
pd.set_option("display.max_columns", 40)
pd.set_option("display.max_rows", 200)

dcm = pd.read_csv(IDX / "dicom_index.csv", dtype=str, keep_default_na=False)
ann = pd.read_csv(IDX / "annotations.csv", dtype=str, keep_default_na=False)
print(f"DICOM rows: {len(dcm)}  annotation rows: {len(ann)}")

for c in ["ipp_z", "spacing_row", "spacing_col", "slice_thickness", "rows", "cols", "instance_number"]:
    dcm[c] = pd.to_numeric(dcm[c], errors="coerce")

dcm["pid_short"] = dcm["pid"].str.replace("Lung_Dx-", "", regex=False).str.strip()
dcm["group"] = dcm["pid_short"].str[0]
ann["sop_uid"] = ann["sop_uid"].str.strip()
ann_sops = set(ann.loc[ann["xmin"] != "", "sop_uid"])
dcm["annotated"] = dcm["sop_uid"].isin(ann_sops)

# ---------------------------------------------------------------- series level
g = dcm.groupby("series_uid")
series = g.agg(
    pid=("pid_short", "first"),
    group=("group", "first"),
    study_uid=("study_uid", "first"),
    study_desc=("study_desc", "first"),
    study_date=("study_date", "first"),
    series_desc=("series_desc", "first"),
    series_number=("series_number", "first"),
    modality=("modality", "first"),
    n_files=("sop_uid", "size"),
    n_sops=("sop_uid", "nunique"),
    n_annotated=("annotated", "sum"),
    for_uid=("for_uid", "first"),
    manufacturer=("manufacturer", "first"),
    model=("model", "first"),
    kernel=("kernel", "first"),
    kvp=("kvp", "first"),
    slice_thickness=("slice_thickness", "median"),
    spacing_row=("spacing_row", "median"),
    rows=("rows", "median"),
    cols=("cols", "median"),
    z_min=("ipp_z", "min"),
    z_max=("ipp_z", "max"),
    n_z=("ipp_z", "nunique"),
    units=("units", "first"),
    image_type=("image_type", "first"),
    body_part=("body_part", "first"),
    contrast=("contrast_agent", "first"),
    photometric=("photometric", "first"),
    bits=("bits_stored", "first"),
).reset_index()
series["z_extent_mm"] = series["z_max"] - series["z_min"]
series["is_pet_study"] = series["study_desc"].str.contains("PET", case=False, na=False)
series.to_csv(IDX / "series_summary.csv", index=False)

print("\n=== Series by modality ===")
print(series["modality"].value_counts())
print("\n=== Non CT/PT series descriptions (if any) ===")
print(series.loc[~series["modality"].isin(["CT", "PT"]), ["pid", "modality", "series_desc", "n_files"]].head(30))

print("\n=== Annotated SOPs by modality ===")
print(dcm.loc[dcm["annotated"]].groupby("modality").size())
print("Annotation SOPs not found in any DICOM:", len(ann_sops - set(dcm["sop_uid"])))

print("\n=== Annotated slices by (modality, is_pet_study) ===")
print(dcm.loc[dcm["annotated"]].merge(series[["series_uid", "is_pet_study"]], on="series_uid")
      .groupby(["modality", "is_pet_study"]).size())

print("\n=== Series with annotations: top descriptions ===")
print(series.loc[series["n_annotated"] > 0].groupby(["modality", "series_desc"]).agg(
    n_series=("series_uid", "size"), n_ann=("n_annotated", "sum")).sort_values("n_ann", ascending=False).head(30))

# ------------------------------------------------------------- PET geometry
pet = series[series["modality"] == "PT"].copy()
print(f"\n=== PET series: {len(pet)} in {pet['pid'].nunique()} patients ===")
print(pet[["rows", "cols", "spacing_row", "slice_thickness", "n_files", "n_z", "z_extent_mm", "units"]].describe())
print("PET units:", pet["units"].value_counts().to_dict())
print("PET models:", pet["model"].value_counts().to_dict())

# For every PET series: CT series in the same study / same frame of reference
ct = series[series["modality"] == "CT"].copy()
rows = []
for _, p in pet.iterrows():
    same_study = ct[ct["study_uid"] == p["study_uid"]]
    same_for = ct[(ct["for_uid"] == p["for_uid"]) & (p["for_uid"] != "")]
    rows.append({
        "pid": p["pid"], "pet_series": p["series_uid"], "pet_n": p["n_files"],
        "n_ct_same_study": len(same_study), "n_ct_same_for": len(same_for),
        "ct_same_study_desc": " | ".join(same_study["series_desc"].tolist()),
        "ct_same_for_desc": " | ".join(same_for["series_desc"].tolist()),
        "ct_same_study_annotated": int((same_study["n_annotated"] > 0).sum()),
        "ct_same_for_annotated": int((same_for["n_annotated"] > 0).sum()),
    })
petct = pd.DataFrame(rows)
petct.to_csv(IDX / "pet_ct_pairing.csv", index=False)
print("\n=== PET/CT pairing ===")
print(petct[["n_ct_same_study", "n_ct_same_for", "ct_same_study_annotated", "ct_same_for_annotated"]].describe())
print("PET with >=1 CT in same frame of reference:", int((petct["n_ct_same_for"] > 0).sum()))
print("PET with >=1 annotated CT in same study:", int((petct["ct_same_study_annotated"] > 0).sum()))
print("PET with >=1 annotated CT in same FoR:", int((petct["ct_same_for_annotated"] > 0).sum()))
print(petct["ct_same_for_desc"].value_counts().head(15))

# ------------------------------------------------------------ patient level
pat_rows = []
for pid, sp in series.groupby("pid"):
    cts = sp[sp["modality"] == "CT"]
    pts = sp[sp["modality"] == "PT"]
    ann_ct = cts[cts["n_annotated"] > 0]
    pat_rows.append({
        "pid": pid, "group": sp["group"].iloc[0],
        "n_studies": sp["study_uid"].nunique(),
        "n_ct_series": len(cts), "n_pt_series": len(pts),
        "has_pet": len(pts) > 0,
        "n_annotated_ct_series": len(ann_ct),
        "n_annotated_ct_slices": int(cts["n_annotated"].sum()),
        "n_annotated_pt_slices": int(pts["n_annotated"].sum()),
        "best_ann_ct_desc": ann_ct.sort_values("n_annotated", ascending=False)["series_desc"].iloc[0] if len(ann_ct) else "",
        "best_ann_ct_n": int(ann_ct["n_annotated"].max()) if len(ann_ct) else 0,
        "best_ann_ct_thickness": ann_ct.sort_values("n_annotated", ascending=False)["slice_thickness"].iloc[0] if len(ann_ct) else np.nan,
        "best_ann_ct_in_pet_study": bool(ann_ct.sort_values("n_annotated", ascending=False)["is_pet_study"].iloc[0]) if len(ann_ct) else False,
        "manufacturers": "|".join(sorted(set(cts["manufacturer"]))),
    })
patients = pd.DataFrame(pat_rows)
patients.to_csv(IDX / "patient_summary.csv", index=False)

print("\n=== Patients ===")
print("total:", len(patients), "by group:", patients["group"].value_counts().to_dict())
print("with PET by group:", patients[patients["has_pet"]]["group"].value_counts().to_dict())
print("with any annotated CT slice:", int((patients["n_annotated_ct_slices"] > 0).sum()))
print("with annotated CT by group:", patients[patients["n_annotated_ct_slices"] > 0]["group"].value_counts().to_dict())
print("with PET and annotated CT:", int(((patients["has_pet"]) & (patients["n_annotated_ct_slices"] > 0)).sum()))
print("with PET, annotated CT inside the PET study:", int(((patients["has_pet"]) & (patients["best_ann_ct_in_pet_study"])).sum()))
print("\nannotated slices per patient (CT):")
print(patients["n_annotated_ct_slices"].describe())
print("\nbest annotated CT thickness distribution:")
print(patients["best_ann_ct_thickness"].value_counts().sort_index())
print("\nCT manufacturers per patient:")
print(patients["manufacturers"].value_counts())
print("\nSCLC (B) patients detail:")
print(patients[patients["group"] == "B"][["pid", "has_pet", "n_ct_series", "n_annotated_ct_slices", "best_ann_ct_desc", "best_ann_ct_thickness", "best_ann_ct_in_pet_study"]])
