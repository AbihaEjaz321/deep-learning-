"""
Step 18: clinico-radiological models under the full nested protocol (same outer folds as all imaging runs).
  stage_TN_logreg        : logistic regression on T stage (with a/b/c sub-stage) and N stage only
  fusion_img_TN          : equal-weight average of z-scored logits of the imaging OOF ensemble (ens_ft_frz_platt) and
                           the T/N logistic model; z-scoring, Platt recalibration and thresholds are all fitted on the
                           inner-fold predictions of the outer-training patients (no weight is learned on test folds).
Histological grade is excluded (G3 is definitional for SCLC). M stage and demographics are excluded (no signal).
Writes results/<name>/ in the standard format so 05_evaluate.py / 09_summary.py can be used.
"""
import json
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import RepeatedStratifiedKFold, StratifiedKFold
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

from common import select_thresholds, HERE

RESULTS = HERE / "results"
IMG = "ens_ft_frz_platt"


def logit(p):
    p = np.clip(np.asarray(p, float), 1e-4, 1 - 1e-4); return np.log(p / (1 - p))


def fit_platt(x, y, l2=1e-3):
    a, b = 1.0, 0.0
    for _ in range(200):
        z = a * x + b; p = 1 / (1 + np.exp(-z)); w = p * (1 - p) + 1e-9
        g = np.array([np.sum((p - y) * x) + l2 * (a - 1), np.sum(p - y)]); H = np.array([[np.sum(w * x * x) + l2, np.sum(w * x)], [np.sum(w * x), np.sum(w)]])
        step = np.linalg.solve(H, g); a -= step[0]; b -= step[1]
        if np.abs(step).max() < 1e-8:
            break
    return a, b


clin = pd.read_excel(HERE / "index" / "statistics-clinical-20201221.xlsx")
clin.columns = [str(c).strip() for c in clin.columns]
clin = clin.rename(columns={"NewPatientID": "pid", "T-Stage": "T", "N-Stage": "N"})
clin["T_score"] = pd.to_numeric(clin["T"].astype(str).str.extract(r"(\d)")[0], errors="coerce") + clin["T"].astype(str).str.extract(r"\d([abc])")[0].map({"a": 0.0, "b": 0.33, "c": 0.66}).fillna(0.0)
clin["N_num"] = pd.to_numeric(clin["N"].astype(str).str.extract(r"(\d)")[0], errors="coerce")
img = pd.read_csv(RESULTS / IMG / "oof_predictions.csv"); img = img[img["rep"] == 0].reset_index(drop=True)
df = img.merge(clin[["pid", "T_score", "N_num"]], on="pid", how="left")
y = df["label"].values; cols = ["T_score", "N_num"]
out = {"stage_TN_logreg": [], "fusion_img_TN": []}; finfo = {k: [] for k in out}
for fold in sorted(int(f) for f in df["fold"].unique()):      # reuse the imaging run's outer folds exactly
    te = np.flatnonzero(df["fold"].values == fold); tr = np.flatnonzero(df["fold"].values != fold)
    img_inner = pd.read_csv(RESULTS / IMG / f"inner_oof_r0f{fold}.csv").set_index("pid")
    X = df[cols]; med = X.iloc[tr].median()
    # inner 3-fold clinical OOF logits for the outer-training patients
    inner = StratifiedKFold(3, shuffle=True, random_state=42 + fold); c_in = np.zeros(len(tr))
    for itr, iva in inner.split(np.zeros(len(tr)), y[tr]):
        m = make_pipeline(StandardScaler(), LogisticRegression(C=0.3, class_weight="balanced", max_iter=2000)).fit(X.iloc[tr[itr]].fillna(med), y[tr[itr]])
        c_in[iva] = logit(m.predict_proba(X.iloc[tr[iva]].fillna(med))[:, 1])
    m_full = make_pipeline(StandardScaler(), LogisticRegression(C=0.3, class_weight="balanced", max_iter=2000)).fit(X.iloc[tr].fillna(med), y[tr])
    c_te = logit(m_full.predict_proba(X.iloc[te].fillna(med))[:, 1])
    i_in = logit(img_inner.loc[df.iloc[tr]["pid"], "prob_cal"].values); i_te = logit(df.iloc[te]["prob_cal"].values)
    # z-score parameters from inner predictions only
    mu_c, sd_c, mu_i, sd_i = c_in.mean(), c_in.std() + 1e-9, i_in.mean(), i_in.std() + 1e-9
    f_in = 0.5 * ((c_in - mu_c) / sd_c + (i_in - mu_i) / sd_i); f_te = 0.5 * ((c_te - mu_c) / sd_c + (i_te - mu_i) / sd_i)
    for name, z_in, z_te in [("stage_TN_logreg", c_in, c_te), ("fusion_img_TN", f_in, f_te)]:
        a, b = fit_platt(z_in, y[tr]); p_in = 1 / (1 + np.exp(-(a * z_in + b))); p_te = 1 / (1 + np.exp(-(a * z_te + b)))
        thr = select_thresholds(p_in, y[tr], 0.80)
        pd.DataFrame({"pid": df.iloc[tr]["pid"].values, "label": y[tr], "rep": 0, "fold": fold, "logit": z_in, "prob_cal": p_in}).to_csv(RESULTS / name / f"inner_oof_r0f{fold}.csv", index=False) if (RESULTS / name).mkdir(parents=True, exist_ok=True) is None else None
        finfo[name].append({"rep": 0, "fold": fold, "platt_a": a, "platt_b": b, "thresholds": thr, "inner_oof_auc": float(roc_auc_score(y[tr], z_in)), "test_auc": float(roc_auc_score(y[te], z_te)), "temperature": 1.0})
        for k, idx in enumerate(te):
            r = df.iloc[idx]
            out[name].append({"pid": r["pid"], "label": int(r["label"]), "group": r["group"], "rep": 0, "fold": fold, "prob_cal": float(p_te[k]), "prob_raw": float(p_te[k]),
                              "logit_mean": float(z_te[k]), "temperature": 1.0, "thr_youden": thr["youden"], "thr_f1max": thr["f1max"], "thr_sens80": thr["sens80"],
                              "has_pet": bool(r["has_pet"]), "pet_used": bool(r["has_pet"]), "manufacturer": r["manufacturer"], "n_slices": r["n_slices"], "fallback_roi": bool(r["fallback_roi"])})
for name in out:
    d = pd.DataFrame(out[name]); d.to_csv(RESULTS / name / "oof_predictions.csv", index=False)
    cfg = {"name": name, "fusion": name, "cohort": "all", "loss": "n/a", "lomo": None, "view": "n/a", "geom": False, "inner": 3, "repeats": 1, "backbone": "clinical" if name.startswith("stage") else f"late-fusion:{IMG}+T/N", "no_pet": False, "final_eval_slices": 0}
    json.dump({"config": cfg, "folds": finfo[name]}, open(RESULTS / name / "folds.json", "w"), indent=1)
    yy = d["label"].values; p = d["prob_cal"].values; pred = (p >= d["thr_youden"].values).astype(int); pred80 = (p >= d["thr_sens80"].values).astype(int)
    sens = lambda pr: ((pr == 1) & (yy == 1)).sum() / (yy == 1).sum(); spec = lambda pr: ((pr == 0) & (yy == 0)).sum() / (yy == 0).sum()
    print(f"{name:18s} AUC={roc_auc_score(yy, p):.3f} | Youden sens={sens(pred):.3f} spec={spec(pred):.3f} | sens80-target sens={sens(pred80):.3f} spec={spec(pred80):.3f} | inner-OOF AUC mean={np.mean([f['inner_oof_auc'] for f in finfo[name]]):.3f}")
