"""Smoke test: data pipeline + every model variant on the GPU using a small cache directory."""
import sys
import time
import numpy as np
import torch
from torch.utils.data import DataLoader

from common import load_cohort, BagDataset, collate_bags, MILFusionNet, WeightedFocalLoss, predict

cache_dir = sys.argv[1] if len(sys.argv) > 1 else "cache_test"
recs = load_cohort(cache_dir=cache_dir, verbose=False)
print("records:")
for r in recs:
    print(f"  {r.pid} label={r.label} pet={r.has_pet} n={r.n_slices} ct={r.ct.shape} pet_arr={None if r.pet is None else r.pet.shape} "
          f"box0={r.boxes[0].round(1).tolist()} manuf={r.manufacturer} pet_mode={r.pet_mode}")
ds = BagDataset(recs, bag_size=8, train=True, use_pet=True, modality_dropout=0.25, seed=1)
t = time.time(); batch = collate_bags([ds[i] for i in range(len(ds))]); print(f"batch build {time.time() - t:.2f}s")
ct, pt, pm, mask, y, pids, idx = batch
print("ct", tuple(ct.shape), "pt", tuple(pt.shape), "pet_mask", pm.tolist(), "mask", tuple(mask.shape), "y", y.tolist())
print("ct range", ct.min().item(), ct.max().item(), "| pet range", pt.min().item(), pt.max().item(),
      "| pet mean where present", pt[pm].mean().item() if pm.any() else None)
dev = torch.device("cuda")
for fusion in ["xattn", "concat", "ct_only", "pet_only", "early"]:
    m = MILFusionNet(fusion=fusion).to(dev)
    nparam = sum(p.numel() for p in m.parameters()) / 1e6
    torch.cuda.reset_peak_memory_stats()
    with torch.autocast("cuda", dtype=torch.bfloat16):
        t = time.time(); logit, a, xw = m(ct.to(dev), pt.to(dev), pm.to(dev), mask.to(dev)); torch.cuda.synchronize(); fwd = time.time() - t
    loss = WeightedFocalLoss()(logit.float(), y.to(dev)); loss.backward()
    print(f"{fusion:8s} params={nparam:.2f}M logits={tuple(logit.shape)} attn={tuple(a.shape)} loss={loss.item():.4f} "
          f"fwd={fwd * 1000:.0f}ms peak_mem={torch.cuda.max_memory_allocated() / 1e9:.2f}GB")
    m = None; torch.cuda.empty_cache()
m = MILFusionNet(fusion="xattn").to(dev)
t = time.time(); out = predict(m, recs, dev, return_attention=True)
print(f"predict {time.time() - t:.2f}s")
for o in out:
    print("  ", o["pid"], round(o["logit"], 3), o["pet_used"], o["n_slices_eval"], np.round(o["attention"][:4], 3).tolist())
# timing of a training-style step loop
loader = DataLoader(ds, batch_size=4, shuffle=True, collate_fn=collate_bags)
opt = torch.optim.AdamW(m.parameters(), lr=1e-4)
t = time.time(); n = 0
for ct, pt, pm, mask, y, _, _ in loader:
    with torch.autocast("cuda", dtype=torch.bfloat16):
        logit, _, _ = m(ct.to(dev), pt.to(dev), pm.to(dev), mask.to(dev))
    loss = WeightedFocalLoss()(logit.float(), y.to(dev)); opt.zero_grad(); loss.backward(); opt.step(); n += 1
torch.cuda.synchronize(); print(f"{n} train steps (batch 4 x K8) in {time.time() - t:.2f}s")
print("SMOKE TEST OK")
