"""
Step 17: how much do clinical covariates add? (age, sex, weight, smoking, T stage, N stage, M stage; histological
grade is EXCLUDED because G3 is definitional for SCLC = label leakage).
  (a) clinical-only logistic regression under the same nested CV (same outer folds as the imaging models)
  (b) leakage-free late fusion: equal-weight average of the z-scored imaging logit (Platt-recalibrated OOF) and the
      clinical OOF logit - no weights are fitted, so nothing is learned from test patients.
"""
import json
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import RepeatedStratifiedKFold
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

HERE = Path(__file__).resolve().parent
RESULTS = HERE / "results"

clin = pd.read_excel(HERE / "index" / "statistics-clinical-20201221.xlsx")
clin.columns = [str(c).strip() for c in clin.columns]
clin = clin.rename(columns={"NewPatientID": "pid", "weight (kg)": "weight", "T-Stage": "T", "N-Stage": "N", "Ｍ-Stage": "M", "M-Stage": "M", "Smoking History": "smoking"})
clin["T_num"] = pd.to_numeric(clin["T"].astype(str).str.extract(r"(\d)")[0], errors="coerce")
clin["T_sub"] = clin["T"].astype(str).str.extract(r"\d([abc])")[0].map({"a": 0.0, "b": 0.33, "c": 0.66}).fillna(0.0)
clin["T_score"] = clin["T_num"] + clin["T_sub"]
clin["N_num"] = pd.to_numeric(clin["N"].astype(str).str.extract(r"(\d)")[0], errors="coerce")
clin["M_bin"] = (pd.to_numeric(clin["M"].astype(str).str.extract(r"(\d)")[0], errors="coerce") > 0).astype(float)
clin["sex_m"] = (clin["Sex"].astype(str).str.upper().str.startswith("M")).astype(float)
for c in ["Age", "weight", "smoking"]:
    clin[c] = pd.to_numeric(clin[c], errors="coerce")

main = pd.read_csv(RESULTS / "ens_ft_frz_platt" / "oof_predictions.csv")      # imaging ensemble, rep 0, 355 patients
main = main[main["rep"] == 0][["pid", "label", "fold", "prob_cal"]].rename(columns={"prob_cal": "p_img"})
df = main.merge(clin, on="pid", how="left")
df["img_logit"] = np.log(np.clip(df["p_img"], 1e-4, 1 - 1e-4) / (1 - np.clip(df["p_img"], 1e-4, 1 - 1e-4)))
y = df["label"].values
sets = {
    "demographics (age, sex, weight, smoking)": ["Age", "sex_m", "weight", "smoking"],
    "T + N stage only": ["T_score", "N_num"],
    "T + N + M stage": ["T_score", "N_num", "M_bin"],
    "demographics + T N M": ["Age", "sex_m", "weight", "smoking", "T_score", "N_num", "M_bin"],
}
rskf = RepeatedStratifiedKFold(n_splits=5, n_repeats=1, random_state=42)   # same outer folds as every imaging run
print(f"n={len(df)} SCLC={int(y.sum())}; imaging ensemble OOF AUC = {roc_auc_score(y, df['p_img']):.3f}")
print("N stage distribution SCLC vs NSCLC:", df.groupby("label")["N_num"].value_counts(normalize=True).round(2).unstack().to_string())
for name, cols in sets.items():
    X = df[cols].copy(); oof = np.zeros(len(df))
    for tr, te in rskf.split(X, y):
        med = X.iloc[tr].median()
        pipe = make_pipeline(StandardScaler(), LogisticRegression(C=0.3, class_weight="balanced", max_iter=2000))
        pipe.fit(X.iloc[tr].fillna(med), y[tr]); p = pipe.predict_proba(X.iloc[te].fillna(med))[:, 1]
        oof[te] = np.log(np.clip(p, 1e-4, 1 - 1e-4) / (1 - np.clip(p, 1e-4, 1 - 1e-4)))
    auc_c = roc_auc_score(y, oof)
    z_img = (df["img_logit"] - df["img_logit"].mean()) / df["img_logit"].std(); z_c = (oof - oof.mean()) / oof.std()
    auc_fuse = roc_auc_score(y, z_img + z_c)
    print(f"{name:42s} clinical-only AUC={auc_c:.3f} | equal-weight late fusion with imaging AUC={auc_fuse:.3f}")
