"""Inference latency of the fine-tuned model (all candidate slices per patient, flip TTA off and on) on the local GPU."""
import json
import time
import numpy as np
import torch

from common import BagDataset, MILFusionNet, load_cohort, HERE, VIEWS

name = "ft_ctx"; device = torch.device("cuda")
cfg = json.load(open(HERE / "results" / name / "folds.json"))["config"]
model = MILFusionNet(cfg["backbone"], fusion=cfg["fusion"], pretrained=False, views=len(VIEWS[cfg["view"]]))
sd = torch.load(HERE / "results" / name / "models" / "r0f0i0.pt", map_location="cpu")
model.load_state_dict({k: v.float() if v.is_floating_point() else v for k, v in sd.items()}); model = model.to(device).eval()
recs = load_cohort(verbose=False)[:60]
ds = BagDataset(recs, train=False, use_pet=True, eval_max_slices=48, view=cfg["view"])
n_params = sum(p.numel() for p in model.parameters()) / 1e6
times, slices, prep = [], [], []
with torch.no_grad():
    for i in range(len(ds)):
        t0 = time.perf_counter(); ct, pt, pm, y, pid, ks, geom = ds[i]; prep.append(time.perf_counter() - t0)
        ct = ct.unsqueeze(0).to(device); pt = pt.unsqueeze(0).to(device); pm = pm.view(1).to(device); geom = geom.view(1, -1).to(device)
        mask = torch.ones(1, ct.shape[1], dtype=torch.bool, device=device)
        for _ in range(2):   # warm-up
            with torch.autocast("cuda", dtype=torch.bfloat16):
                model(ct, pt, pm, mask, geom)
        torch.cuda.synchronize(); t0 = time.perf_counter()
        with torch.autocast("cuda", dtype=torch.bfloat16):
            model(ct, pt, pm, mask, geom); model(torch.flip(ct, dims=[-1]), torch.flip(pt, dims=[-1]), pm, mask, geom)
        torch.cuda.synchronize(); times.append(time.perf_counter() - t0); slices.append(ct.shape[1])
times = np.array(times) * 1000; slices = np.array(slices); prep = np.array(prep) * 1000
print(f"model params {n_params:.2f} M; GPU {torch.cuda.get_device_name(0)}")
print(f"GPU inference per patient (both TTA passes, median slices {np.median(slices):.0f}): median {np.median(times):.1f} ms, p90 {np.percentile(times, 90):.1f} ms")
print(f"per slice-equivalent: {np.median(times / slices):.2f} ms; CPU crop/window preparation per patient: median {np.median(prep):.0f} ms")
