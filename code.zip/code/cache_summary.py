"""Summarise the built cache: slices per patient, PET alignment modes / Dice, SUV availability; write index/cache_summary.csv."""
import json
from pathlib import Path
import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
rows = []
for mp in sorted((HERE / "cache").glob("*/meta.json")):
    m = json.load(open(mp, encoding="utf-8"))
    pet = m.get("pet", {}) or {}
    rows.append({"pid": m["pid"], "group": m["group"], "label": m["label"], "ct_desc": m["ct_desc"], "ct_manufacturer": m.get("ct_manufacturer", ""),
                 "ct_kernel": m.get("ct_kernel", ""), "dz_native": m["ct_dz_native"], "dz_effective": m["ct_effective_dz"],
                 "n_total": m["ct_n_slices_total"], "n_cand": len(m["candidate_idx"]), "n_ann_series": m["n_annotated_slices_in_series"],
                 "n_ann_patient": m["n_annotated_slices_patient"], "cand_mode": m["candidate_mode"], "has_pet": m["has_pet"],
                 "pet_mode": pet.get("mode", ""), "dice_geometry": pet.get("dice_geometry", np.nan), "dice_registered": pet.get("dice_registered", np.nan),
                 "dice_final": pet.get("dice_final", np.nan), "suv_mode": pet.get("suv_mode", ""), "uptake_min": (pet.get("uptake_s", np.nan) or np.nan) / 60.0,
                 "max_suv": m.get("pet_max_suv_in_candidates", np.nan), "n_boxes_total": sum(len(s["boxes"]) for s in m["slices"]),
                 "box_labels": "|".join(sorted({b[4] for s in m["slices"] for b in s["boxes"]})), "seconds": m.get("seconds", np.nan)})
df = pd.DataFrame(rows)
df.to_csv(HERE / "index" / "cache_summary.csv", index=False)
pd.set_option("display.width", 220); pd.set_option("display.max_columns", 30)
print("patients:", len(df), " by group:", df["group"].value_counts().to_dict(), " with PET:", int(df["has_pet"].sum()))
print("\ncandidate slices per patient:\n", df["n_cand"].describe().round(1).to_string())
print("\nby PET availability and class (n_cand mean):\n", df.groupby(["has_pet", "label"])["n_cand"].agg(["count", "mean", "min", "max"]).round(1))
print("\neffective slice thickness:\n", df["dz_effective"].round(1).value_counts().sort_index().to_string())
print("\nCT manufacturer x label:\n", pd.crosstab(df["ct_manufacturer"], df["label"]))
print("\nCT kernel (top):\n", df["ct_kernel"].value_counts().head(12).to_string())
p = df[df["has_pet"]]
print("\nPET alignment modes:\n", p["pet_mode"].value_counts().to_string())
print("\nDice final:\n", p["dice_final"].describe().round(3).to_string())
print("Dice geometry vs registered (where tried):\n", p.loc[p["dice_registered"].notna(), ["dice_geometry", "dice_registered", "dice_final"]].describe().round(3))
print("\nSUV mode:", p["suv_mode"].value_counts().to_dict(), " uptake min (median, IQR):", p["uptake_min"].median(), p["uptake_min"].quantile([.25, .75]).tolist())
print("max SUV in candidates:\n", p["max_suv"].describe().round(2).to_string())
print("\nlow Dice (<0.65) patients:\n", p.loc[p["dice_final"] < 0.65, ["pid", "pet_mode", "dice_geometry", "dice_registered", "dice_final", "max_suv"]].to_string())
print("\nbox label mismatches (box label != patient group):\n", df.loc[df["box_labels"] != df["group"], ["pid", "group", "box_labels"]].head(20).to_string())
print("\nannotation coverage: patients with n_ann_series < 3:", int((df["n_ann_series"] < 3).sum()))
