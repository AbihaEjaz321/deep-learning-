"""
Step 1: Build a per-file DICOM header index and parse all annotation XML files
for the Lung-PET-CT-Dx collection.

Outputs (in revision_experiments/index/):
  dicom_index.csv      one row per DICOM file with geometry + acquisition metadata
  annotations.csv      one row per annotated bounding box (pid, sop_uid, label, box)
  series_summary.csv   one row per series with counts and annotation coverage
"""
import os
import sys
import csv
import time
import xml.etree.ElementTree as ET
from pathlib import Path
from multiprocessing import Pool, cpu_count

import pydicom
from pydicom.tag import Tag

DATA_ROOT = Path(r"D:\LungPETCTDx")
IMG_ROOT = DATA_ROOT / "Lung-PET-CT-Dx" / "Lung-PET-CT-Dx"
ANN_ROOT = DATA_ROOT / "Annotation" / "Annotation"
OUT_DIR = Path(__file__).resolve().parent / "index"
OUT_DIR.mkdir(parents=True, exist_ok=True)

TAGS = [
    "PatientID", "PatientSex", "PatientAge", "PatientWeight",
    "StudyInstanceUID", "StudyDescription", "StudyDate",
    "SeriesInstanceUID", "SeriesDescription", "SeriesNumber", "SeriesTime", "AcquisitionTime",
    "SOPInstanceUID", "Modality", "InstanceNumber",
    "ImagePositionPatient", "ImageOrientationPatient", "PixelSpacing", "SliceThickness",
    "SpacingBetweenSlices", "Rows", "Columns", "NumberOfFrames",
    "RescaleSlope", "RescaleIntercept", "RescaleType", "Units", "DecayCorrection",
    "FrameOfReferenceUID", "Manufacturer", "ManufacturerModelName", "ConvolutionKernel",
    "KVP", "BodyPartExamined", "ImageType", "PhotometricInterpretation",
    "BitsStored", "PixelRepresentation", "WindowCenter", "WindowWidth",
    "RadiopharmaceuticalInformationSequence", "CorrectedImage", "ReconstructionMethod",
    "AttenuationCorrectionMethod", "ContrastBolusAgent",
]

COLUMNS = [
    "path", "pid", "patient_sex", "patient_age", "patient_weight",
    "study_uid", "study_desc", "study_date",
    "series_uid", "series_desc", "series_number", "series_time", "acq_time",
    "sop_uid", "modality", "instance_number",
    "ipp_x", "ipp_y", "ipp_z", "iop", "spacing_row", "spacing_col", "slice_thickness",
    "spacing_between", "rows", "cols", "n_frames",
    "rescale_slope", "rescale_intercept", "rescale_type", "units", "decay_correction",
    "for_uid", "manufacturer", "model", "kernel", "kvp", "body_part", "image_type",
    "photometric", "bits_stored", "pixel_rep", "window_center", "window_width",
    "radionuclide_total_dose", "radiopharm_start_time", "radionuclide_half_life",
    "corrected_image", "recon_method", "atten_corr_method", "contrast_agent",
]


def _s(v):
    if v is None:
        return ""
    try:
        if isinstance(v, (list, tuple)) or hasattr(v, "__iter__") and not isinstance(v, (str, bytes)):
            return "\\".join(str(x) for x in v)
    except Exception:
        pass
    return str(v)


def _f(v):
    try:
        return float(v)
    except Exception:
        return ""


def read_one(path):
    try:
        ds = pydicom.dcmread(path, stop_before_pixels=True, force=True, specific_tags=TAGS)
    except Exception as exc:  # unreadable file
        return None
    ipp = getattr(ds, "ImagePositionPatient", None)
    ps = getattr(ds, "PixelSpacing", None)
    rad_dose = rad_start = rad_half = ""
    seq = getattr(ds, "RadiopharmaceuticalInformationSequence", None)
    if seq:
        try:
            item = seq[0]
            rad_dose = _s(getattr(item, "RadionuclideTotalDose", ""))
            rad_start = _s(getattr(item, "RadiopharmaceuticalStartTime", ""))
            rad_half = _s(getattr(item, "RadionuclideHalfLife", ""))
        except Exception:
            pass
    row = {
        "path": os.path.relpath(path, IMG_ROOT),
        "pid": _s(getattr(ds, "PatientID", "")),
        "patient_sex": _s(getattr(ds, "PatientSex", "")),
        "patient_age": _s(getattr(ds, "PatientAge", "")),
        "patient_weight": _s(getattr(ds, "PatientWeight", "")),
        "study_uid": _s(getattr(ds, "StudyInstanceUID", "")),
        "study_desc": _s(getattr(ds, "StudyDescription", "")),
        "study_date": _s(getattr(ds, "StudyDate", "")),
        "series_uid": _s(getattr(ds, "SeriesInstanceUID", "")),
        "series_desc": _s(getattr(ds, "SeriesDescription", "")),
        "series_number": _s(getattr(ds, "SeriesNumber", "")),
        "series_time": _s(getattr(ds, "SeriesTime", "")),
        "acq_time": _s(getattr(ds, "AcquisitionTime", "")),
        "sop_uid": _s(getattr(ds, "SOPInstanceUID", "")),
        "modality": _s(getattr(ds, "Modality", "")),
        "instance_number": _s(getattr(ds, "InstanceNumber", "")),
        "ipp_x": _f(ipp[0]) if ipp is not None and len(ipp) >= 3 else "",
        "ipp_y": _f(ipp[1]) if ipp is not None and len(ipp) >= 3 else "",
        "ipp_z": _f(ipp[2]) if ipp is not None and len(ipp) >= 3 else "",
        "iop": _s(getattr(ds, "ImageOrientationPatient", "")),
        "spacing_row": _f(ps[0]) if ps is not None and len(ps) >= 2 else "",
        "spacing_col": _f(ps[1]) if ps is not None and len(ps) >= 2 else "",
        "slice_thickness": _s(getattr(ds, "SliceThickness", "")),
        "spacing_between": _s(getattr(ds, "SpacingBetweenSlices", "")),
        "rows": _s(getattr(ds, "Rows", "")),
        "cols": _s(getattr(ds, "Columns", "")),
        "n_frames": _s(getattr(ds, "NumberOfFrames", "")),
        "rescale_slope": _s(getattr(ds, "RescaleSlope", "")),
        "rescale_intercept": _s(getattr(ds, "RescaleIntercept", "")),
        "rescale_type": _s(getattr(ds, "RescaleType", "")),
        "units": _s(getattr(ds, "Units", "")),
        "decay_correction": _s(getattr(ds, "DecayCorrection", "")),
        "for_uid": _s(getattr(ds, "FrameOfReferenceUID", "")),
        "manufacturer": _s(getattr(ds, "Manufacturer", "")),
        "model": _s(getattr(ds, "ManufacturerModelName", "")),
        "kernel": _s(getattr(ds, "ConvolutionKernel", "")),
        "kvp": _s(getattr(ds, "KVP", "")),
        "body_part": _s(getattr(ds, "BodyPartExamined", "")),
        "image_type": _s(getattr(ds, "ImageType", "")),
        "photometric": _s(getattr(ds, "PhotometricInterpretation", "")),
        "bits_stored": _s(getattr(ds, "BitsStored", "")),
        "pixel_rep": _s(getattr(ds, "PixelRepresentation", "")),
        "window_center": _s(getattr(ds, "WindowCenter", "")),
        "window_width": _s(getattr(ds, "WindowWidth", "")),
        "radionuclide_total_dose": rad_dose,
        "radiopharm_start_time": rad_start,
        "radionuclide_half_life": rad_half,
        "corrected_image": _s(getattr(ds, "CorrectedImage", "")),
        "recon_method": _s(getattr(ds, "ReconstructionMethod", "")),
        "atten_corr_method": _s(getattr(ds, "AttenuationCorrectionMethod", "")),
        "contrast_agent": _s(getattr(ds, "ContrastBolusAgent", "")),
    }
    return row


def list_dicom_files(root):
    files = []
    for dirpath, _, filenames in os.walk(root):
        for fn in filenames:
            if fn.lower().endswith(".dcm"):
                files.append(os.path.join(dirpath, fn))
    return files


def parse_annotations():
    rows = []
    n_files = 0
    for pid_dir in sorted(ANN_ROOT.iterdir()):
        if not pid_dir.is_dir():
            continue
        pid_short = pid_dir.name  # e.g. A0001
        for xml_path in pid_dir.glob("*.xml"):
            n_files += 1
            sop = xml_path.stem
            try:
                root = ET.parse(str(xml_path)).getroot()
            except Exception:
                rows.append({"pid_short": pid_short, "sop_uid": sop, "label": "", "xmin": "", "ymin": "",
                             "xmax": "", "ymax": "", "width": "", "height": "", "parse_error": 1})
                continue
            size = root.find("size")
            w = size.findtext("width") if size is not None else ""
            h = size.findtext("height") if size is not None else ""
            objs = root.findall("object")
            if not objs:
                rows.append({"pid_short": pid_short, "sop_uid": sop, "label": "", "xmin": "", "ymin": "",
                             "xmax": "", "ymax": "", "width": w, "height": h, "parse_error": 0})
            for obj in objs:
                bb = obj.find("bndbox")
                rows.append({
                    "pid_short": pid_short, "sop_uid": sop,
                    "label": (obj.findtext("name") or "").strip(),
                    "xmin": bb.findtext("xmin") if bb is not None else "",
                    "ymin": bb.findtext("ymin") if bb is not None else "",
                    "xmax": bb.findtext("xmax") if bb is not None else "",
                    "ymax": bb.findtext("ymax") if bb is not None else "",
                    "width": w, "height": h, "parse_error": 0,
                })
    print(f"Annotation XML files: {n_files}, box rows: {len(rows)}")
    return rows


def main():
    t0 = time.time()
    print("Parsing annotations ...")
    ann_rows = parse_annotations()
    with open(OUT_DIR / "annotations.csv", "w", newline="", encoding="utf-8") as f:
        wr = csv.DictWriter(f, fieldnames=["pid_short", "sop_uid", "label", "xmin", "ymin", "xmax", "ymax",
                                           "width", "height", "parse_error"])
        wr.writeheader()
        wr.writerows(ann_rows)

    print("Listing DICOM files ...")
    files = list_dicom_files(IMG_ROOT)
    print(f"Found {len(files)} DICOM files in {time.time() - t0:.1f}s")

    n_workers = max(4, min(cpu_count() // 2, 12))   # keep the laptop responsive
    print(f"Reading headers with {n_workers} workers ...")
    n_ok = 0
    n_bad = 0
    with open(OUT_DIR / "dicom_index.csv", "w", newline="", encoding="utf-8") as f:
        wr = csv.DictWriter(f, fieldnames=COLUMNS)
        wr.writeheader()
        with Pool(n_workers) as pool:
            for i, row in enumerate(pool.imap_unordered(read_one, files, chunksize=64), 1):
                if row is None:
                    n_bad += 1
                else:
                    n_ok += 1
                    wr.writerow(row)
                if i % 20000 == 0:
                    print(f"  {i}/{len(files)} ({time.time() - t0:.0f}s)", flush=True)
    print(f"Done. ok={n_ok} bad={n_bad} total={time.time() - t0:.0f}s")


if __name__ == "__main__":
    main()
