# -*- coding: utf-8 -*-
"""
Step 20: build the revised manuscript as a Word document with tracked changes (w:ins / w:del), reading every number
from the evaluation files. Input: the unpacked, run-merged original manuscript (scratchpad/manu). Output:
  <Abiha>/PLOS_ONE_Manuscript_REVISED_tracked.docx
Edits are addressed by the body-element indices printed by the structure listing (0-184) of the original document.
"""
import copy
import importlib.util
import json
import shutil
import sys
import zipfile
from pathlib import Path

import numpy as np
import pandas as pd
from lxml import etree

HERE = Path(__file__).resolve().parent
RESULTS = HERE / "results"; DOCS = HERE / "docs"
SRC = Path(r"C:\Users\acpgi\AppData\Local\Temp\claude\D--Gilanie-Data-Study-PhD-Thesis-IUB-Abiha\8cdb1a90-505e-4bf2-91da-041bb0c886bd\scratchpad\manu")
OUT_DIR = Path(r"C:\Users\acpgi\AppData\Local\Temp\claude\D--Gilanie-Data-Study-PhD-Thesis-IUB-Abiha\8cdb1a90-505e-4bf2-91da-041bb0c886bd\scratchpad\manu_rev")
OUT_DOCX = HERE.parent / "PLOS_ONE_Manuscript_REVISED_tracked.docx"

W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
XMLNS = "http://www.w3.org/XML/1998/namespace"
AUTHOR = "Revision"
DATE = "2026-10-21T09:00:00Z"
_id = [5000]


def nid():
    _id[0] += 1; return str(_id[0])


def q(t):
    return "{%s}%s" % (W, t)


# ----------------------------------------------------------------------------- numbers
def M(name):
    return json.load(open(RESULTS / name / "eval" / "metrics.json", encoding="utf-8"))


def auc_ci(m, d=2):
    return f"{m['auc']['value']:.{d}f} ({m['auc']['delong_ci'][0]:.{d}f}–{m['auc']['delong_ci'][1]:.{d}f})"


def op(m, key, k):
    return m["operating_points"][key][k]["value"]


def opci(m, key, k):
    v = m["operating_points"][key][k]; return f"{v['value']:.2f} ({v['ci'][0]:.2f}–{v['ci'][1]:.2f})"


def ss(m, key):
    return f"{op(m, key, 'sensitivity'):.2f} / {op(m, key, 'specificity'):.2f}"


def fold_auc(m):
    a = m["per_fold_mean_sd"]["auc"]
    return f"{a[0]:.2f} ± {a[1]:.2f}" if a[1] == a[1] else f"{a[0]:.2f}"


def brier(m):
    return f"{m['calibration']['brier']['value']:.3f}"


def slope_int(m):
    c = m["calibration"]; return f"{c['calibration_slope']['value']:.2f} / {c['calibration_intercept']['value']:.2f}"


def conf(m, key):
    c = m["operating_points"][key]["confusion"]; return c


ENS, FT, EARLY, FRZ, GEOM, CONCAT, CTONLY, BCE = ("ens_ft_frz_platt", "ft_ctx_platt", "ft_early_ctx_platt", "final_b0_xattn_platt",
                                                 "final_b0_xattn_geom_platt", "final_b0_concat_platt", "final_b0_ct_only_platt", "final_b0_xattn_bce_platt")
LR, GLR, STAGE, FUSE = "baseline_ctpet_handcrafted_logreg_platt", "baseline_geometry_logreg_platt", "stage_TN_logreg", "fusion_img_TN"
PX, PC, PP, PCC = "final_b0_paired_xattn_platt", "final_b0_paired_ct_only_platt", "final_b0_paired_pet_only_platt", "final_b0_paired_concat_platt"
LGE, LSI, LPH = "final_b0_lomo_GE_platt", "final_b0_lomo_SIEMENS_platt", "final_b0_lomo_Philips_platt"
m = {k: M(k) for k in [ENS, FT, EARLY, FRZ, GEOM, CONCAT, CTONLY, BCE, LR, GLR, STAGE, FUSE, PX, PC, PP, PCC, LGE, LSI, LPH]}

# paired DeLong tests computed here (rep 0, identical patients)
spec = importlib.util.spec_from_file_location("ev", HERE / "05_evaluate.py"); ev = importlib.util.module_from_spec(spec); spec.loader.exec_module(ev)


def delong(a, b):
    da = pd.read_csv(RESULTS / a / "oof_predictions.csv"); db = pd.read_csv(RESULTS / b / "oof_predictions.csv")
    da = da[da["rep"] == 0]; db = db[db["rep"] == 0]; x = da.merge(db, on="pid", suffixes=("_a", "_b"))
    a1, a2, diff, z, p = ev.delong_paired_test(x["label_a"].values, x["prob_cal_a"].values, x["prob_cal_b"].values)
    return diff, p


d_ens_ft, p_ens_ft = delong(ENS, FT); d_ens_lr, p_ens_lr = delong(ENS, LR); d_pet, p_pet = delong(FRZ, CTONLY)
d_xe, p_xe = delong(FT, EARLY); d_xc, p_xc = delong(FRZ, CONCAT); d_fu_ens, p_fu_ens = delong(FUSE, ENS); d_fu_st, p_fu_st = delong(FUSE, STAGE)
rob = pd.read_csv(RESULTS / "ft_ctx" / "robustness" / "summary.csv")
rob_shift = rob[rob["condition"] == "pet_shift"]; rob_removed = rob[rob["condition"] == "pet_removed"].iloc[0]
sub_ens = m[ENS]["subgroups"]; sub_frz = m[FRZ]["subgroups"]
cohort = pd.read_csv(DOCS / "cohort_table.csv")
TP, FN = conf(m[ENS], "thr_sens80")["tp"], conf(m[ENS], "thr_sens80")["fn"]
TPf, FNf = conf(m[FUSE], "thr_sens80")["tp"], conf(m[FUSE], "thr_sens80")["fn"]
LATENCY_PATIENT, LATENCY_SLICE = 73, 6.2   # from 19_latency.py (RTX 5090 laptop GPU, both TTA passes, median 10 slices)


# ----------------------------------------------------------------------------- XML helpers
def run(text, bold=False, italic=False, size=None):
    r = etree.Element(q("r")); rpr = etree.SubElement(r, q("rPr"))
    if bold:
        etree.SubElement(rpr, q("b"))
    if italic:
        etree.SubElement(rpr, q("i"))
    if size:
        etree.SubElement(rpr, q("sz"), {q("val"): str(size)}); etree.SubElement(rpr, q("szCs"), {q("val"): str(size)})
    if len(rpr) == 0:
        r.remove(rpr)
    t = etree.SubElement(r, q("t")); t.text = text; t.set("{%s}space" % XMLNS, "preserve")
    return r


def mark(kind):
    return etree.Element(q(kind), {q("id"): nid(), q("author"): AUTHOR, q("date"): DATE})


def ins(*runs):
    e = mark("ins"); e.extend(runs); return e


def segs_to_runs(segs, size=None):
    out = []
    for s in segs:
        if isinstance(s, tuple):
            out.append(run(s[0], *(s[1:]), size=size) if len(s) <= 3 else run(s[0], s[1], s[2], size=size))
        else:
            out.append(run(s, size=size))
    return out


def new_p(segs, style=None, size=None, align=None):
    p = etree.Element(q("p")); ppr = etree.SubElement(p, q("pPr"))
    if style:
        etree.SubElement(ppr, q("pStyle"), {q("val"): style})
    if align:
        etree.SubElement(ppr, q("jc"), {q("val"): align})
    rpr = etree.SubElement(ppr, q("rPr")); rpr.append(mark("ins"))
    p.append(ins(*segs_to_runs(segs, size)))
    return p


def delete_runs(p):
    for r in list(p.iter(q("r"))):
        parent = r.getparent()
        if parent.tag == q("del"):
            continue
        for t in r.findall(q("t")):
            t.tag = q("delText")
        d = mark("del"); parent.insert(parent.index(r), d); d.append(r)


def mark_p_deleted(p):
    ppr = p.find(q("pPr"))
    if ppr is None:
        ppr = etree.Element(q("pPr")); p.insert(0, ppr)
    rpr = ppr.find(q("rPr"))
    if rpr is None:
        rpr = etree.SubElement(ppr, q("rPr"))
    rpr.insert(0, mark("del"))


def style_of(p):
    s = p.find(q("pPr") + "/" + q("pStyle")); return s.get(q("val")) if s is not None else None


def replace_p(p, paragraphs, style=None):
    """paragraphs: list of segment-lists. First replaces p's content; the rest are inserted after p."""
    delete_runs(p)
    p.append(ins(*segs_to_runs(paragraphs[0])))
    last = p
    for segs in paragraphs[1:]:
        np_ = new_p(segs, style=style if style is not None else (None if style_of(p) in (None, "Heading1", "Heading2", "Heading3") else style_of(p)))
        last.addnext(np_); last = np_
    return last


def delete_p(p):
    delete_runs(p); mark_p_deleted(p)


def insert_after(el, elements):
    for e in elements:
        el.addnext(e); el = e
    return el


def new_table(header, rows, widths, size=16):
    tbl = etree.Element(q("tbl")); tblPr = etree.SubElement(tbl, q("tblPr"))
    etree.SubElement(tblPr, q("tblW"), {q("w"): str(sum(widths)), q("type"): "dxa"})
    b = etree.SubElement(tblPr, q("tblBorders"))
    for side in ("top", "left", "bottom", "right", "insideH", "insideV"):
        etree.SubElement(b, q(side), {q("val"): "single", q("sz"): "4", q("space"): "0", q("color"): "auto"})
    etree.SubElement(tblPr, q("tblLook"), {q("val"): "04A0"})
    grid = etree.SubElement(tbl, q("tblGrid"))
    for w in widths:
        etree.SubElement(grid, q("gridCol"), {q("w"): str(w)})

    def make_row(cells, bold):
        tr = etree.Element(q("tr")); trPr = etree.SubElement(tr, q("trPr")); trPr.append(mark("ins"))
        for c, w in zip(cells, widths):
            tc = etree.SubElement(tr, q("tc")); tcPr = etree.SubElement(tc, q("tcPr"))
            etree.SubElement(tcPr, q("tcW"), {q("w"): str(w), q("type"): "dxa"})
            tc.append(new_p([(str(c), bold, False)], size=size))
        return tr
    tbl.append(make_row(header, True))
    for r in rows:
        tbl.append(make_row(r, False))
    return tbl


def delete_table(tbl):
    for tr in tbl.findall(q("tr")):
        trPr = tr.find(q("trPr"))
        if trPr is None:
            trPr = etree.Element(q("trPr"))
            ex = tr.find(q("tblPrEx"))                 # schema order: tblPrEx, trPr, tc...
            tr.insert(tr.index(ex) + 1 if ex is not None else 0, trPr)
        trPr.append(mark("del"))
        for p in tr.iter(q("p")):
            delete_runs(p)


# ----------------------------------------------------------------------------- load document
if OUT_DIR.exists():
    shutil.rmtree(OUT_DIR)
shutil.copytree(SRC, OUT_DIR)
doc_path = OUT_DIR / "word" / "document.xml"
tree = etree.parse(str(doc_path)); body = tree.getroot().find(q("body"))
E = list(body)          # original element references by index

# ============================================================================= TEXT
H1, H2, H3, LIST = "Heading1", "Heading2", "Heading3", "ListParagraph"

replace_p(E[1], [["Multimodal deep learning fusion for lung cancer subtype differentiation from CT and PET imaging: a proof-of-concept study with nested, patient-level cross-validation on the Lung-PET-CT-Dx collection"]])

abstract = (
    f"Distinguishing small cell lung cancer (SCLC) from non-small cell lung cancer (NSCLC) determines first-line treatment, and an image-based estimate of SCLC risk could help prioritise histological confirmation. We evaluated a weakly supervised CT/PET fusion framework for patient-level SCLC risk estimation on the public Lung-PET-CT-Dx collection (355 patients with histology-confirmed lung cancer, 38 SCLC; CT in all patients and 18F-FDG PET in 133). "
    f"Tumour-bearing axial slices were encoded by two ImageNet-pretrained EfficientNet-B0 streams (CT and PET), fused by multi-head cross-attention with explicit handling of missing PET, and aggregated into a patient-level prediction by attention-gated multiple-instance pooling. CT/PET alignment used the scanner's shared frame of reference or rigid registration and was quality-controlled for every patient. All models were developed and evaluated with nested, patient-level cross-validation (five outer test folds, three inner folds): early stopping, probability recalibration and decision thresholds were fixed on the inner folds and applied unchanged to the outer test folds, so that every patient was predicted once out-of-fold. "
    f"The image-only ensemble of the fine-tuned and frozen-encoder variants reached a patient-level area under the ROC curve (AUC) of {auc_ci(m[ENS])} with SCLC sensitivity {opci(m[ENS], 'thr_sens80', 'sensitivity')} at specificity {op(m[ENS], 'thr_sens80', 'specificity'):.2f} and negative predictive value {op(m[ENS], 'thr_sens80', 'npv'):.2f} at the pre-specified sensitivity-targeted operating point (Brier score {brier(m[ENS])}; null model 0.096). Cross-attention, feature concatenation and pixel-level early fusion performed alike (AUC {m[FRZ]['auc']['value']:.2f}–{m[EARLY]['auc']['value']:.2f}), PET added less than 0.01 AUC over CT alone with the same pooling head, and predictions were insensitive to PET translations of up to 40 mm. "
    f"Adding radiologist-reported T and N stage in a secondary clinico-radiological model increased the AUC to {auc_ci(m[FUSE])}. Decision-curve analysis showed net benefit over treating all patients as SCLC for threshold probabilities between 5% and 20%. To our knowledge this is the first leakage-free, TRIPOD+AI-reported patient-level evaluation of CT/PET fusion for SCLC risk on a public collection and the first to use every patient despite incomplete PET; its results exceed previously reported leakage-free patient-level results on this collection (AUC 0.69) while remaining below those of curated single-centre cohorts, so the framework should be regarded as a calibrated proof of concept rather than a deployable triage tool."
)
replace_p(E[7], [[abstract]])

# --- Introduction: contributions
replace_p(E[18], [["To address these problems we evaluate a hybrid multiple-instance learning (MIL) fusion framework for patient-level discrimination of SCLC from NSCLC on the public Lung-PET-CT-Dx collection, using CT from all 355 patients and PET where it exists (133 patients). The study is designed and reported as a diagnostic prediction-model development study with internal validation (TRIPOD+AI [38]). Our contributions are:"]])
replace_p(E[19], [["A leakage-free, fully reported benchmark: to our knowledge the first patient-level evaluation of CT/PET fusion for SCLC versus NSCLC on a public collection in which nested cross-validation, probability recalibration and decision thresholds are frozen before testing, every metric carries a confidence interval, and calibration, decision-curve, scanner-shift, subgroup and misalignment analyses are reported against the TRIPOD+AI checklist [38]. Previous results on this collection were obtained with slice-level evaluation, synthetic oversampling or a single split."]])
replace_p(E[20], [["Missing-modality-tolerant multimodal learning: dual EfficientNet-B0 streams joined by token-level multi-head cross-attention, with a learned missing-PET token and modality dropout, so that all 355 patients (PET available in 133) contribute to training and testing rather than only the paired subset required by existing PET/CT fusion models."]])
replace_p(E[21], [["A documented, quality-controlled CT/PET alignment protocol (scanner frame of reference or rigid registration, two per-patient alignment scores, visual review of every PET case) together with a quantified test of robustness to residual misalignment, which no previous study on this collection reports."]])
replace_p(E[22], [["Controlled ablations under identical folds that isolate what matters: cross-attention versus feature concatenation versus pixel-level early fusion, CT-only versus CT+PET, focal versus cross-entropy loss, lesion-relative versus fixed-size field of view, end-to-end versus frozen encoders, and hand-crafted radiomic baselines, with paired statistical tests."]])
insert_after(E[22], [new_p(["A secondary clinico-radiological model that fuses the imaging ensemble with radiologist-reported T and N stage and shows that the two information sources are complementary (AUC 0.80), evaluated with the same frozen-threshold protocol."], style=LIST),
                     new_p(["Correction of the cohort description of our preprint, and public release of code, fold assignments, out-of-fold predictions, frozen thresholds and alignment scores so that every number can be reproduced."], style=LIST)])

# --- related work: prior results on this collection
insert_after(E[30], [new_p([
    "Few studies report patient-level, leakage-free results for SCLC versus NSCLC. On the Lung-PET-CT-Dx collection used here, three-dimensional CT radiomics reached an AUC of 0.69 before synthetic oversampling [45], and a PET/CT convolutional network trained at another institution reached 0.69 on an external Lung-PET-CT-Dx subset with 14 SCLC patients [46]; considerably higher figures reported on the same collection (0.94–0.98) were obtained with slice-level evaluation or after synthetic minority oversampling and are not comparable to patient-level estimates [45,52]. Curated single-centre radiomics cohorts with manual three-dimensional segmentation and balanced or SCLC-rich case mixes report 0.80–0.93 [49–51], with squamous-versus-small-cell discrimination being the hardest pairing. These values frame what can be expected from an 11%-prevalence, multi-vendor, box-annotated public cohort."])])
replace_p(E[36], [["This section concludes the review of related work. The aim of the study is to evaluate, under a leakage-free patient-level protocol, whether weakly supervised CT/PET feature fusion provides clinically useful and well-calibrated SCLC risk estimates on a public multi-vendor collection, and to quantify the contribution of each design choice (PET, cross-attention, loss, field of view) and of clinical stage."]])

# --- Methods: formulation / architecture text
replace_p(E[43], [["comprising K_i instances (axial slices that contain or neighbour the annotated tumour). Each instance consists of a CT crop and, when PET exists for the patient, the spatially corresponding PET crop; a binary indicator m_i marks PET availability. The global target y_i ∈ {0,1} is the histopathological diagnosis, NSCLC (y_i = 0) or SCLC (y_i = 1). The objective is a mapping f_Θ: (B_i, m_i) → ŷ_i producing a calibrated patient-level SCLC probability under severe class imbalance (38 of 355 patients)."]])
replace_p(E[49], [["where E_θCT and E_θPET are EfficientNet-B0 encoders initialised with ImageNet weights (timm tf_efficientnet_b0.ns_jft_in1k [48]) and adapted to two input channels. The 7 × 7 × 1280 output maps are projected to d = 256 and kept as T = 49 spatial tokens per slice and modality, z_{i,k}^{CT}, z_{i,k}^{PET} ∈ ℝ^{T×d}. Two training regimes were evaluated: end-to-end fine-tuning of both encoders, and frozen encoders with only the projection, fusion, pooling and classification layers trained (Implementation)."]])
replace_p(E[51], [["Inter-modality interactions are captured by bidirectional multi-head cross-attention between the token maps of the two modalities (8 heads). Linear maps project the tokens of each modality into query, key and value spaces:"]])
replace_p(E[53], [["CT tokens attend to PET tokens and PET tokens attend to CT tokens; each attended map is added to its input (residual), passed through a feed-forward block, and average-pooled over positions, giving two d-dimensional vectors that are concatenated into the fused instance embedding:"]])
replace_p(E[54], [["A_{CT→PET} = softmax(Q_{CT} K_{PET}^T / √d) V_{PET},   A_{PET→CT} = softmax(Q_{PET} K_{CT}^T / √d) V_{CT}    (Eq 6)"]])
replace_p(E[55], [["z_{i,k}^{fused} = [ pool(z^{CT} + A_{CT→PET}) ∥ pool(z^{PET} + A_{PET→CT}) ]    (Eq 7)"]])
replace_p(E[56], [["where ∥ denotes concatenation and pool the mean over the T positions. When PET is absent (m_i = 0) the CT branch uses its own pooled tokens and the PET half of z^{fused} is replaced by a learned missing-modality vector; during training PET was additionally dropped at random (p = 0.25) for PET patients so that both pathways are learned. Fig 3 shows the full architecture, integrating this fusion with the MIL aggregation described next."]])

# --- Data source and participants
replace_p(E[65], [["Data source, participants and outcome"]])
replace_p(E[66], [["We used the Lung-PET-CT-Dx collection of The Cancer Imaging Archive [37], a retrospective, de-identified collection of CT and 18F-FDG PET/CT examinations (2006–2011) of 355 patients with lung cancer confirmed by standard-of-care biopsy, acquired on GE, Siemens and Philips CT scanners and Siemens Biograph mCT PET/CT systems. The histological subtype is encoded in the patient identifier (A adenocarcinoma, n = 251; G squamous cell carcinoma, n = 61; E large cell carcinoma, n = 5; B small cell carcinoma, n = 38). Five thoracic radiologists marked each tumour with axial bounding boxes stored as PASCAL-VOC files keyed by SOP Instance UID. The outcome was SCLC (y = 1) versus NSCLC (adenocarcinoma, squamous and large cell; y = 0)."]])
replace_p(E[68], [["Eligibility and missing data. All 355 patients were eligible: each has a histology code, at least one CT series with DICOM geometry and at least one radiologist box (median 45 annotated slices per patient, interquartile range 19–124). PET is present for 133 patients (95 adenocarcinoma, 29 squamous, 9 small cell) and absent for 222; PET was therefore treated as an optional modality with explicit missing-modality handling (Eq 7) rather than imputed. Correction to our preprint: the earlier analysis described 355 dual-modality patients, whereas PET had in fact been zero-filled for the 222 patients without PET. Three patients whose boxes lay only on vendor screenshots without geometry received a central crop. Baseline characteristics are given in Table 2: SCLC patients had larger tumours and more nodal disease (N3 in 55% versus 18%), as expected, while age, sex, smoking, scanner vendor and slice thickness did not differ."]])
replace_p(E[69], [["Development and validation did not use a single split. Instead, the whole cohort was partitioned repeatedly into outcome-stratified, patient-level folds (Validation protocol), so that development (inner folds) and validation (outer folds) are separated for every patient and all 38 SCLC patients act as test cases."]])
replace_p(E[70], [["Table 2. Participant characteristics by histological class (n = 355)."]])
delete_table(E[71])
want = {"Patients, n": "Patients, n", "Histology: A": "Adenocarcinoma", "Histology: G": "Squamous cell carcinoma", "Histology: E": "Large cell carcinoma",
        "Histology: B": "Small cell carcinoma", "Age, years (median, IQR)": "Age, years, median (IQR)", "Sex: M": "Male sex", "Smoking history: 1.0": "Smoking history",
        "T stage (major): 1": "T1", "T stage (major): 2": "T2", "T stage (major): 3": "T3", "T stage (major): 4": "T4",
        "Nodal stage N>0: 0.0": "N0", "Nodal stage N>0: 1.0": "N1", "Nodal stage N>0: 2.0": "N2", "Nodal stage N>0: 3.0": "N3",
        "Distant metastasis M>0: 1.0": "M1", "PET available: True": "PET available", "CT manufacturer: GE MEDICAL SYSTEMS": "CT vendor GE",
        "CT manufacturer: SIEMENS": "CT vendor Siemens", "CT manufacturer: Philips": "CT vendor Philips",
        "Effective CT slice thickness, mm: 5": "Effective slice thickness 5 mm after harmonisation",
        "Annotated tumour slices per patient (median, IQR)": "Annotated tumour slices per patient, median (IQR)"}
rows = []
for _, r in cohort.iterrows():
    if r["characteristic"] in want:
        pv = "" if pd.isna(r["p"]) or r["p"] == "" else str(r["p"])
        rows.append([want[r["characteristic"]], str(r["all"]).replace("; n=", " (n = ").replace("n = ", "n = ") if "n=" in str(r["all"]) else r["all"],
                     r["NSCLC"], r["SCLC"], pv])
t2 = new_table(["Characteristic", "All (n = 355)", "NSCLC (n = 317)", "SCLC (n = 38)", "p"], rows, [3400, 1600, 1600, 1500, 700])
E[71].addnext(t2)
insert_after(t2, [new_p(["Counts are n (%) unless stated; p from Mann–Whitney U (continuous) or chi-square/Fisher tests (categorical) over the first level of each variable. Stage and grade are taken from the collection's clinical file; the data providers do not state whether staging was clinical or pathological."], size=18)])

# --- preprocessing
replace_p(E[73], [["To resolve spatial and intensity variation across heterogeneous imaging systems, data were processed with a unified pipeline (series selection, alignment, intensity conversion, slice-thickness harmonisation, instance definition)."]])
replace_p(E[74], [["Series selection and CT/PET alignment"]])
replace_p(E[75], [["For each patient we used the CT series with the largest number of radiologist boxes; vendor secondary-capture RGB screenshots, which carry boxes but no geometry, were excluded. For PET patients the annotated CT acquired in the PET/CT session was preferred. CT and PET were brought into correspondence through DICOM patient coordinates when both series shared a Frame of Reference UID (103 patients; hardware co-registration of the hybrid scanner). When the annotated CT was a separate acquisition (30 patients) the PET volume was rigidly registered to it with SimpleITK [44] (Euler 3-D transform, Mattes mutual information, multi-resolution, 3-mm isotropic resampling); the registered result was kept in 29 patients. Alignment was quality-controlled for every patient with two scores, the Dice overlap of the filled body outlines of CT (HU > −500) and PET (SUV > 0.3; median 0.95, minimum 0.80) and a cranio-caudal lung/soft-tissue uptake score that detects level errors, and every PET case was reviewed visually (S1 Fig). The uptake score identified one SCLC case whose PET had initially been mapped at liver level, which was corrected; the remaining low scores were lung-base tumours with physiological diaphragm mismatch between breath-hold CT and free-breathing PET, which rigid registration cannot remove and whose effect is quantified in the misalignment experiment."]])
replace_p(E[76], [["Hounsfield-unit windows and standardised uptake value"]])
replace_p(E[77], [["CT voxel values were converted to Hounsfield units (HU) with the vendor rescale parameters and represented by two windows: lung (level −600 HU, width 1500 HU) and mediastinal (level 40 HU, width 400 HU). PET activity (Bq/mL) was converted to body-weight standardised uptake value (SUV) from the injected dose, injection and acquisition times, decay correction and patient weight in the DICOM headers (complete for all 133 PET series; median uptake time 76 min) and represented by two channels, SUV/10 and SUV/3, clipped to [0, 1]."]])
replace_p(E[78], [["Slice-thickness harmonisation"]])
replace_p(E[79], [["Because PET/CT sessions provided 0.7–1.0-mm reconstructions whereas most CT-only patients had 5-mm reconstructions, thin series were slab-averaged and sub-sampled to an effective thickness of about 5 mm (93% of patients at 5 mm after harmonisation), reducing vendor- and protocol-specific texture cues that could act as shortcuts for the SCLC label."]])
delete_p(E[80]); delete_p(E[81])
replace_p(E[82], [["Instances, field of view and augmentation"]])
replace_p(E[83], [["Instances were the axial slices within 10 mm of a radiologist box (median 11 per patient). Each instance was represented as a fixed 160 × 160 mm field of view centred on the box, resampled to 224 × 224 pixels, which preserves absolute lesion size and the surrounding hilum and mediastinum; a lesion-relative crop (1.8 × the box), the whole slice and an image-centred mediastinal view were evaluated as alternatives and selected against on the inner folds (S4 Table). Training-time augmentation comprised random crop scale (70–90% of the stored window) and shift, rotation (±10°), horizontal flip, CT intensity gamma and PET gain jitter."]])
replace_p(E[84], [["Tumour-centric instance sampling"]])
replace_p(E[85], [["During training a bag of K = 8 randomly sampled instances per patient formed one training example; at inference all candidate instances of a patient (up to 48) formed one bag and horizontal-flip test-time augmentation was averaged. Patients were sampled with inverse class-frequency weights so that SCLC patients appeared as often as NSCLC patients in each epoch."]])
replace_p(E[86], [["The pipeline therefore requires tumour bounding boxes at inference, as in the submitted version; automated lesion detection is outside the scope of this study and is discussed as a limitation."]])

# --- implementation
replace_p(E[88], [["The models were implemented in PyTorch 2.11 with timm [48], scikit-learn and SimpleITK [44], and trained on a single NVIDIA RTX 5090 laptop GPU (24 GB) with bfloat16 mixed precision. Code, per-patient out-of-fold predictions, fold assignments and frozen thresholds are provided as supporting information (S1 Data)."]])
replace_p(E[90], [["Two variants of the framework were evaluated. In the end-to-end variant both EfficientNet-B0 encoders were fine-tuned together with the fusion, pooling and classification layers (9.9 million parameters). In the frozen-encoder variant the ImageNet encoders were kept fixed and their 7 × 7 token maps were cached once per instance (eight augmented versions), so that only the projections, cross-attention blocks, gated-attention pooling and classifier were trained; this variant is far less prone to over-fitting 284 training patients, trains in seconds, and was used for repeated runs and ablations."]])
replace_p(E[92], [["End-to-end variant: AdamW, learning rate 1 × 10⁻⁴ for the encoders and 3 × 10⁻⁴ for the fusion and pooling layers, weight decay 1 × 10⁻⁴, one warm-up epoch followed by cosine decay over at most 25 epochs, batches of 8 patients × 8 instances, gradient clipping at 1.0 and an exponential moving average of the weights (decay 0.99). Frozen variant: AdamW, learning rate 3 × 10⁻⁴, weight decay 0.05, dropout 0.3, token dropout 0.1, at most 30 epochs. Stronger regularisation of the end-to-end variant (learning rate 3 × 10⁻⁵, weight decay 0.05, drop-path 0.2) was also tested and did not improve inner-fold performance."]])
replace_p(E[93], [["Early stopping and model selection"]])
replace_p(E[94], [["Early stopping monitored the AUC on the inner validation split of each inner model (patience 6 epochs end-to-end, 8 epochs frozen) and never used an outer test fold. All design choices, including the input field of view, the fusion variant and the loss, were compared by the inner-fold out-of-fold AUC."]])
replace_p(E[96], [["To address the severe class imbalance (317 NSCLC versus 38 SCLC) training used inverse-frequency patient sampling together with a class-weighted focal loss [43], which down-weights well-classified majority patients and up-weights SCLC errors:"]])
replace_p(E[97], [["L_focal = −(1/B) Σ_{i=1}^{B} α_{y_i} (1 − p_{i,y_i})^γ log p_{i,y_i},  α_SCLC = 0.6, α_NSCLC = 0.4, γ = 2    (Eq 12)"]])
replace_p(E[98], [["where p_{i,y_i} is the predicted probability of the true class of patient i and B the batch size; labels were smoothed by 0.02–0.05. A class-weighted binary cross-entropy (Eq 13) was evaluated as an ablation."]])

# --- comparison models and ablations
replace_p(E[100], [["Comparison models and ablations"]])
replace_p(E[101], [["To attribute performance to individual design choices, the following models were trained and evaluated under the identical nested protocol, folds and patients."]])
replace_p(E[102], [["Hand-crafted reference baselines"]])
replace_p(E[103], [["Logistic regression and gradient boosting on hand-crafted features derived from the radiologist boxes: lesion geometry (log maximal diameter, log cranio-caudal extent, log box area), HU statistics inside the box (mean, standard deviation, 90th percentile, solid fraction) and, where available, SUVmax, SUVmean and SUVpeak with a PET-availability indicator. A geometry-only model quantifies how much of the signal is tumour size alone."]])
replace_p(E[104], [["Fusion, modality and loss ablations"]])
replace_p(E[105], [["Dual-stream concatenation without cross-attention; CT-only and PET-only encoders with the same pooling head; pixel-level early fusion (a single EfficientNet-B0 on the stacked CT windows and PET channels, the architecture of the submitted baseline); weighted binary cross-entropy instead of focal loss; and the addition of the three geometry descriptors to the pooled bag vector. The strictly paired CT+PET subset (133 patients, 9 SCLC) was analysed separately and is regarded as exploratory. Out-of-fold ensembles were formed by averaging the recalibrated probabilities of several models; because every member's prediction for a patient was produced by models that never saw that patient and no ensemble weight was fitted on test folds, the ensemble remains a valid out-of-fold estimate."]])
replace_p(E[106], [["Secondary clinico-radiological model"]])
replace_p(E[107], [["Because nodal and tumour stage are strongly associated with small cell histology (Table 2) and are routinely reported by the radiologist, we evaluated (i) a logistic regression on T stage (with a/b/c sub-stage) and N stage from the collection's clinical file and (ii) its equal-weight late fusion with the image-only ensemble (average of z-scored logits; z-scoring, recalibration and thresholds fitted on inner folds only, no weight learned on test folds). Histological grade was deliberately excluded because grade 3 is definitional for SCLC and would leak the label; demographic variables carried no signal (AUC 0.42) and were not used. The data providers do not state whether staging was clinical or pathological, so this model is reported as a secondary analysis."]])

# --- validation protocol / recalibration
replace_p(E[108], [["Validation protocol"]])
replace_p(E[109], [["We used nested, patient-level, outcome-stratified cross-validation. Five outer folds provided untouched test sets (71 patients, 7–8 SCLC each). Within each outer training set, three inner folds were used to train three models, each with early stopping on its held-out inner split. The three models' inner out-of-fold predictions (one per outer-training patient) were used to fit a two-parameter logistic (Platt [42]) recalibration and to choose three decision thresholds: the Youden index, the maximum F1 score, and the most specific threshold achieving at least 80% SCLC sensitivity, the operating point relevant to prioritising histological confirmation. These values were frozen before the outer test fold was evaluated with the mean recalibrated probability of the three inner models. Every patient therefore received exactly one out-of-fold prediction per repeat and all 38 SCLC patients served as test cases; the frozen-encoder models were run with three repeats of the outer partition. Per-fold thresholds and recalibration parameters are listed in S3 Table."]])
replace_p(E[110], [["Recalibration was necessary because class-balanced sampling and the focal loss inflate raw probabilities (calibration intercept about −1.7 before recalibration); Platt scaling fitted on inner folds restored the base rate (mean predicted probability 0.10 against a prevalence of 0.107). As a scanner-shift analysis the frozen main model was additionally trained on two CT vendors and tested on the third (leave-one-manufacturer-out). Robustness to residual CT/PET misalignment was tested by translating the PET crop relative to the CT crop by 5–25% of the field of view (8–40 mm) at inference and by removing PET entirely. Explainability used Grad-CAM on the penultimate stage of both encoders, the CT→PET cross-attention maps and the MIL attention weights, summarised by the fraction of attention mass on radiologist-annotated slices."]])
insert_after(E[110], [new_p(["Sample size"], style=H2),
                      new_p(["The sample size was fixed by data availability (all eligible patients of the collection were used); no new data could be collected. With 38 events the Hanley–McNeil [47] standard error of an AUC of 0.75 is 0.047, i.e. a 95% confidence-interval half-width of about ±0.09, and one additional detected SCLC patient changes sensitivity by 2.6 percentage points; the paired CT+PET subset (9 events) has a half-width of about ±0.18 and is reported as exploratory (S2 Text)."])])

# --- statistical analysis
replace_p(E[112], [["Discrimination was summarised by the AUC with DeLong 95% confidence intervals [39] and by the area under the precision–recall curve; sensitivity, specificity, positive and negative predictive value, accuracy, balanced accuracy, macro-F1 and Matthews correlation are reported at the frozen operating points with 95% confidence intervals from 1,000 patient-level bootstrap resamples, together with the mean ± SD across the five test folds. Calibration was assessed by the Brier score, calibration slope and intercept (logistic recalibration) and reliability diagrams [41]; clinical utility by decision-curve analysis against treat-all and treat-none strategies [40]. Paired comparisons between models on identical patients used the DeLong test for AUC differences and bootstrap intervals for differences in sensitivity and balanced accuracy. Subgroup performance is reported by PET availability, CT vendor and NSCLC histology. Analyses used Python 3.12, PyTorch 2.11, timm, scikit-learn and SimpleITK."]])

# ============================================================================= RESULTS
insert_after(E[113], [new_p(["Principal findings"], style=H2),
                      new_p([f"Under a protocol in which no test patient influenced training, model selection, recalibration or thresholds, the image-only ensemble reached an AUC of {auc_ci(m[ENS])} with SCLC sensitivity {op(m[ENS], 'thr_sens80', 'sensitivity'):.2f} at specificity {op(m[ENS], 'thr_sens80', 'specificity'):.2f} and was well calibrated; adding radiologist-reported T and N stage raised the AUC to {auc_ci(m[FUSE])}. The fusion mechanism (cross-attention, concatenation or early fusion) did not matter, PET added little with nine SCLC PET cases, and attention pooling behaved as averaging, whereas preserving absolute lesion size and context, handling missing PET explicitly and recalibrating probabilities did matter. These values exceed previously reported leakage-free patient-level results on this collection (AUC 0.69) and define a reproducible baseline for future external validation."])])
replace_p(E[114], [["Participants"]])
replace_p(E[115], [["All 355 patients (317 NSCLC, 38 SCLC) entered the analysis; 133 had PET. Table 2 summarises their characteristics. Across the five outer test folds each fold contained 71 patients with 7 or 8 SCLC cases."]])
replace_p(E[116], [["Discrimination, calibration and clinical utility"]])
main_txt = (
    f"Table 3 reports the pooled out-of-fold performance. The image-only ensemble of the end-to-end and frozen-encoder cross-attention models reached an AUC of {auc_ci(m[ENS])} (mean ± SD across folds {fold_auc(m[ENS])}) and an area under the precision–recall curve of {m[ENS]['auprc']['value']:.2f} (prevalence 0.11). At the pre-specified sensitivity-targeted operating point it detected {TP} of 38 SCLC patients (sensitivity {opci(m[ENS], 'thr_sens80', 'sensitivity')}) at specificity {opci(m[ENS], 'thr_sens80', 'specificity')}, with negative predictive value {op(m[ENS], 'thr_sens80', 'npv'):.2f}; at the Youden threshold sensitivity and specificity were {ss(m[ENS], 'thr_youden')} (Fig 4). "
    f"The single end-to-end model reached {auc_ci(m[FT])} and the frozen-encoder model {auc_ci(m[FRZ])} (three repeats: 0.69–0.71). The ensemble exceeded the single end-to-end model by {d_ens_ft:+.3f} AUC (DeLong p = {p_ens_ft:.2f}) and the best hand-crafted baseline by {d_ens_lr:+.3f} (p = {p_ens_lr:.2f}); neither difference reaches significance at this sample size. "
    f"After inner-fold Platt recalibration the models were well calibrated: Brier score {brier(m[ENS])} for the ensemble and {brier(m[FRZ])} for the frozen model against 0.096 for a prevalence-only model, calibration intercepts 0.06–0.07 and slopes of {m[FRZ]['calibration']['calibration_slope']['value']:.2f} (frozen) and {m[ENS]['calibration']['calibration_slope']['value']:.2f} (ensemble, i.e. slightly under-confident) (Fig 5A). Decision-curve analysis showed a net benefit above both treat-all and treat-none strategies for threshold probabilities between about 5% and 20% (Fig 5B), the range in which an elevated SCLC probability would plausibly trigger expedited histological confirmation; above 20% the models offer no benefit over treating no one, reflecting their moderate discrimination."
)
replace_p(E[117], [[main_txt]])
replace_p(E[118], [["Table 3. Pooled out-of-fold performance of the image-only models, reference baselines and the secondary clinico-radiological models (355 patients, 38 SCLC). AUC with DeLong 95% CI; sensitivity/specificity at the frozen Youden and sensitivity-targeted (≥0.80 on inner folds) operating points; calibration slope/intercept after inner-fold recalibration; AUC mean ± SD across the five test folds."]])
delete_table(E[119])


def row(label, key):
    mm = m[key]
    return [label, auc_ci(mm), f"{mm['auprc']['value']:.2f}", ss(mm, "thr_youden"), ss(mm, "thr_sens80"), f"{op(mm, 'thr_sens80', 'npv'):.2f}", brier(mm), slope_int(mm), fold_auc(mm)]


t3 = new_table(["Model", "AUC (95% CI)", "AUPRC", "Sens / Spec, Youden", "Sens / Spec, ≥0.80 target", "NPV", "Brier", "Slope / intercept", "Fold AUC"], [
    row("Image-only ensemble (end-to-end + frozen cross-attention MIL)", ENS),
    row("End-to-end dual EfficientNet-B0 + cross-attention MIL (context view)", FT),
    row("End-to-end pixel-level early fusion", EARLY),
    row("Frozen encoders + cross-attention MIL (3 repeats)", FRZ),
    row("  + lesion geometry descriptors", GEOM),
    row("  concatenation instead of cross-attention", CONCAT),
    row("  CT only", CTONLY),
    row("  weighted BCE instead of focal loss", BCE),
    row("Hand-crafted CT+PET features + logistic regression", LR),
    row("Lesion geometry + logistic regression", GLR),
    row("Secondary: T + N stage, logistic regression", STAGE),
    row("Secondary: image-only ensemble + T/N stage", FUSE),
], [3000, 1250, 600, 1000, 1050, 550, 600, 850, 800], size=15)
E[119].addnext(t3)

abl = (
    f"Ablations (Table 3) show that the fusion mechanism matters little on this cohort: cross-attention and feature concatenation differed by {d_xc:+.3f} AUC (p = {p_xc:.2f}), and the end-to-end cross-attention model and pixel-level early fusion by {d_xe:+.3f} (p = {p_xe:.2f}). PET contributed {d_pet:+.3f} AUC over CT alone with the same head (p = {p_pet:.2f}), focal loss and weighted cross-entropy were equivalent, and the geometry descriptors added {m[GEOM]['auc']['value'] - m[FRZ]['auc']['value']:+.3f}. Tumour size alone (geometry logistic regression) reached {auc_ci(m[GLR])}, confirming that lesion bulk carries a substantial part of the signal, and the hand-crafted CT+PET baseline {auc_ci(m[LR])}. "
    f"In the strictly paired CT+PET subset (133 patients, 9 SCLC) all variants lay between AUC {min(m[k]['auc']['value'] for k in (PX, PC, PP, PCC)):.2f} and {max(m[k]['auc']['value'] for k in (PX, PC, PP, PCC)):.2f} with confidence-interval half-widths of about 0.12 (S5 Table); nine events do not support any statement about fusion in this subset. "
    f"Subgroup AUCs of the ensemble were {sub_ens['with_PET=False']['auc']:.2f} in patients without PET and {sub_ens['with_PET=True']['auc']:.2f} in patients with PET, and {sub_ens['manufacturer=GE MEDICAL SYSTEMS']['auc']:.2f}, {sub_ens['manufacturer=SIEMENS']['auc']:.2f} and {sub_ens['manufacturer=Philips']['auc']:.2f} for GE, Siemens and Philips CTs (Table 4)."
)
fig4 = new_p([("Fig 4. Discrimination of the revised models. ", True, False), ("(A) Pooled out-of-fold ROC curves of the image-only ensemble, the frozen cross-attention model, its CT-only ablation and the hand-crafted baseline. (B) AUC with DeLong 95% confidence intervals for all evaluated models, the paired subset and the leave-one-manufacturer-out tests.", False, False)])
sec = (
    f"Secondary clinico-radiological model. T and N stage alone reached an AUC of {auc_ci(m[STAGE])} with sensitivity {op(m[STAGE], 'thr_sens80', 'sensitivity'):.2f} at specificity {op(m[STAGE], 'thr_sens80', 'specificity'):.2f}. Its late fusion with the image-only ensemble reached {auc_ci(m[FUSE])} (fold mean ± SD {fold_auc(m[FUSE])}), detecting {TPf} of 38 SCLC patients (sensitivity {opci(m[FUSE], 'thr_sens80', 'sensitivity')}) at specificity {op(m[FUSE], 'thr_sens80', 'specificity'):.2f}, with Brier score {brier(m[FUSE])} and calibration slope {m[FUSE]['calibration']['calibration_slope']['value']:.2f}. Imaging added {d_fu_st:+.3f} AUC to stage (p = {p_fu_st:.2f}) and stage added {d_fu_ens:+.3f} to imaging (p = {p_fu_ens:.2f})."
)
insert_after(t3, [new_p([abl]), fig4, new_p([sec])])

replace_p(E[120], [[f"Scanner-shift analysis. Trained on Siemens and Philips CTs and tested on GE CTs (146 patients, 19 SCLC) the frozen main model retained an AUC of {auc_ci(m[LGE])} with sensitivity/specificity {ss(m[LGE], 'thr_youden')}; trained without the Siemens group, which contains all PET/CT sessions and the thin-slice protocol, and tested on it (179 patients, 17 SCLC) the AUC fell to {auc_ci(m[LSI])}; the Philips group (30 patients, 2 SCLC) is too small to be informative ({m[LPH]['auc']['value']:.2f}) (Table 4). Vendor shift therefore degrades performance when the held-out vendor differs in acquisition protocol, which is the expected behaviour and the reason external validation remains necessary."]])
t4rows = [
    ["Ensemble, patients without PET", f"222 / 29", f"{sub_ens['with_PET=False']['auc']:.2f}", f"{sub_ens['with_PET=False']['sensitivity']:.2f} / {sub_ens['with_PET=False']['specificity']:.2f}"],
    ["Ensemble, patients with PET", f"133 / 9", f"{sub_ens['with_PET=True']['auc']:.2f}", f"{sub_ens['with_PET=True']['sensitivity']:.2f} / {sub_ens['with_PET=True']['specificity']:.2f}"],
    ["Ensemble, GE CTs", "146 / 19", f"{sub_ens['manufacturer=GE MEDICAL SYSTEMS']['auc']:.2f}", f"{sub_ens['manufacturer=GE MEDICAL SYSTEMS']['sensitivity']:.2f} / {sub_ens['manufacturer=GE MEDICAL SYSTEMS']['specificity']:.2f}"],
    ["Ensemble, Siemens CTs", "179 / 17", f"{sub_ens['manufacturer=SIEMENS']['auc']:.2f}", f"{sub_ens['manufacturer=SIEMENS']['sensitivity']:.2f} / {sub_ens['manufacturer=SIEMENS']['specificity']:.2f}"],
    ["Ensemble, Philips CTs", "30 / 2", f"{sub_ens['manufacturer=Philips']['auc']:.2f}", f"{sub_ens['manufacturer=Philips']['sensitivity']:.2f} / {sub_ens['manufacturer=Philips']['specificity']:.2f}"],
    ["Leave-GE-out (trained on Siemens + Philips)", "146 / 19", auc_ci(m[LGE]), ss(m[LGE], "thr_youden")],
    ["Leave-Siemens-out (trained on GE + Philips)", "179 / 17", auc_ci(m[LSI]), ss(m[LSI], "thr_youden")],
    ["Leave-Philips-out (trained on GE + Siemens)", "30 / 2", auc_ci(m[LPH]), ss(m[LPH], "thr_youden")],
    ["Paired CT+PET subset: cross-attention", "133 / 9", auc_ci(m[PX]), ss(m[PX], "thr_youden")],
    ["Paired CT+PET subset: concatenation", "133 / 9", auc_ci(m[PCC]), ss(m[PCC], "thr_youden")],
    ["Paired CT+PET subset: CT only", "133 / 9", auc_ci(m[PC]), ss(m[PC], "thr_youden")],
    ["Paired CT+PET subset: PET only", "133 / 9", auc_ci(m[PP]), ss(m[PP], "thr_youden")],
]
t4cap = new_p([("Table 4. Subgroup, scanner-shift and paired-subset results. ", True, False), ("Subgroups are evaluated on the pooled out-of-fold predictions of the image-only ensemble; leave-one-manufacturer-out models are trained on the other two vendors; the paired subset uses the frozen-encoder head with three repeats.", False, False)])
t4 = new_table(["Analysis", "Patients / SCLC", "AUC (95% CI where estimable)", "Sens / Spec, Youden"], t4rows, [4200, 1300, 2000, 1500])
insert_after(E[120], [t4cap, t4])
robrows = [["PET removed at inference", "—", f"{rob_removed['auc_all']:.3f}", f"{rob_removed['auc_pet_patients']:.3f}", f"{rob_removed['sens']:.2f} / {rob_removed['spec']:.2f}"]]
for _, r in rob_shift.iterrows():
    robrows.append([f"PET shifted by {int(r['shift_fraction'] * 100)}% of field of view", f"{r['approx_shift_mm']:.0f} mm", f"{r['auc_all']:.3f}", f"{r['auc_pet_patients']:.3f}", f"{r['sens']:.2f} / {r['spec']:.2f}"])
t5cap = new_p([("Table 5. Robustness of the end-to-end model to CT/PET misalignment at inference ", True, False), ("(outer test folds, thresholds unchanged).", False, False)])
t5 = new_table(["Condition", "Translation", "AUC, all patients", "AUC, PET patients", "Sens / Spec, Youden"], robrows, [3200, 1200, 1500, 1500, 1600])
rob_txt = new_p([f"Robustness to misalignment. Translating the PET crop by 8–40 mm changed the pooled AUC of the end-to-end model by less than 0.01 ({rob_shift['auc_all'].min():.3f}–{rob_shift['auc_all'].max():.3f}), and removing PET altogether gave {rob_removed['auc_all']:.3f} (Table 5). The fused model is therefore insensitive to residual rigid misregistration, which also indicates that PET contributes little to the end-to-end model on this cohort."])
insert_after(t4, [rob_txt, t5cap, t5])
replace_p(E[121], [[("Fig 5. Calibration and clinical utility. ", True, False), ("(A) Reliability diagrams (quantile bins with 95% confidence intervals) of the image-only ensemble and the frozen cross-attention model after inner-fold Platt recalibration. (B) Decision curves against treat-all and treat-none strategies.", False, False)]])
insert_after(E[121], [new_p([("Fig 6. Explainability examples from an outer test fold. ", True, False), ("Grad-CAM of the CT encoder (penultimate stage) and of the PET encoder for the highest-ranked slices of correctly classified SCLC and NSCLC patients and of a missed SCLC patient, the PET SUV overlay, and the slice-level MIL attention profile against the radiologist-annotated slices. Further examples and the CT→PET cross-attention maps are given in S2 Fig.", False, False)])])

# --- discussion of ablations
replace_p(E[123], [["Fusion strategy"]])
replace_p(E[124], [["The submitted version argued that pixel-level early fusion lets CT gradients overshadow PET and that cross-attention repairs this. Under the leakage-free protocol the three fusion strategies, early fusion, concatenation of pooled modality features and token-level cross-attention, performed within 0.02 AUC of each other, well inside the ±0.03 spread we observed between repeats that differed only in augmentation seeds. We therefore no longer claim that cross-attention is superior; on 284 training patients with 30 SCLC cases, the fusion module cannot learn interactions that the simpler combinations miss, and the gain of the ensemble over any single model (about +0.03) is a variance-reduction effect rather than an architectural one."]])
replace_p(E[125], [["Contribution of PET, lesion size and the field of view"]])
replace_p(E[126], [[f"PET added {d_pet:+.3f} AUC over CT alone with the same pooling head (p = {p_pet:.2f}) and had no measurable effect on the end-to-end model (Table 5). Three facts explain this: PET exists for 37% of patients and only 9 SCLC patients, so the PET pathway is trained on very few positive examples; SUVmax did not separate the classes in this cohort (univariate AUC 0.51); and residual respiratory misalignment at the lung bases blurs the PET signal in exactly the patients where it is strongest. In contrast, absolute lesion size and surroundings were informative: lesion-relative crops that normalise size (the submitted design) performed worse on the inner folds than the fixed 160-mm field of view, and geometry alone reached an AUC of 0.67, in keeping with the larger, more central and more node-bearing presentation of small cell carcinoma (Table 2)."]])
replace_p(E[127], [["Patient-level aggregation and explainability"]])
replace_p(E[128], [["The gated-attention MIL weights were close to uniform in every trained model (maximum weight about 1/K; attention mass on radiologist-annotated slices equal to the uniform expectation), so the patient-level decision is effectively an average over the tumour-bearing slices rather than a selection of individual diagnostic slices; we report this rather than claim slice selection. Grad-CAM maps of the CT encoder concentrate on the lesion and the adjacent hilum and mediastinum in detected SCLC cases and on the lesion margin in NSCLC cases (Fig 6), and the PET encoder maps follow the hypermetabolic focus when PET is informative. The decision therefore rests on the intended anatomy, but the attention module as configured does not add interpretability beyond Grad-CAM."]])
replace_p(E[130], [[f"Inference for one patient (all candidate slices, both test-time-augmentation passes) took a median of {LATENCY_PATIENT} ms on the RTX 5090 laptop GPU, about {LATENCY_SLICE} ms per slice-equivalent, plus about 5 ms of CPU pre-processing; the frozen-encoder variant trains all 45 cross-validation models in under 15 minutes. Run-time is therefore not a barrier to use; discrimination and external validity are."]])
replace_p(E[132], [["The clinical question is whether an image-based SCLC probability can shorten the path to the correct first-line therapy. At the sensitivity-targeted operating point the image-only ensemble flags 29 of 38 SCLC patients while clearing 60% of NSCLC patients, and its negative predictive value of 0.95 means that a low score makes small cell histology unlikely but not excluded; adding the radiologist's T and N stage raises the AUC to 0.80 and specificity to 0.63 at the same sensitivity. The decision curves show net benefit only below a 20% threshold probability, i.e. the model can reasonably inform the urgency of histological confirmation but cannot replace it."]])
replace_p(E[133], [["We therefore present the framework as a proof of concept for weakly supervised CT/PET fusion rather than as a deployable triage tool. Before any clinical use it would need prospective external validation across institutions and scanners, integration with automated lesion detection, and a human-reader comparison, none of which the present data allow."]])
insert_after(E[133], [
    new_p(["Comparison with prior work"], style=H2),
    new_p([f"Table 6 places the results among published patient-level studies. To our knowledge the only previous patient-level, leakage-free results on this collection are an AUC of 0.69 for three-dimensional CT radiomics before synthetic oversampling [45] and 0.69 for an externally trained PET/CT network tested on a 44-patient Lung-PET-CT-Dx subset [46]; the present ensemble ({m[ENS]['auc']['value']:.2f}) and clinico-radiological model ({m[FUSE]['auc']['value']:.2f}) exceed these, although the confidence intervals overlap. Higher values reported on the same collection (0.94–0.98) rest on slice-level evaluation or synthetic minority oversampling [45,52] and are not comparable with patient-level estimates. Curated single-centre radiomics studies with manual three-dimensional segmentation and balanced or SCLC-rich cohorts report 0.80–0.93 [49–51,53,54], and even there squamous-versus-small-cell discrimination reaches only 0.78 [55]; our cohort has an 11% SCLC prevalence, three CT vendors, mixed slice thicknesses, incomplete PET and box annotations only, which is closer to the conditions of a referral population but harder. Beyond the numbers, the present study differs from all of these in handling missing PET explicitly, in documenting and stress-testing CT/PET alignment, and in reporting calibration and clinical utility, which none of the cited studies provide."]),
    new_p([("Table 6. Published patient-level results for SCLC versus NSCLC discrimination compared with the present study. ", True, False), ("AUCs as reported by the authors; CE-CT, contrast-enhanced CT; CV, cross-validation; OOF, out-of-fold. Slice-level results are listed for completeness but are not comparable with patient-level estimates.", False, False)]),
    new_table(["Study", "Cohort", "Patients (SCLC)", "Input", "Method / validation", "Unit of evaluation", "AUC"], [
        ["Dunn 2023 [45]", "Lung-PET-CT-Dx", "201 (30)", "CT", "3-D radiomics, 5-fold CV", "patient, before SMOTE", "0.69 (0.98 after SMOTE)"],
        ["Karimpour 2025 [46]", "single centre, external test on Lung-PET-CT-Dx", "44 (14)", "fused PET/CT", "2-D CNN, external test", "patient (majority vote)", "0.69 (0.98 internal)"],
        ["Shorfuzzaman 2026 [52]", "Lung-PET-CT-Dx", "350 (38)", "CT", "segmentation + CNN + LSTM, 5-fold CV", "slice", "≈0.95 (not comparable)"],
        ["Liu 2020 [49]", "single centre, CE-CT", "468 (202)", "CT", "radiomics + logistic regression, hold-out", "patient", "0.82 (0.94 with serum markers)"],
        ["Chen 2020 [50]", "single centre, peripheral tumours", "69 (35)", "CT", "radiomics + neural network, repeated splits", "patient", "0.93"],
        ["Varyukhina 2025 [51]", "single centre, balanced design", "200 (100)", "CT", "radiomics + gradient boosting, 5-fold CV", "patient", "0.89"],
        ["Kuzan 2026 [53]", "single centre", "99 (11)", "CT", "radiomics + CatBoost, k-fold CV", "patient", "0.80"],
        ["Huang 2023 [54]", "single centre", "852 (166)", "CT", "radiomics + random forest, hold-out", "patient (SCLC vs rest)", "0.88"],
        ["Li 2021 [55]", "single centre, central tumours", "200 (79)", "CE-CT", "radiomics, 10-fold CV", "patient (pairwise)", "0.84 vs ADC; 0.78 vs SCC"],
        ["This study, image-only ensemble", "Lung-PET-CT-Dx, 3 vendors", "355 (38)", "CT + optional PET", "dual-stream MIL, nested CV, frozen thresholds", "patient, OOF", auc_ci(m[ENS])],
        ["This study, imaging + T/N stage", "Lung-PET-CT-Dx, 3 vendors", "355 (38)", "CT + optional PET + stage", "late fusion, nested CV, frozen thresholds", "patient, OOF", auc_ci(m[FUSE])],
    ], [1500, 1750, 950, 1050, 1900, 1200, 1350], size=15),
    new_p(["Limitations"], style=H2),
    new_p(["This study has important limitations. First, it relies on a single public collection and the scanner-shift analysis is only a proxy for external validation; the drop to an AUC of 0.59 when the Siemens group is held out shows that acquisition protocol matters. Second, with 38 SCLC patients (9 with PET) the confidence intervals are wide and no comparison between model variants reaches significance; the paired CT+PET analysis is exploratory. Third, the framework requires radiologist tumour boxes at inference and was trained on tumour-bearing slices only, so it does not detect lesions. Fourth, respiratory-phase mismatch between breath-hold CT and free-breathing PET persists at the lung bases and cannot be removed by rigid alignment; deformable registration could not be evaluated meaningfully with nine SCLC PET cases. Fifth, the clinico-radiological model uses stage information whose provenance (clinical or pathological) the data providers do not specify, and we cannot exclude that some staging incorporated information unavailable at the time of imaging. Sixth, the MIL attention weights did not concentrate on specific slices, so interpretability rests on Grad-CAM alone. Finally, our earlier preprint described the cohort incorrectly; the corrected description and the stricter protocol lower the headline accuracy but, we believe, give a truthful picture of what CT/PET fusion can achieve on this benchmark."]),
])

# --- conclusions
replace_p(E[135], [[f"We evaluated a weakly supervised CT/PET fusion framework for patient-level discrimination of small cell from non-small cell lung cancer on the Lung-PET-CT-Dx collection under a nested, patient-level cross-validation protocol in which recalibration and decision thresholds were frozen before testing. The image-only ensemble reached an AUC of {m[ENS]['auc']['value']:.2f} (95% CI {m[ENS]['auc']['delong_ci'][0]:.2f}–{m[ENS]['auc']['delong_ci'][1]:.2f}) with SCLC sensitivity {op(m[ENS], 'thr_sens80', 'sensitivity'):.2f} at specificity {op(m[ENS], 'thr_sens80', 'specificity'):.2f}, was well calibrated, and offered net clinical benefit for threshold probabilities between 5% and 20%; adding radiologist-reported T and N stage raised the AUC to {m[FUSE]['auc']['value']:.2f}."]])
replace_p(E[136], [["Cross-attention did not outperform simpler fusion, PET contributed little in this cohort, and attention pooling behaved as averaging; what did matter was preserving absolute lesion size and context, handling the missing modality explicitly, recalibrating probabilities, and evaluating without leakage. To our knowledge this is the first leakage-free, missing-modality-tolerant and TRIPOD+AI-reported evaluation of CT/PET fusion for SCLC risk on a public collection, and the best patient-level result reported on this benchmark so far; it remains short of the discrimination needed for autonomous triage and defines the baseline against which future external, prospective evaluations of multimodal SCLC risk estimation should be measured."]])
replace_p(E[138], [["External and prospective validation on independent, multi-institutional PET/CT cohorts with sufficient SCLC cases, including a comparison with radiologist readers."]])
replace_p(E[139], [["Automated lesion detection and segmentation so that the pipeline no longer depends on manual bounding boxes, and three-dimensional or 2.5-dimensional encoders that use the full tumour volume."]])
replace_p(E[140], [["Deformable CT/PET registration and respiratory-phase-aware fusion, evaluated on cohorts with enough PET-positive SCLC cases to measure their effect."]])
replace_p(E[141], [["Self-supervised pre-training of the encoders on the roughly 250,000 unlabeled slices of this and related collections to replace ImageNet features."]])
replace_p(E[142], [["Prospective integration of clinical variables with documented provenance (clinical stage, smoking, tumour markers) in a pre-registered clinico-radiological model."]])

replace_p(E[144], [["This study used the publicly available Lung-PET-CT-Dx collection hosted by The Cancer Imaging Archive (https://doi.org/10.7937/TCIA.2020.NNC2-0461) [37]. No new imaging data were generated. The analysis code, the per-patient fold assignments, the out-of-fold predictions of every evaluated model, the frozen per-fold thresholds and recalibration parameters, and the alignment quality-control scores are provided as Supporting Information (S1 Data) and will be deposited in a public repository upon acceptance."]])

# --- new references and supporting information list (appended after the last reference)
new_refs = [
    "37. Li P, Wang S, Li T, Lu J, HuangFu Y, Wang D. A Large-Scale CT and PET/CT Dataset for Lung Cancer Diagnosis (Lung-PET-CT-Dx) [Data set]. The Cancer Imaging Archive; 2020. doi: 10.7937/TCIA.2020.NNC2-0461",
    "38. Collins GS, Moons KGM, Dhiman P, Riley RD, Beam AL, Van Calster B, et al. TRIPOD+AI statement: updated guidance for reporting clinical prediction models that use regression or machine learning methods. BMJ. 2024;385:e078378. doi: 10.1136/bmj-2023-078378",
    "39. DeLong ER, DeLong DM, Clarke-Pearson DL. Comparing the areas under two or more correlated receiver operating characteristic curves: a nonparametric approach. Biometrics. 1988;44(3):837-845.",
    "40. Vickers AJ, Elkin EB. Decision curve analysis: a novel method for evaluating prediction models. Med Decis Making. 2006;26(6):565-574. doi: 10.1177/0272989X06295361",
    "41. Van Calster B, McLernon DJ, van Smeden M, Wynants L, Steyerberg EW. Calibration: the Achilles heel of predictive analytics. BMC Med. 2019;17(1):230. doi: 10.1186/s12916-019-1466-7",
    "42. Platt JC. Probabilistic outputs for support vector machines and comparisons to regularized likelihood methods. In: Smola AJ, Bartlett P, Schölkopf B, Schuurmans D, editors. Advances in Large Margin Classifiers. Cambridge (MA): MIT Press; 1999. p. 61-74.",
    "43. Lin TY, Goyal P, Girshick R, He K, Dollár P. Focal loss for dense object detection. IEEE Trans Pattern Anal Mach Intell. 2020;42(2):318-327. doi: 10.1109/TPAMI.2018.2858826",
    "44. Lowekamp BC, Chen DT, Ibáñez L, Blezek D. The design of SimpleITK. Front Neuroinform. 2013;7:45. doi: 10.3389/fninf.2013.00045",
    "45. REF_DUNN",
    "46. REF_KARIMPOUR",
    "47. Hanley JA, McNeil BJ. The meaning and use of the area under a receiver operating characteristic (ROC) curve. Radiology. 1982;143(1):29-36. doi: 10.1148/radiology.143.1.7063747",
    "48. Wightman R. PyTorch Image Models (timm) [software]. GitHub; 2019. doi: 10.5281/zenodo.4414861",
    "49. REF_LIU",
    "50. REF_CHEN",
    "51. REF_VARYUKHINA",
    "52. REF_SHORFUZZAMAN",
    "53. Kuzan BN, Ilgin C, Emeç M, Yildiz HŞ, Geçmen GG, Baysal T. The role of using machine learning algorithms in non-contrast CT based images in determining pathological subtypes of lung cancer. Technol Cancer Res Treat. 2026;25:15330338261483507. doi: 10.1177/15330338261483507",
    "54. Huang J, He W, Xu H, Yang S, Dai J, Guo W, et al. Evaluating histological subtypes classification of primary lung cancers on unenhanced computed tomography based on random forest model. J Healthc Eng. 2023;2023:8964676. doi: 10.1155/2023/8964676",
    "55. Li H, Gao L, Ma H, Arefan D, He J, Wang J, et al. Radiomics-based features for prediction of histological subtypes in central lung cancer. Front Oncol. 2021;11:658887. doi: 10.3389/fonc.2021.658887",
]
refs_json = DOCS / "new_references.json"
if refs_json.exists():
    lookup = json.load(open(refs_json, encoding="utf-8"))
    new_refs = [lookup.get(r.split(". ", 1)[1], r) if r.split(". ", 1)[1].startswith("REF_") else r for r in new_refs]
last = E[183]
last = insert_after(last, [new_p([r]) for r in new_refs])
si = [
    ("Supporting information", H1),
    ("S1 Table. TRIPOD+AI checklist with the location of each item in the revised manuscript.", None),
    ("S2 Text. Sample-size and precision considerations.", None),
    ("S3 Table. Per-fold frozen decision thresholds and Platt recalibration parameters for every model.", None),
    ("S4 Table. Inner-fold selection of the input field of view and of the fusion variant (detail, context, whole-slice and mediastinal views; EfficientNet-B0 versus DINOv2 frozen features).", None),
    ("S5 Table. Complete results of all evaluated models including the paired CT+PET subset, with bootstrap confidence intervals for every metric.", None),
    ("S1 Fig. CT/PET alignment quality control: body-outline Dice and lung/soft-tissue uptake score for all 133 PET patients, with example overlays of registered and flagged cases.", None),
    ("S2 Fig. Additional Grad-CAM, cross-attention and MIL-attention examples from the outer test folds.", None),
    ("S1 Data. Analysis code, fold assignments, out-of-fold predictions, thresholds and alignment scores (archive).", None),
]
last = insert_after(last, [new_p([t], style=s) for t, s in si])

# ----------------------------------------------------------------------------- enable track-changes view and save
settings = OUT_DIR / "word" / "settings.xml"
st = etree.parse(str(settings)); root = st.getroot()
if root.find(q("trackRevisions")) is None:
    root.insert(0, etree.Element(q("trackRevisions")))
st.write(str(settings), xml_declaration=True, encoding="UTF-8", standalone=True)
tree.write(str(doc_path), xml_declaration=True, encoding="UTF-8", standalone=True)
if OUT_DOCX.exists():
    OUT_DOCX.unlink()
with zipfile.ZipFile(OUT_DOCX, "w", zipfile.ZIP_DEFLATED) as z:
    for f in sorted(OUT_DIR.rglob("*")):
        if f.is_file():
            z.write(f, f.relative_to(OUT_DIR).as_posix())
print("written", OUT_DOCX)
