"""
Step 7: robustness of a trained experiment to CT/PET misalignment and to missing PET.

Re-evaluates the saved fold models on their own outer test folds (so predictions stay out-of-fold) while
  (a) translating the PET crop relative to the CT crop by a fraction of the crop side (simulated residual
      rigid misregistration; the fraction is converted to millimetres using each patient's pixel spacing), and
  (b) switching PET off entirely for patients who have it (missing-modality behaviour).

  python 07_robustness.py --name proposed_all --shifts 0 0.05 0.10 0.15 0.25
"""
import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from sklearn.metrics import roc_auc_score

from common import MILFusionNet, load_cohort, predict, HERE, STORE, EVAL_REL, VIEWS

RESULTS = HERE / "results"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--name", required=True)
    ap.add_argument("--shifts", nargs="*", type=float, default=[0.0, 0.05, 0.10, 0.15, 0.25])
    ap.add_argument("--rep", type=int, default=0)
    args = ap.parse_args()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    out_dir = RESULTS / args.name / "robustness"; out_dir.mkdir(parents=True, exist_ok=True)
    meta = json.load(open(RESULTS / args.name / "folds.json", encoding="utf-8"))
    cfg = meta["config"]
    oof = pd.read_csv(RESULTS / args.name / "oof_predictions.csv")
    oof = oof[oof["rep"] == args.rep]
    recs = {r.pid: r for r in load_cohort(verbose=False)}
    # crop side in mm for PET patients: EVAL_REL * STORE store-pixels; store pixel = side_px / STORE native pixels
    cs = pd.read_csv(HERE / "index" / "cache_summary.csv")
    rows = []
    conditions = [("pet_shift", s) for s in args.shifts] + [("pet_removed", None)]
    for fold_info in meta["folds"]:
        if fold_info["rep"] != args.rep:
            continue
        fold = fold_info["fold"]; T = fold_info["temperature"]; thr = fold_info["thresholds"]
        test_pids = oof[oof["fold"] == fold]["pid"].tolist()
        test_recs = [recs[p] for p in test_pids]
        models = []
        view = cfg.get("view", "detail")
        for j in range(cfg["inner"]):
            m = MILFusionNet(cfg["backbone"], fusion=cfg["fusion"], pretrained=False, views=len(VIEWS[view]), use_geom=cfg.get("geom", False))
            sd = torch.load(RESULTS / args.name / "models" / f"r{args.rep}f{fold}i{j}.pt", map_location="cpu")
            m.load_state_dict({k: v.float() if v.is_floating_point() else v for k, v in sd.items()})
            models.append(m.to(device).eval())
        for cond, val in conditions:
            logits = []
            for m in models:
                if cond == "pet_shift":
                    pv = predict(m, test_recs, device, use_pet=not cfg["no_pet"], bag_size_eval=cfg["final_eval_slices"], pet_shift_px=val, view=view)
                else:
                    pv = predict(m, test_recs, device, use_pet=False, bag_size_eval=cfg["final_eval_slices"], view=view)
                logits.append(np.array([p["logit"] for p in pv]))
            p_cal = (1 / (1 + np.exp(-np.stack(logits) / T))).mean(0)
            for k, r in enumerate(test_recs):
                rows.append({"pid": r.pid, "label": r.label, "fold": fold, "condition": cond, "value": val, "prob_cal": float(p_cal[k]),
                             "thr_youden": thr["youden"], "thr_sens80": thr["sens80"], "has_pet": r.has_pet})
        print(f"fold {fold} done", flush=True)
        models = None; torch.cuda.empty_cache()
    df = pd.DataFrame(rows); df.to_csv(out_dir / "predictions.csv", index=False)

    # approximate mm per shift fraction: crop side = EVAL_REL * window side; window side (native px) = STORE-window / scale.
    # We stored boxes in STORE coordinates; recover window side from meta: side_px = max(box)*EXPAND_STORE etc. Use median over PET patients.
    mm = []
    for pid, r in recs.items():
        if not r.has_pet:
            continue
        b = r.boxes[0]; box_store = max(b[2] - b[0], b[3] - b[1])
        # box_store = box_native * STORE / side_native  and side_native = max(box_native*EXPAND_STORE, MIN_SIDE) ->
        # for the common case side_native = box_native*EXPAND_STORE: side_native = box_native*2.6 => box_store = STORE/2.6 (~98 px)
        spacing = cs.loc[cs["pid"] == pid]
        # use native pixel spacing from meta.json
        mj = json.load(open(HERE / "cache" / pid / "meta.json", encoding="utf-8"))
        ps = float(mj["ct_spacing_row_col"][0])
        side_native = (STORE / box_store) * (max((b[2] - b[0]), (b[3] - b[1])) / (STORE / STORE)) if box_store > 0 else np.nan
        # simpler and exact: side_native_px = STORE * ps_native / ps_store; ps_store = side_native/STORE -> circular; so compute from boxes:
        # box native px = box_store * side_native / STORE; EXPAND rule: side_native = max(box_native*2.6, 96)
        # => if side_native = box_native*2.6: box_store = STORE/2.6; else side_native = 96.
        side_native = 96.0 if abs(box_store - STORE / 2.6) > 1.0 else None
        if side_native is None:
            # box_native unknown directly; use annotated box size from meta (first candidate with boxes)
            bx = next((s["boxes"][0] for s in mj["slices"] if s["boxes"]), None)
            if bx is None:
                continue
            side_native = max(max(bx[2] - bx[0], bx[3] - bx[1]) * 2.6, 96.0)
        mm.append(EVAL_REL * side_native * ps)
    crop_mm = float(np.median(mm)) if mm else float("nan")
    from common import CTX_EVAL_REL, CTX_STORE_MM, WHOLE_EVAL_REL
    view0 = VIEWS[cfg.get("view", "detail")][0]
    if view0 == "context":
        crop_mm = CTX_EVAL_REL * CTX_STORE_MM            # 160 mm field of view
    elif view0 in ("whole", "medi"):
        crop_mm = float("nan")

    summary = []
    for (cond, val), d in df.groupby(["condition", "value"], dropna=False):
        y = d["label"].values; p = d["prob_cal"].values
        pred = (p >= d["thr_youden"].values).astype(int)
        tp = ((pred == 1) & (y == 1)).sum(); fn = ((pred == 0) & (y == 1)).sum(); tn = ((pred == 0) & (y == 0)).sum(); fp = ((pred == 1) & (y == 0)).sum()
        dp = d[d["has_pet"]]
        summary.append({"condition": cond, "shift_fraction": val, "approx_shift_mm": (val * crop_mm) if cond == "pet_shift" else None,
                        "auc_all": roc_auc_score(y, p), "sens": tp / max(tp + fn, 1), "spec": tn / max(tn + fp, 1),
                        "bacc": (tp / max(tp + fn, 1) + tn / max(tn + fp, 1)) / 2,
                        "auc_pet_patients": roc_auc_score(dp["label"], dp["prob_cal"]) if dp["label"].nunique() > 1 else np.nan,
                        "n_pet_patients": int(len(dp))})
    s = pd.DataFrame(summary); s.to_csv(out_dir / "summary.csv", index=False)
    print(f"median evaluation crop side ~ {crop_mm:.0f} mm")
    print(s.to_string(index=False))


if __name__ == "__main__":
    main()
