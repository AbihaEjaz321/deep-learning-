"""
Step 12: nested CV for the fusion / MIL head trained on frozen encoder token features (from 11_extract_features.py).

Same protocol as 04_train_cv.py (5 outer x 3 inner patient-stratified folds, thresholds + temperature frozen on the
inner out-of-fold predictions, flip TTA), but the EfficientNet encoders are kept frozen so that only the projections,
cross-attention, gated-attention MIL pooling and classifier are trained. Training a model takes seconds, which allows
repeats and inner-fold-driven hyper-parameter selection without over-fitting the backbones.

  python 12_train_frozen.py --name frozen_xattn_all --fusion xattn --view all --repeats 3
"""
import argparse
import copy
import json
import math
import random
import time
from pathlib import Path

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import RepeatedStratifiedKFold, StratifiedKFold
from torch.utils.data import DataLoader, WeightedRandomSampler

from common import (CrossModalBlock, GatedAttention, WeightedBCE, WeightedFocalLoss, fit_temperature, load_cohort,
                    seed_everything, select_thresholds, HERE, VIEWS, GEOM_DIM)

RESULTS = HERE / "results"
FEAT = HERE / "feat"


def get_args():
    ap = argparse.ArgumentParser()
    ap.add_argument("--name", required=True)
    ap.add_argument("--tag", default="b0", help="feature set under feat/")
    ap.add_argument("--fusion", default="xattn", choices=["xattn", "concat", "ct_only", "pet_only"])
    ap.add_argument("--view", default="all", choices=list(VIEWS.keys()))
    ap.add_argument("--cohort", default="all", choices=["all", "paired"])
    ap.add_argument("--no_pet", action="store_true")
    ap.add_argument("--geom", action="store_true")
    ap.add_argument("--loss", default="focal", choices=["focal", "bce"])
    ap.add_argument("--alpha", type=float, default=0.6); ap.add_argument("--gamma", type=float, default=2.0)
    ap.add_argument("--label_smoothing", type=float, default=0.05)
    ap.add_argument("--sampler", default="inverse", choices=["inverse", "none"])
    ap.add_argument("--folds", type=int, default=5); ap.add_argument("--repeats", type=int, default=3); ap.add_argument("--inner", type=int, default=3)
    ap.add_argument("--epochs", type=int, default=40); ap.add_argument("--patience", type=int, default=10); ap.add_argument("--min_epochs", type=int, default=10)
    ap.add_argument("--select", default="best", choices=["best", "last"])
    ap.add_argument("--K", type=int, default=8); ap.add_argument("--batch", type=int, default=16)
    ap.add_argument("--lr", type=float, default=3e-4); ap.add_argument("--wd", type=float, default=0.05)
    ap.add_argument("--d", type=int, default=256); ap.add_argument("--heads", type=int, default=8)
    ap.add_argument("--dropout", type=float, default=0.3); ap.add_argument("--token_drop", type=float, default=0.1)
    ap.add_argument("--feat_noise", type=float, default=0.05, help="gaussian noise (relative) added to training tokens")
    ap.add_argument("--mdrop", type=float, default=0.25)
    ap.add_argument("--ema", type=float, default=0.99)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--lomo", default=None)
    ap.add_argument("--eval_slices", type=int, default=48)
    ap.add_argument("--no_save_models", action="store_true")
    return ap.parse_args()


# ------------------------------------------------------------------------------- data
class FeatStore:
    """All token features in RAM as float16 tensors: ct[pid] -> (n_slices, n_versions, V, T, C)."""
    def __init__(self, recs, tag, views):
        self.root = FEAT / tag; self.views = views
        meta = json.load(open(self.root / "meta.json")); self.n_ver = meta["n_versions"]; self.dim = meta["dim"]
        self.ct = {}; self.pt = {}
        t0 = time.time()
        for i, r in enumerate(recs):
            self.ct[r.pid] = torch.from_numpy(np.stack([np.load(self.root / r.pid / f"{v}_ct.npy") for v in views], axis=2))
            if r.has_pet:
                self.pt[r.pid] = torch.from_numpy(np.stack([np.load(self.root / r.pid / f"{v}_pt.npy") for v in views], axis=2))
            if (i + 1) % 100 == 0:
                print(f"  features loaded {i + 1}/{len(recs)} ({time.time() - t0:.0f}s)", flush=True)
        self.T = next(iter(self.ct.values())).shape[3]


class FrozenBagDataset(torch.utils.data.Dataset):
    def __init__(self, recs, store, train, K=8, use_pet=True, mdrop=0.25, eval_max=48, seed=0, version=None):
        self.recs = recs; self.s = store; self.train = train; self.K = K; self.use_pet = use_pet; self.mdrop = mdrop
        self.eval_max = eval_max; self.rng = random.Random(seed); self.version = version

    def __len__(self):
        return len(self.recs)

    def __getitem__(self, i):
        r = self.recs[i]; n = r.n_slices
        if self.train:
            ks = self.rng.sample(range(n), self.K) if n >= self.K else [self.rng.randrange(n) for _ in range(self.K)]
        else:
            ks = list(range(n)) if n <= self.eval_max else [int(round(t)) for t in np.linspace(0, n - 1, self.eval_max)]
        pet_present = bool(self.use_pet and r.has_pet)
        if self.train and pet_present and self.rng.random() < self.mdrop:
            pet_present = False
        if self.version is not None:
            vers = [self.version] * len(ks)
        elif self.train:
            vers = [self.rng.randrange(self.s.n_ver) for _ in ks]
        else:
            vers = [0] * len(ks)
        ks_t = torch.tensor(ks); vers_t = torch.tensor(vers)
        ct = self.s.ct[r.pid][ks_t, vers_t]                                    # (K, V, T, C) float16
        pt = self.s.pt[r.pid][ks_t, vers_t] if pet_present else torch.zeros_like(ct)
        return ct, pt, torch.tensor(pet_present), torch.tensor(float(r.label)), r.pid, ks_t, torch.from_numpy(r.geom)


def collate(batch):
    K = max(b[0].shape[0] for b in batch); B = len(batch)
    ct = torch.zeros((B, K) + batch[0][0].shape[1:], dtype=torch.float16); pt = torch.zeros_like(ct); mask = torch.zeros(B, K, dtype=torch.bool)
    pm = torch.zeros(B, dtype=torch.bool); y = torch.zeros(B); pids = []; idxs = []; geom = torch.zeros(B, GEOM_DIM)
    for i, (c, p, m, yy, pid, ks, g) in enumerate(batch):
        n = c.shape[0]; ct[i, :n] = c; pt[i, :n] = p; mask[i, :n] = True; pm[i] = m; y[i] = yy; geom[i] = g; pids.append(pid); idxs.append(ks)
    return ct, pt, pm, mask, y, pids, idxs, geom


# ------------------------------------------------------------------------------- model
class FrozenFusionHead(nn.Module):
    def __init__(self, in_dim, fusion="xattn", d=256, heads=8, drop=0.3, token_drop=0.1, views=1, use_geom=False):
        super().__init__()
        self.fusion = fusion; self.d = d; self.views = views; self.use_geom = use_geom
        self.token_drop = nn.Dropout(token_drop)
        if fusion != "pet_only":
            self.proj_ct = nn.Sequential(nn.LayerNorm(in_dim), nn.Linear(in_dim, d))
        if fusion != "ct_only":
            self.proj_pt = nn.Sequential(nn.LayerNorm(in_dim), nn.Linear(in_dim, d))
        if fusion == "xattn":
            self.x_ct = CrossModalBlock(d, heads, drop * 0.5); self.x_pt = CrossModalBlock(d, heads, drop * 0.5)
        self.missing_pt = nn.Parameter(torch.zeros(d))
        emb = (d if fusion in ("ct_only", "pet_only") else 2 * d) * views
        self.mil = GatedAttention(emb, 128, drop * 0.5)
        head_in = emb + (32 if use_geom else 0)
        if use_geom:
            self.geom_mlp = nn.Sequential(nn.Linear(GEOM_DIM, 32), nn.GELU(), nn.Dropout(drop * 0.5))
        self.head = nn.Sequential(nn.LayerNorm(head_in), nn.Dropout(drop), nn.Linear(head_in, 1))

    def forward(self, ct, pt, pet_mask, slice_mask, geom=None, return_attn=False):
        B, K, V, T, C = ct.shape
        pm = pet_mask.repeat_interleave(K * V).unsqueeze(-1)
        xw = None
        if self.fusion == "pet_only":
            z = self.proj_pt(self.token_drop(pt.flatten(0, 2))).mean(1).view(B, K, -1)
        else:
            t_ct = self.proj_ct(self.token_drop(ct.flatten(0, 2)))
            z_ct_self = t_ct.mean(1)
            if self.fusion == "ct_only":
                z = z_ct_self.view(B, K, -1)
            else:
                t_pt = self.proj_pt(self.token_drop(pt.flatten(0, 2)))
                z_pt_self = t_pt.mean(1)
                if self.fusion == "xattn":
                    a_ct, w_ct = self.x_ct(t_ct, t_pt, need_weights=return_attn); a_pt, w_pt = self.x_pt(t_pt, t_ct, need_weights=return_attn)
                    z_ct = torch.where(pm, a_ct.mean(1), z_ct_self); z_pt = torch.where(pm, a_pt.mean(1), self.missing_pt.expand_as(z_pt_self))
                    xw = (w_ct, w_pt) if return_attn else None
                else:
                    z_ct = z_ct_self; z_pt = torch.where(pm, z_pt_self, self.missing_pt.expand_as(z_pt_self))
                z = torch.cat([z_ct.view(B * K, V * self.d), z_pt.view(B * K, V * self.d)], 1).view(B, K, -1)
        bag, a = self.mil(z, slice_mask)
        if self.use_geom:
            bag = torch.cat([bag, self.geom_mlp(geom.to(bag.dtype))], 1)
        return self.head(bag).squeeze(-1), a, xw


class EMA:
    def __init__(self, model, decay):
        self.m = copy.deepcopy(model).eval(); self.decay = decay; self.n = 0
        for p in self.m.parameters():
            p.requires_grad_(False)

    @torch.no_grad()
    def update(self, model):
        self.n += 1; d = min(self.decay, (1 + self.n) / (10 + self.n)); msd = model.state_dict()
        for k, v in self.m.state_dict().items():
            v.mul_(d).add_(msd[k].detach(), alpha=1 - d) if v.dtype.is_floating_point else v.copy_(msd[k])


@torch.no_grad()
def predict(model, recs, store, device, use_pet, eval_max, tta=True, return_attention=False):
    model.eval(); out = []
    for ver in ([0, 1] if tta else [0]):
        ds = FrozenBagDataset(recs, store, train=False, use_pet=use_pet, eval_max=eval_max, version=ver)
        dl = DataLoader(ds, batch_size=8, shuffle=False, collate_fn=collate)
        res = []
        for ct, pt, pm, mask, y, pids, idxs, geom in dl:
            logit, a, _ = model(ct.to(device).float(), pt.to(device).float(), pm.to(device), mask.to(device), geom.to(device))
            for i, pid in enumerate(pids):
                n = int(mask[i].sum()); rec = {"pid": pid, "label": int(y[i]), "logit": float(logit[i]), "pet_used": bool(pm[i])}
                if return_attention:
                    rec["attention"] = a[i, :n].cpu().numpy().tolist(); rec["slice_idx"] = idxs[i].tolist()
                res.append(rec)
        out.append(res)
    final = out[0]
    if tta:
        for r0, r1 in zip(out[0], out[1]):
            r0["logit"] = 0.5 * (r0["logit"] + r1["logit"])
    return final


def safe_auc(y, s):
    return float(roc_auc_score(y, s)) if len(np.unique(y)) > 1 else float("nan")


def train_one(tr, va, store, args, device, seed, tag, log):
    seed_everything(seed)
    ds = FrozenBagDataset(tr, store, train=True, K=args.K, use_pet=not args.no_pet, mdrop=args.mdrop, seed=seed)
    labels = np.array([r.label for r in tr])
    if args.sampler == "inverse":
        w = 1.0 / np.bincount(labels, minlength=2)[labels]
        sampler = WeightedRandomSampler(torch.tensor(w / w.sum(), dtype=torch.double), len(tr), replacement=True, generator=torch.Generator().manual_seed(seed))
        dl = DataLoader(ds, batch_size=args.batch, sampler=sampler, collate_fn=collate, drop_last=True)
    else:
        dl = DataLoader(ds, batch_size=args.batch, shuffle=True, collate_fn=collate, drop_last=True)
    model = FrozenFusionHead(store.dim, args.fusion, args.d, args.heads, args.dropout, args.token_drop, len(store.views), args.geom).to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.wd)
    steps = max(len(dl), 1) * args.epochs; warm = max(len(dl), 1)
    sched = torch.optim.lr_scheduler.LambdaLR(opt, lambda s: (s + 1) / warm if s < warm else 0.5 * (1 + math.cos(math.pi * (s - warm) / max(steps - warm, 1))))
    n_pos = labels.sum(); n_neg = len(labels) - n_pos
    crit = WeightedFocalLoss(args.alpha, args.gamma, args.label_smoothing) if args.loss == "focal" else \
        WeightedBCE((n_neg / max(n_pos, 1)) if args.sampler == "none" else 1.0, args.label_smoothing).to(device)
    ema = EMA(model, args.ema); val_y = np.array([r.label for r in va])
    best = {"score": -1e9, "epoch": 0, "state": None, "auc": float("nan"), "loss": float("nan")}; bad = 0; hist = []
    for epoch in range(1, args.epochs + 1):
        model.train(); run = 0.0; nb = 0
        for ct, pt, pm, mask, y, _, _, geom in dl:
            ct = ct.to(device).float(); pt = pt.to(device).float()
            if args.feat_noise > 0:
                ct = ct + args.feat_noise * ct.std() * torch.randn_like(ct); pt = pt + args.feat_noise * (pt.std() + 1e-6) * torch.randn_like(pt)
            logit, _, _ = model(ct, pt, pm.to(device), mask.to(device), geom.to(device))
            loss = crit(logit, y.to(device)); opt.zero_grad(set_to_none=True); loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0); opt.step(); sched.step(); ema.update(model)
            run += loss.item(); nb += 1
        pv = predict(ema.m, va, store, device, not args.no_pet, args.eval_slices, tta=False)
        vl = np.array([p["logit"] for p in pv]); v_auc = safe_auc(val_y, vl)
        v_loss = float(nn.functional.binary_cross_entropy_with_logits(torch.tensor(vl), torch.tensor(val_y, dtype=torch.float32)))
        score = (0.0 if math.isnan(v_auc) else v_auc) - 0.05 * v_loss
        hist.append({"epoch": epoch, "train_loss": run / max(nb, 1), "val_auc": v_auc, "val_loss": v_loss})
        if args.select == "last" or score > best["score"] + 1e-6:
            best = {"score": score, "epoch": epoch, "state": copy.deepcopy(ema.m.state_dict()), "auc": v_auc, "loss": v_loss}; bad = 0
        else:
            bad += 1
            if epoch >= args.min_epochs and bad >= args.patience:
                break
    ema.m.load_state_dict(best["state"])
    log(f"    [{tag}] best epoch {best['epoch']}/{len(hist)} val_auc={best['auc']:.3f} val_loss={best['loss']:.3f}")
    return ema.m, best, hist


def main():
    args = get_args()
    out = RESULTS / args.name; out.mkdir(parents=True, exist_ok=True); (out / "models").mkdir(exist_ok=True)
    logf = open(out / "train_log.txt", "a", encoding="utf-8")

    def log(msg):
        print(msg, flush=True); logf.write(msg + "\n"); logf.flush()

    log(f"=== {args.name} === {json.dumps(vars(args))}")
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu"); torch.set_num_threads(6)
    seed_everything(args.seed)
    recs = load_cohort(verbose=False)
    if args.cohort == "paired":
        recs = [r for r in recs if r.has_pet]
    store = FeatStore(recs, args.tag, VIEWS[args.view])
    labels = np.array([r.label for r in recs])
    log(f"patients={len(recs)} SCLC={int(labels.sum())} with_pet={sum(r.has_pet for r in recs)} views={store.views} T={store.T} dim={store.dim} versions={store.n_ver}")
    if args.lomo:
        man = np.array([(r.manufacturer or "").upper() for r in recs]); te = np.where(np.char.find(man, args.lomo.upper()) >= 0)[0]
        splits = [(0, 0, np.setdiff1d(np.arange(len(recs)), te), te)]
    else:
        rskf = RepeatedStratifiedKFold(n_splits=args.folds, n_repeats=args.repeats, random_state=args.seed)
        splits = [(i // args.folds, i % args.folds, tr, te) for i, (tr, te) in enumerate(rskf.split(np.zeros(len(recs)), labels))]
    rows, finfo = [], []; t0 = time.time()
    for rep, fold, tr_idx, te_idx in splits:
        tag0 = f"r{rep}f{fold}"; tr = [recs[i] for i in tr_idx]; te = [recs[i] for i in te_idx]; tr_y = labels[tr_idx]
        inner = StratifiedKFold(args.inner, shuffle=True, random_state=args.seed + 1000 * rep + fold)
        inner_oof = np.full(len(tr), np.nan); test_logits = []; imeta = []
        for j, (itr, iva) in enumerate(inner.split(np.zeros(len(tr)), tr_y)):
            model, best, hist = train_one([tr[k] for k in itr], [tr[k] for k in iva], store, args, device, args.seed + 7 * j + 100 * fold + 10000 * rep, f"{tag0}i{j}", log)
            inner_oof[iva] = [p["logit"] for p in predict(model, [tr[k] for k in iva], store, device, not args.no_pet, args.eval_slices)]
            test_logits.append(np.array([p["logit"] for p in predict(model, te, store, device, not args.no_pet, args.eval_slices)]))
            imeta.append({"inner": j, "best_epoch": best["epoch"], "val_auc": best["auc"], "val_loss": best["loss"], "history": hist})
            if not args.no_save_models:
                torch.save({k: v.half() if v.is_floating_point() else v for k, v in model.state_dict().items()}, out / "models" / f"{tag0}i{j}.pt")
        T = fit_temperature(inner_oof, tr_y); thr = select_thresholds(1 / (1 + np.exp(-inner_oof / T)), tr_y, 0.80)
        pd.DataFrame({"pid": [r.pid for r in tr], "label": tr_y, "rep": rep, "fold": fold, "logit": inner_oof,
                      "prob_cal": 1 / (1 + np.exp(-inner_oof / T))}).to_csv(out / f"inner_oof_r{rep}f{fold}.csv", index=False)
        tl = np.stack(test_logits); p_cal = (1 / (1 + np.exp(-tl / T))).mean(0); p_raw = (1 / (1 + np.exp(-tl))).mean(0); te_y = labels[te_idx]
        info = {"rep": rep, "fold": fold, "n_train": len(tr), "n_test": len(te), "test_sclc": int(te_y.sum()), "temperature": T, "thresholds": thr,
                "inner_oof_auc": safe_auc(tr_y, inner_oof), "test_auc": safe_auc(te_y, p_cal), "inner": imeta, "minutes": round((time.time() - t0) / 60, 1)}
        finfo.append(info)
        log(f"  >> {tag0}: inner-OOF AUC={info['inner_oof_auc']:.4f} T={T:.3f} | TEST AUC={info['test_auc']:.4f} ({info['minutes']} min)")
        for k, r in enumerate(te):
            rows.append({"pid": r.pid, "label": int(r.label), "group": r.group, "rep": rep, "fold": fold, "prob_cal": float(p_cal[k]), "prob_raw": float(p_raw[k]),
                         "logit_mean": float(tl[:, k].mean()), "temperature": T, "thr_youden": thr["youden"], "thr_f1max": thr["f1max"], "thr_sens80": thr["sens80"],
                         "has_pet": bool(r.has_pet), "pet_used": bool(r.has_pet and not args.no_pet), "manufacturer": r.manufacturer, "n_slices": r.n_slices,
                         "fallback_roi": bool(r.fallback_roi)})
        pd.DataFrame(rows).to_csv(out / "oof_predictions.csv", index=False)
        cfg = dict(vars(args)); cfg.update({"backbone": f"frozen:{args.tag}", "final_eval_slices": args.eval_slices})
        json.dump({"config": cfg, "folds": finfo}, open(out / "folds.json", "w", encoding="utf-8"), indent=1)
    df = pd.DataFrame(rows)
    inner_mean = np.nanmean([f["inner_oof_auc"] for f in finfo])
    for rep, d in df.groupby("rep"):
        y = d["label"].values; p = d["prob_cal"].values; pred = (p >= d["thr_youden"].values).astype(int)
        tp = ((pred == 1) & (y == 1)).sum(); fn = ((pred == 0) & (y == 1)).sum(); tn = ((pred == 0) & (y == 0)).sum(); fp = ((pred == 1) & (y == 0)).sum()
        log(f"rep {rep}: AUC={safe_auc(y, p):.4f} sens={tp / max(tp + fn, 1):.3f} spec={tn / max(tn + fp, 1):.3f} bacc={(tp / max(tp + fn, 1) + tn / max(tn + fp, 1)) / 2:.3f}")
    log(f"mean inner-OOF AUC={inner_mean:.4f} | total minutes: {(time.time() - t0) / 60:.1f}")
    logf.close()


if __name__ == "__main__":
    main()
