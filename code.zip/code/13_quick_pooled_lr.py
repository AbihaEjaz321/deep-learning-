"""Quick diagnostic: nested-CV logistic regression on mean-pooled frozen encoder features (+ optional geometry)."""
import json
import sys
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import RepeatedStratifiedKFold, StratifiedKFold, GridSearchCV
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

HERE = Path(__file__).resolve().parent
FEAT = HERE / "feat" / (sys.argv[1] if len(sys.argv) > 1 else "b0")
cs = pd.read_csv(HERE / "index" / "cache_summary.csv")
hand = pd.read_csv(HERE / "index" / "handcrafted_features.csv").set_index("pid")
X, y, pids, haspet = {}, [], [], []
blocks = {"ct_detail": [], "ct_context": [], "pt_detail": [], "pt_context": []}
for pdir in sorted(FEAT.iterdir()):
    if not pdir.is_dir():
        continue
    pid = pdir.name
    row = cs[cs["pid"] == pid].iloc[0]
    for view in ("detail", "context"):
        f = np.load(pdir / f"{view}_ct.npy", mmap_mode="r")[:, 0]          # version 0 = canonical crop
        blocks[f"ct_{view}"].append(np.asarray(f, dtype=np.float32).mean(axis=(0, 1)))
        if (pdir / f"{view}_pt.npy").exists():
            g = np.load(pdir / f"{view}_pt.npy", mmap_mode="r")[:, 0]
            blocks[f"pt_{view}"].append(np.asarray(g, dtype=np.float32).mean(axis=(0, 1)))
        else:
            blocks[f"pt_{view}"].append(np.zeros(f.shape[-1], np.float32))
    y.append(int(row["label"])); pids.append(pid); haspet.append(bool(row["has_pet"]))
y = np.array(y); haspet = np.array(haspet, dtype=np.float32)
geom = np.stack([hand.loc[p, ["log_diam", "log_extent", "log_area"]].values.astype(np.float32) if p in hand.index else np.array([3.9, 3.0, 2.5], np.float32) for p in pids])
B = {k: np.stack(v) for k, v in blocks.items()}


def nested(Xmat, name, n_comp=32):
    rskf = RepeatedStratifiedKFold(n_splits=5, n_repeats=2, random_state=42)
    oof = np.zeros((2, len(y))); inner_aucs = []
    for i, (tr, te) in enumerate(rskf.split(Xmat, y)):
        rep = i // 5
        pipe = make_pipeline(StandardScaler(), PCA(n_components=min(n_comp, len(tr) - 1), random_state=0),
                             LogisticRegression(class_weight="balanced", max_iter=3000))
        gs = GridSearchCV(pipe, {"logisticregression__C": [0.003, 0.01, 0.03, 0.1, 0.3, 1.0]}, scoring="roc_auc",
                          cv=StratifiedKFold(3, shuffle=True, random_state=i), n_jobs=4)
        gs.fit(Xmat[tr], y[tr]); inner_aucs.append(gs.best_score_)
        oof[rep, te] = gs.predict_proba(Xmat[te])[:, 1]
    aucs = [roc_auc_score(y, oof[r]) for r in range(2)]
    print(f"{name:34s} dims={Xmat.shape[1]:5d}  inner-CV AUC={np.mean(inner_aucs):.3f}  pooled OOF AUC rep0={aucs[0]:.3f} rep1={aucs[1]:.3f}")


nested(B["ct_detail"], "CT detail")
nested(B["ct_context"], "CT context")
nested(np.hstack([B["ct_detail"], B["ct_context"]]), "CT detail+context")
nested(np.hstack([B["ct_detail"], B["ct_context"], geom]), "CT both + geometry")
nested(np.hstack([B["ct_detail"], B["ct_context"], B["pt_detail"], B["pt_context"], haspet[:, None]]), "CT+PET both views")
nested(np.hstack([B["ct_detail"], B["ct_context"], B["pt_detail"], B["pt_context"], haspet[:, None], geom]), "CT+PET both + geometry")
m = haspet > 0
print(f"\nPET subset n={m.sum()} SCLC={int(y[m].sum())}")
