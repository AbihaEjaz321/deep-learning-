"""
Step 14: out-of-fold ensemble of several experiments that used the same outer folds (same --seed/--folds/--repeats).

For every outer fold the member models' calibrated inner-OOF probabilities (outer-training patients only) are averaged
to re-select the thresholds, which are then applied to the averaged calibrated test-fold probabilities. No test label is
used, so the ensemble stays a legitimate out-of-fold estimate. Writes results/<out_name>/ in the standard format.

  python 14_ensemble.py --out ens_main --members ft_ctx_reg frz_xattn_ctx_whole baseline_ctpet_handcrafted_logreg
"""
import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import roc_auc_score

from common import select_thresholds, HERE

RESULTS = HERE / "results"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True); ap.add_argument("--members", nargs="+", required=True)
    ap.add_argument("--weights", nargs="*", type=float, default=None)
    args = ap.parse_args()
    w = np.array(args.weights or [1.0] * len(args.members)); w = w / w.sum()
    oofs = [pd.read_csv(RESULTS / m / "oof_predictions.csv") for m in args.members]
    base = oofs[0][["pid", "label", "group", "rep", "fold", "has_pet", "manufacturer", "n_slices", "fallback_roi"]].copy()
    for m, d in zip(args.members, oofs):
        chk = base.merge(d[["pid", "rep", "fold"]], on=["pid", "rep"], suffixes=("", "_m"))
        if (chk["fold"] != chk["fold_m"]).any() or len(chk) != len(base):
            raise SystemExit(f"{m}: outer folds differ from {args.members[0]}; ensemble not valid")
    probs = np.zeros(len(base))
    for wi, d in zip(w, oofs):
        probs += wi * base.merge(d[["pid", "rep", "prob_cal"]], on=["pid", "rep"])["prob_cal"].values
    base["prob_cal"] = probs; base["prob_raw"] = probs; base["pet_used"] = base["has_pet"]
    rows = []; finfo = []
    for (rep, fold), d in base.groupby(["rep", "fold"]):
        inner = None
        for wi, m in zip(w, args.members):
            f = RESULTS / m / f"inner_oof_r{rep}f{fold}.csv"
            if not f.exists():
                raise SystemExit(f"missing {f} (re-run {m} with the updated trainer to log inner-fold predictions)")
            io = pd.read_csv(f)[["pid", "label", "prob_cal"]].rename(columns={"prob_cal": m})
            inner = io if inner is None else inner.merge(io, on=["pid", "label"])
        p_in = sum(wi * inner[m].values for wi, m in zip(w, args.members))
        thr = select_thresholds(p_in, inner["label"].values, 0.80)
        (RESULTS / args.out).mkdir(parents=True, exist_ok=True)
        pc = np.clip(p_in, 1e-4, 1 - 1e-4)
        pd.DataFrame({"pid": inner["pid"], "label": inner["label"], "rep": rep, "fold": fold, "logit": np.log(pc / (1 - pc)),
                      "prob_cal": p_in}).to_csv(RESULTS / args.out / f"inner_oof_r{rep}f{fold}.csv", index=False)
        finfo.append({"rep": int(rep), "fold": int(fold), "thresholds": thr, "inner_oof_auc": float(roc_auc_score(inner["label"], p_in)),
                      "test_auc": float(roc_auc_score(d["label"], d["prob_cal"])) if d["label"].nunique() > 1 else None, "temperature": 1.0})
        for _, r in d.iterrows():
            rows.append({**r.to_dict(), "logit_mean": float(np.log(r["prob_cal"] / (1 - r["prob_cal"] + 1e-9) + 1e-9)), "temperature": 1.0,
                         "thr_youden": thr["youden"], "thr_f1max": thr["f1max"], "thr_sens80": thr["sens80"]})
    out = RESULTS / args.out; out.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(out / "oof_predictions.csv", index=False)
    cfg = {"name": args.out, "fusion": "ensemble:" + "+".join(args.members), "cohort": "all", "loss": "n/a", "lomo": None, "view": "n/a",
           "geom": False, "inner": 3, "repeats": int(base["rep"].nunique()), "backbone": "ensemble", "no_pet": False, "final_eval_slices": 0,
           "weights": w.tolist()}
    json.dump({"config": cfg, "folds": finfo}, open(out / "folds.json", "w", encoding="utf-8"), indent=1)
    df = pd.DataFrame(rows)
    for rep, d in df.groupby("rep"):
        y = d["label"].values; p = d["prob_cal"].values; pred = (p >= d["thr_youden"].values).astype(int)
        tp = ((pred == 1) & (y == 1)).sum(); fn = ((pred == 0) & (y == 1)).sum(); tn = ((pred == 0) & (y == 0)).sum(); fp = ((pred == 1) & (y == 0)).sum()
        print(f"{args.out} rep {rep}: AUC={roc_auc_score(y, p):.4f} sens={tp / (tp + fn):.3f} spec={tn / (tn + fp):.3f} bacc={(tp / (tp + fn) + tn / (tn + fp)) / 2:.3f}  "
              f"(mean inner-OOF AUC {np.mean([f['inner_oof_auc'] for f in finfo if f['rep'] == rep]):.3f})")


if __name__ == "__main__":
    main()
