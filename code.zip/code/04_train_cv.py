"""
Step 4: nested, patient-level cross-validation.

Outer loop : RepeatedStratifiedKFold (default 5 folds x 1 repeat) -> untouched test folds.
Inner loop : StratifiedKFold (default 3) on the outer-training patients -> one model per inner split,
             early stopping / checkpoint selection on the inner validation split only.
Freezing   : temperature scaling and decision thresholds (Youden, F1-max, sensitivity>=0.80) are fitted
             on the inner out-of-fold predictions of the outer-training patients and then applied,
             unchanged, to the outer test fold (mean of the inner models' calibrated probabilities).
Optional   : --lomo MANUFACTURER -> leave-one-manufacturer-out split instead of CV (pseudo-external test).

Example:
  python 04_train_cv.py --name proposed_all --fusion xattn --cohort all --loss focal
"""
import argparse
import copy
import json
import math
import time
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import RepeatedStratifiedKFold, StratifiedKFold
from torch.utils.data import DataLoader, WeightedRandomSampler

from common import (BagDataset, MILFusionNet, WeightedBCE, WeightedFocalLoss, collate_bags, fit_temperature,
                    load_cohort, predict, seed_everything, select_thresholds, HERE, VIEWS)

RESULTS = HERE / "results"


def get_args():
    ap = argparse.ArgumentParser()
    ap.add_argument("--name", required=True)
    ap.add_argument("--fusion", default="xattn", choices=["xattn", "concat", "ct_only", "pet_only", "early"])
    ap.add_argument("--cohort", default="all", choices=["all", "paired"])
    ap.add_argument("--no_pet", action="store_true", help="never feed PET (data-level CT-only)")
    ap.add_argument("--view", default="detail", choices=list(VIEWS.keys()),
                    help="detail = box-relative crop; context = fixed 160 mm field of view; whole = full slice; medi = central 150 mm; combinations")
    ap.add_argument("--geom", action="store_true", help="append lesion-geometry descriptors (log diameter/extent/area)")
    ap.add_argument("--loss", default="focal", choices=["focal", "bce"])
    ap.add_argument("--alpha", type=float, default=0.6); ap.add_argument("--gamma", type=float, default=2.0)
    ap.add_argument("--label_smoothing", type=float, default=0.02)
    ap.add_argument("--sampler", default="inverse", choices=["inverse", "none"])
    ap.add_argument("--folds", type=int, default=5); ap.add_argument("--repeats", type=int, default=1)
    ap.add_argument("--inner", type=int, default=3)
    ap.add_argument("--epochs", type=int, default=25); ap.add_argument("--patience", type=int, default=6)
    ap.add_argument("--min_epochs", type=int, default=6)
    ap.add_argument("--K", type=int, default=8); ap.add_argument("--batch", type=int, default=8)
    ap.add_argument("--lr", type=float, default=1e-4); ap.add_argument("--lr_head", type=float, default=3e-4)
    ap.add_argument("--wd", type=float, default=1e-4)
    ap.add_argument("--backbone", default="tf_efficientnet_b0.ns_jft_in1k")
    ap.add_argument("--mdrop", type=float, default=0.25, help="modality dropout prob for PET during training")
    ap.add_argument("--ema", type=float, default=0.99, help="EMA decay (about 35 optimiser steps per epoch here)")
    ap.add_argument("--drop_path", type=float, default=0.1); ap.add_argument("--dropout", type=float, default=0.2)
    ap.add_argument("--freeze_stages", type=int, default=0, help="freeze the stem and the first N EfficientNet blocks")
    ap.add_argument("--select", default="best", choices=["best", "last"],
                    help="checkpoint selection: best inner-validation score, or simply the final EMA weights (fixed schedule)")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--lomo", default=None, help="leave-one-manufacturer-out: test on this CT manufacturer")
    ap.add_argument("--limit", type=int, default=None, help="debug: use only the first N patients")
    ap.add_argument("--eval_slices", type=int, default=24, help="max slices per bag for per-epoch validation")
    ap.add_argument("--final_eval_slices", type=int, default=48)
    ap.add_argument("--no_save_models", action="store_true")
    return ap.parse_args()


def make_loader(recs, args, seed):
    ds = BagDataset(recs, bag_size=args.K, train=True, use_pet=not args.no_pet, modality_dropout=args.mdrop, seed=seed, view=args.view)
    labels = np.array([r.label for r in recs])
    if args.sampler == "inverse":
        counts = np.bincount(labels, minlength=2).astype(float)
        w = (1.0 / counts[labels]); w = w / w.sum()
        sampler = WeightedRandomSampler(torch.tensor(w, dtype=torch.double), num_samples=len(recs), replacement=True,
                                        generator=torch.Generator().manual_seed(seed))
        return DataLoader(ds, batch_size=args.batch, sampler=sampler, num_workers=0, collate_fn=collate_bags, drop_last=True)
    return DataLoader(ds, batch_size=args.batch, shuffle=True, num_workers=0, collate_fn=collate_bags, drop_last=True,
                      generator=torch.Generator().manual_seed(seed))


class EMA:
    """Exponential moving average of weights with a warm-up (effective decay grows from 0 to `decay`)."""
    def __init__(self, model, decay):
        self.m = copy.deepcopy(model).eval(); self.decay = decay; self.n = 0
        for p in self.m.parameters():
            p.requires_grad_(False)

    @torch.no_grad()
    def update(self, model):
        self.n += 1
        d = min(self.decay, (1 + self.n) / (10 + self.n))
        msd = model.state_dict()
        for k, v in self.m.state_dict().items():
            if v.dtype.is_floating_point:
                v.mul_(d).add_(msd[k].detach(), alpha=1 - d)
            else:
                v.copy_(msd[k])


@torch.no_grad()
def eval_logits(model, recs, device, use_pet, max_slices, view="detail", batch=8):
    """Batched evaluation (no TTA) used inside the training loop."""
    model.eval()
    ds = BagDataset(recs, train=False, use_pet=use_pet, eval_max_slices=max_slices, view=view)
    dl = DataLoader(ds, batch_size=batch, shuffle=False, num_workers=0, collate_fn=collate_bags)
    out = []
    for ct, pt, pm, mask, y, pids, _, geom in dl:
        ct, pt, pm, mask, geom = ct.to(device, non_blocking=True), pt.to(device, non_blocking=True), pm.to(device), mask.to(device), geom.to(device)
        with torch.autocast("cuda", dtype=torch.bfloat16, enabled=device.type == "cuda"):
            logit, _, _ = model(ct, pt, pm, mask, geom)
        out.append(logit.float().cpu().numpy())
    return np.concatenate(out)


def safe_auc(y, s):
    y = np.asarray(y); s = np.asarray(s)
    if len(np.unique(y)) < 2:
        return float("nan")
    return float(roc_auc_score(y, s))


def train_one(train_recs, val_recs, args, device, seed, tag, log):
    seed_everything(seed)
    loader = make_loader(train_recs, args, seed)
    model = MILFusionNet(args.backbone, fusion=args.fusion, views=len(VIEWS[args.view]), use_geom=args.geom,
                         drop=args.dropout, drop_path=args.drop_path).to(device)
    if args.freeze_stages > 0:
        for n, p in model.named_parameters():
            if n.startswith("enc") and (".conv_stem" in n or ".bn1." in n or any(f".blocks.{i}." in n for i in range(args.freeze_stages))):
                p.requires_grad_(False)
    enc_params = [p for n, p in model.named_parameters() if n.startswith("enc") and p.requires_grad]
    other = [p for n, p in model.named_parameters() if not n.startswith("enc")]
    opt = torch.optim.AdamW([{"params": enc_params, "lr": args.lr}, {"params": other, "lr": args.lr_head}], weight_decay=args.wd)
    steps_per_epoch = max(len(loader), 1); total = steps_per_epoch * args.epochs; warm = steps_per_epoch
    sched = torch.optim.lr_scheduler.LambdaLR(opt, lambda s: (s + 1) / warm if s < warm else 0.5 * (1 + math.cos(math.pi * (s - warm) / max(total - warm, 1))))
    labels = np.array([r.label for r in train_recs]); n_pos = labels.sum(); n_neg = len(labels) - n_pos
    if args.loss == "focal":
        crit = WeightedFocalLoss(args.alpha, args.gamma, args.label_smoothing)
    else:
        crit = WeightedBCE(pos_weight=(n_neg / max(n_pos, 1)) if args.sampler == "none" else 1.0, label_smoothing=args.label_smoothing).to(device)
    ema = EMA(model, args.ema)
    val_y = np.array([r.label for r in val_recs])
    best = {"score": -1e9, "epoch": 0, "state": None, "auc": float("nan"), "loss": float("nan")}
    history = []; bad = 0; t0 = time.time()
    for epoch in range(1, args.epochs + 1):
        model.train(); run_loss = 0.0; n_b = 0
        for ct, pt, pm, mask, y, _, _, geom in loader:
            ct = ct.to(device, non_blocking=True); pt = pt.to(device, non_blocking=True)
            pm = pm.to(device); mask = mask.to(device); y = y.to(device); geom = geom.to(device)
            with torch.autocast("cuda", dtype=torch.bfloat16, enabled=device.type == "cuda"):
                logit, _, _ = model(ct, pt, pm, mask, geom)
            loss = crit(logit.float(), y)
            opt.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step(); sched.step(); ema.update(model)
            run_loss += loss.item(); n_b += 1
        vl = eval_logits(ema.m, val_recs, device, not args.no_pet, args.eval_slices, view=args.view)
        v_auc = safe_auc(val_y, vl)
        v_loss = float(torch.nn.functional.binary_cross_entropy_with_logits(torch.tensor(vl), torch.tensor(val_y, dtype=torch.float32)).item())
        score = (0.0 if math.isnan(v_auc) else v_auc) - 0.05 * v_loss
        history.append({"epoch": epoch, "train_loss": run_loss / max(n_b, 1), "val_auc": v_auc, "val_loss": v_loss, "sec": round(time.time() - t0)})
        log(f"    [{tag}] ep {epoch:02d} train_loss={run_loss / max(n_b, 1):.4f} val_auc={v_auc:.4f} val_loss={v_loss:.4f} ({time.time() - t0:.0f}s)")
        if args.select == "last":
            best = {"score": score, "epoch": epoch, "state": copy.deepcopy(ema.m.state_dict()), "auc": v_auc, "loss": v_loss}
            continue
        if score > best["score"] + 1e-6:
            best = {"score": score, "epoch": epoch, "state": copy.deepcopy(ema.m.state_dict()), "auc": v_auc, "loss": v_loss}; bad = 0
        else:
            bad += 1
            if epoch >= args.min_epochs and bad >= args.patience:
                log(f"    [{tag}] early stop at epoch {epoch}; best epoch {best['epoch']}")
                break
    ema.m.load_state_dict(best["state"])
    return ema.m, best, history


def main():
    args = get_args()
    out = RESULTS / args.name; out.mkdir(parents=True, exist_ok=True)
    (out / "models").mkdir(exist_ok=True)
    logf = open(out / "train_log.txt", "a", encoding="utf-8")

    def log(msg):
        print(msg, flush=True); logf.write(msg + "\n"); logf.flush()

    log(f"=== {args.name} === {json.dumps(vars(args))}")
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    torch.backends.cudnn.benchmark = False   # variable bag sizes at evaluation would trigger constant re-tuning
    torch.set_num_threads(6)                 # several runs share the CPU; avoid oversubscription
    try:
        import cv2; cv2.setNumThreads(4)
    except Exception:
        pass
    seed_everything(args.seed)

    recs = load_cohort()
    if args.cohort == "paired":
        recs = [r for r in recs if r.has_pet]
    if args.limit:
        recs = recs[: args.limit]
    labels = np.array([r.label for r in recs])
    log(f"patients={len(recs)} SCLC={int(labels.sum())} NSCLC={int((labels == 0).sum())} with_pet={sum(r.has_pet for r in recs)} "
        f"fallback_roi={sum(r.fallback_roi for r in recs)}")

    # ---------------------------------------------------------------- outer splits
    if args.lomo:
        man = np.array([(r.manufacturer or "").upper() for r in recs])
        test_idx = np.where(np.char.find(man, args.lomo.upper()) >= 0)[0]
        train_idx = np.setdiff1d(np.arange(len(recs)), test_idx)
        splits = [(0, 0, train_idx, test_idx)]
        log(f"LOMO test manufacturer={args.lomo}: train={len(train_idx)} test={len(test_idx)} test_SCLC={int(labels[test_idx].sum())}")
    else:
        rskf = RepeatedStratifiedKFold(n_splits=args.folds, n_repeats=args.repeats, random_state=args.seed)
        splits = []
        for i, (tr, te) in enumerate(rskf.split(np.zeros(len(recs)), labels)):
            splits.append((i // args.folds, i % args.folds, tr, te))

    rows = []; fold_info = []
    t_all = time.time()
    for rep, fold, tr_idx, te_idx in splits:
        tag0 = f"r{rep}f{fold}"
        log(f"\n--- outer {tag0}: train={len(tr_idx)} (SCLC {int(labels[tr_idx].sum())}) test={len(te_idx)} (SCLC {int(labels[te_idx].sum())}) ---")
        tr_recs = [recs[i] for i in tr_idx]; te_recs = [recs[i] for i in te_idx]
        tr_y = labels[tr_idx]
        inner = StratifiedKFold(n_splits=args.inner, shuffle=True, random_state=args.seed + 1000 * rep + fold)
        inner_oof = np.full(len(tr_recs), np.nan); test_logits = []; inner_meta = []
        for j, (itr, iva) in enumerate(inner.split(np.zeros(len(tr_recs)), tr_y)):
            tag = f"{tag0}i{j}"
            model, best, hist = train_one([tr_recs[k] for k in itr], [tr_recs[k] for k in iva], args, device,
                                          seed=args.seed + 7 * j + 100 * fold + 10000 * rep, tag=tag, log=log)
            pv = predict(model, [tr_recs[k] for k in iva], device, use_pet=not args.no_pet, bag_size_eval=args.final_eval_slices, view=args.view)
            inner_oof[iva] = [p["logit"] for p in pv]
            pt_ = predict(model, te_recs, device, use_pet=not args.no_pet, bag_size_eval=args.final_eval_slices, view=args.view)
            test_logits.append(np.array([p["logit"] for p in pt_]))
            inner_meta.append({"inner": j, "best_epoch": best["epoch"], "val_auc": best["auc"], "val_loss": best["loss"],
                               "inner_val_auc_tta": safe_auc(tr_y[iva], inner_oof[iva]), "history": hist})
            if not args.no_save_models:
                torch.save({k: v.half() if v.is_floating_point() else v for k, v in model.state_dict().items()},
                           out / "models" / f"{tag}.pt")
            del model; torch.cuda.empty_cache()
        T = fit_temperature(inner_oof, tr_y)
        p_inner = 1 / (1 + np.exp(-inner_oof / T))
        thr = select_thresholds(p_inner, tr_y, target_sens=0.80)
        pd.DataFrame({"pid": [r.pid for r in tr_recs], "label": tr_y, "rep": rep, "fold": fold, "logit": inner_oof,
                      "prob_cal": p_inner}).to_csv(out / f"inner_oof_r{rep}f{fold}.csv", index=False)
        test_logits = np.stack(test_logits)                       # (inner, n_test)
        p_cal = (1 / (1 + np.exp(-test_logits / T))).mean(0)
        p_raw = (1 / (1 + np.exp(-test_logits))).mean(0)
        te_y = labels[te_idx]
        info = {"rep": rep, "fold": fold, "n_train": len(tr_idx), "n_test": len(te_idx), "test_sclc": int(te_y.sum()),
                "temperature": T, "thresholds": thr, "inner_oof_auc": safe_auc(tr_y, inner_oof),
                "test_auc": safe_auc(te_y, p_cal), "inner": inner_meta, "minutes": round((time.time() - t_all) / 60, 1)}
        fold_info.append(info)
        log(f"  >> {tag0}: inner-OOF AUC={info['inner_oof_auc']:.4f} T={T:.3f} thr={thr} | TEST AUC={info['test_auc']:.4f}")
        for k, r in enumerate(te_recs):
            rows.append({"pid": r.pid, "label": int(r.label), "group": r.group, "rep": rep, "fold": fold,
                         "prob_cal": float(p_cal[k]), "prob_raw": float(p_raw[k]),
                         "logit_mean": float(test_logits[:, k].mean()), "temperature": T,
                         "thr_youden": thr["youden"], "thr_f1max": thr["f1max"], "thr_sens80": thr["sens80"],
                         "has_pet": bool(r.has_pet), "pet_used": bool(r.has_pet and not args.no_pet),
                         "manufacturer": r.manufacturer, "n_slices": r.n_slices, "fallback_roi": bool(r.fallback_roi)})
        pd.DataFrame(rows).to_csv(out / "oof_predictions.csv", index=False)
        with open(out / "folds.json", "w", encoding="utf-8") as f:
            json.dump({"config": vars(args), "folds": fold_info}, f, indent=1)

    df = pd.DataFrame(rows)
    log("\n=== pooled out-of-fold summary (per repeat) ===")
    for rep, d in df.groupby("rep"):
        y = d["label"].values; p = d["prob_cal"].values
        pred = (p >= d["thr_youden"].values).astype(int)
        tp = int(((pred == 1) & (y == 1)).sum()); fn = int(((pred == 0) & (y == 1)).sum())
        tn = int(((pred == 0) & (y == 0)).sum()); fp = int(((pred == 1) & (y == 0)).sum())
        log(f"rep {rep}: n={len(d)} AUC={safe_auc(y, p):.4f} | Youden thr: sens={tp / max(tp + fn, 1):.3f} spec={tn / max(tn + fp, 1):.3f} "
            f"bacc={(tp / max(tp + fn, 1) + tn / max(tn + fp, 1)) / 2:.3f} acc={(tp + tn) / len(d):.3f}")
    log(f"total minutes: {(time.time() - t_all) / 60:.1f}")
    logf.close()


if __name__ == "__main__":
    main()
