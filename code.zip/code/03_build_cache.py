"""
Step 3: Build a per-patient cache for model training.

For every patient:
  * pick the CT series with the most annotated (tumour-box) slices
  * harmonise slice thickness: thin-slice series (<=1.5 mm) are slab-averaged to ~5 mm
    and sub-sampled to ~5 mm spacing so that all patients have a comparable effective
    thickness (5 mm reconstructions dominate the CT-only patients)
  * candidate slices = slices within NEIGHBOR_MM of an annotated slice (capped at MAX_CAND)
  * CT -> Hounsfield units (int16), full-resolution candidate slices
  * if the patient has PET: PET -> SUV(bw) (falls back to normalised activity if the SUV
    fields are missing), resampled onto every candidate CT slice with DICOM geometry.
    Alignment is checked with a body-outline Dice between CT and PET; if the shared
    frame of reference is missing or the Dice is poor, a rigid PET->CT registration
    (SimpleITK, Mattes mutual information) is attempted and kept only if it improves Dice.
  * metadata json with boxes, positions, spacing, alignment mode and QA numbers.

Usage:
  python 03_build_cache.py                      # all patients
  python 03_build_cache.py --pids A0001 B0033 --workers 1 --force
"""
import json
import math
import time
import argparse
import datetime as dt
from pathlib import Path
from multiprocessing import Pool

import numpy as np
import pandas as pd
import pydicom
import SimpleITK as sitk
from scipy import ndimage

HERE = Path(__file__).resolve().parent
IDX = HERE / "index"
CACHE = HERE / "cache"
IMG_ROOT = Path(r"D:\LungPETCTDx") / "Lung-PET-CT-Dx" / "Lung-PET-CT-Dx"

NEIGHBOR_MM = 10.0        # include slices within this distance of an annotated slice
TARGET_DZ = 5.0           # effective slice thickness / spacing after harmonisation
THIN_LIMIT = 1.5          # series with dz <= THIN_LIMIT are slab-averaged
MAX_CAND = 120            # cap on candidate slices per patient
DICE_OK = 0.75            # body-outline Dice below which PET->CT registration is attempted
LABEL_MAP = {"A": 0, "E": 0, "G": 0, "B": 1}   # 0 = NSCLC, 1 = SCLC

_DCM = None
_ANN = None


def _tables():
    global _DCM, _ANN
    if _DCM is None:
        d = pd.read_csv(IDX / "dicom_index.csv", dtype=str, keep_default_na=False)
        d["pid_short"] = d["pid"].str.replace("Lung_Dx-", "", regex=False).str.strip()
        _DCM = d
        _ANN = pd.read_csv(IDX / "annotations.csv", dtype=str, keep_default_na=False)
    return _DCM, _ANN


# --------------------------------------------------------------------------- DICOM helpers
def _float_list(v, n):
    try:
        out = [float(x) for x in v]
        return out if len(out) >= n else None
    except Exception:
        return None


def load_series(df_rows):
    items = []
    for _, r in df_rows.iterrows():
        p = IMG_ROOT / r["path"]
        try:
            ds = pydicom.dcmread(str(p), force=True)
            arr = ds.pixel_array
        except Exception:
            continue
        if arr.ndim == 3:
            if arr.shape[-1] in (3, 4):
                arr = arr[..., 0]
            else:
                continue
        ipp = _float_list(getattr(ds, "ImagePositionPatient", None), 3)
        iop = _float_list(getattr(ds, "ImageOrientationPatient", None), 6)
        ps = _float_list(getattr(ds, "PixelSpacing", None), 2)
        if ipp is None or iop is None or ps is None:
            continue
        items.append({"sop": str(ds.SOPInstanceUID), "ipp": np.array(ipp), "iop": np.array(iop), "ps": ps,
                      "slope": float(getattr(ds, "RescaleSlope", 1.0) or 1.0),
                      "inter": float(getattr(ds, "RescaleIntercept", 0.0) or 0.0), "arr": arr, "ds": ds})
    if not items:
        return None
    iop = items[0]["iop"]
    normal = np.cross(iop[:3], iop[3:])
    for it in items:
        it["pos"] = float(np.dot(it["ipp"], normal))
    items.sort(key=lambda it: it["pos"])
    dedup = []
    for it in items:
        if dedup and abs(it["pos"] - dedup[-1]["pos"]) < 1e-3:
            continue
        dedup.append(it)
    items = [it for it in dedup if it["arr"].shape == dedup[0]["arr"].shape]
    pos = np.array([it["pos"] for it in items])
    dz = float(np.median(np.diff(pos))) if len(items) > 1 else float(getattr(items[0]["ds"], "SliceThickness", 1.0) or 1.0)
    if not np.isfinite(dz) or dz <= 0:
        dz = 1.0
    return {"items": items, "pos": pos, "dz": dz, "ps": items[0]["ps"], "iop": iop, "normal": normal,
            "origin": items[0]["ipp"], "shape": items[0]["arr"].shape}


def volume_from_series(ser, dtype=np.float32):
    return np.stack([it["arr"].astype(np.float32) * it["slope"] + it["inter"] for it in ser["items"]]).astype(dtype)


def sitk_image(vol, ser, origin=None):
    img = sitk.GetImageFromArray(np.ascontiguousarray(vol))
    img.SetSpacing((float(ser["ps"][1]), float(ser["ps"][0]), float(ser["dz"])))
    img.SetOrigin(tuple(float(x) for x in (ser["origin"] if origin is None else origin)))
    direction = np.column_stack([ser["iop"][:3], ser["iop"][3:], ser["normal"]]).astype(float)
    img.SetDirection(tuple(direction.flatten()))
    return img


# --------------------------------------------------------------------------- PET -> SUV
def _parse_time(s):
    if not s:
        return None
    s = str(s).split(".")[0]
    try:
        return dt.datetime.strptime(s[:6].ljust(6, "0"), "%H%M%S")
    except Exception:
        return None


def suv_factor(ds):
    info = {"suv_mode": "none"}
    try:
        units = str(getattr(ds, "Units", "")).upper()
        weight = float(getattr(ds, "PatientWeight", 0) or 0)
        seq = getattr(ds, "RadiopharmaceuticalInformationSequence", None)
        if units != "BQML" or weight <= 0 or not seq:
            info["reason"] = f"units={units} weight={weight} seq={'yes' if seq else 'no'}"
            return None, info
        item = seq[0]
        dose = float(getattr(item, "RadionuclideTotalDose", 0) or 0)
        half = float(getattr(item, "RadionuclideHalfLife", 0) or 0)
        start = _parse_time(getattr(item, "RadiopharmaceuticalStartTime", None))
        scan = _parse_time(getattr(ds, "SeriesTime", None)) or _parse_time(getattr(ds, "AcquisitionTime", None))
        if dose <= 0 or half <= 0 or start is None or scan is None:
            info["reason"] = f"dose={dose} half={half} start={start} scan={scan}"
            return None, info
        decay_corr = str(getattr(ds, "DecayCorrection", "")).upper()
        delta = (scan - start).total_seconds()
        if delta < 0:
            delta += 24 * 3600
        decayed_dose = dose if decay_corr == "ADMIN" else dose * math.pow(2.0, -delta / half)
        info.update({"suv_mode": "bw", "weight_kg": weight, "dose_Bq": dose, "half_life_s": half,
                     "uptake_s": delta, "decay_correction": decay_corr})
        return (weight * 1000.0) / decayed_dose, info
    except Exception as exc:
        info["reason"] = repr(exc)
        return None, info


# --------------------------------------------------------------------------- alignment helpers
def _prep_for_reg(img, lo, hi, spacing=3.0):
    img = sitk.Clamp(sitk.Cast(img, sitk.sitkFloat32), sitk.sitkFloat32, lo, hi)
    sp = img.GetSpacing(); sz = img.GetSize()
    new_sz = [max(1, int(round(sz[i] * sp[i] / spacing))) for i in range(3)]
    return sitk.Resample(img, new_sz, sitk.Transform(), sitk.sitkLinear, img.GetOrigin(), (spacing,) * 3,
                         img.GetDirection(), lo, sitk.sitkFloat32)


def register_rigid(fixed_img, moving_img, fixed_range, moving_range):
    f = _prep_for_reg(fixed_img, *fixed_range); m = _prep_for_reg(moving_img, *moving_range)
    init = sitk.CenteredTransformInitializer(f, m, sitk.Euler3DTransform(), sitk.CenteredTransformInitializerFilter.GEOMETRY)
    reg = sitk.ImageRegistrationMethod()
    reg.SetMetricAsMattesMutualInformation(numberOfHistogramBins=32)
    reg.SetMetricSamplingStrategy(reg.RANDOM); reg.SetMetricSamplingPercentage(0.25, seed=42)
    reg.SetInterpolator(sitk.sitkLinear)
    reg.SetOptimizerAsRegularStepGradientDescent(learningRate=2.0, minStep=1e-3, numberOfIterations=200, relaxationFactor=0.6)
    reg.SetOptimizerScalesFromPhysicalShift()
    reg.SetInitialTransform(init, inPlace=True)
    reg.SetShrinkFactorsPerLevel([4, 2, 1]); reg.SetSmoothingSigmasPerLevel([2, 1, 0]); reg.SmoothingSigmasAreSpecifiedInPhysicalUnitsOn()
    tx = reg.Execute(f, m)
    return tx, float(reg.GetMetricValue()), int(reg.GetOptimizerIteration())


def resample_pet_on_slices(pet_img, ct_vol, ct_ser, cand, tx):
    H, W = ct_ser["shape"]
    out = np.zeros((len(cand), H, W), dtype=np.float32)
    for k, i in enumerate(cand):
        ref = sitk_image(ct_vol[i:i + 1].astype(np.float32), ct_ser, origin=ct_ser["items"][i]["ipp"])
        res = sitk.Resample(pet_img, ref, tx, sitk.sitkLinear, 0.0, sitk.sitkFloat32)
        out[k] = sitk.GetArrayFromImage(res)[0]
    return out


def _body_mask(img, thresh):
    """Largest connected component of (img > thresh) with holes (lungs, airways) filled."""
    m = img > thresh
    m = ndimage.binary_closing(m, iterations=2)
    m = ndimage.binary_fill_holes(m)
    lab, n = ndimage.label(m)
    if n > 1:
        sizes = ndimage.sum(m, lab, range(1, n + 1))
        m = lab == (int(np.argmax(sizes)) + 1)
    return m


def body_dice(ct_slices, pet_slices, pet_thresh):
    """Median Dice between filled CT body mask (HU > -500) and filled PET body mask; ~0.9+ when aligned."""
    ds_ = []
    for c, p in zip(ct_slices, pet_slices):
        a = _body_mask(c, -500); b = _body_mask(p, pet_thresh)
        inter = np.logical_and(a, b).sum(); s = a.sum() + b.sum()
        if s > 0:
            ds_.append(2.0 * inter / s)
    return float(np.median(ds_)) if ds_ else 0.0


def lung_dice(ct_slices, pet_slices, pet_thresh=None):
    """Cranio-caudal alignment check (scale-free), returned as 1 - ratio so that higher is better:
    ratio = median PET uptake inside the CT lung (HU < -500, inside the body) divided by the median uptake inside
    CT soft tissue (HU > 0: heart, mediastinum, muscle, liver). Aerated lung is far colder than soft tissue, so the
    score is ~0.5-0.8 when aligned and drops towards 0 when, e.g., the liver level is mapped onto the lung level;
    the body outline cannot detect that failure."""
    scores = []
    for c, p in zip(ct_slices, pet_slices):
        body = _body_mask(c, -500)
        lung = body & (c < -500); soft = body & (c > 0)
        if lung.sum() < 200 or soft.sum() < 200:
            continue
        m_soft = float(np.median(p[soft]))
        if m_soft <= 1e-6:
            continue
        ratio = float(np.median(p[lung])) / m_soft
        scores.append(1.0 - min(ratio, 1.5))
    return float(np.median(scores)) if scores else 0.0


# --------------------------------------------------------------------------- per patient
def process_patient(args):
    pid, out_dir, force = args
    out_dir = Path(out_dir)
    if (out_dir / pid / "meta.json").exists() and not force:
        return pid, "cached", ""
    t0 = time.time()
    try:
        dcm, ann_all = _tables()
        d = dcm[dcm["pid_short"] == pid]
        if d.empty:
            return pid, "error", "no dicom rows"
        ann = ann_all[(ann_all["pid_short"] == pid) & (ann_all["xmin"] != "")]
        box_by_sop = {}
        for _, r in ann.iterrows():
            box_by_sop.setdefault(r["sop_uid"], []).append(
                [int(float(r["xmin"])), int(float(r["ymin"])), int(float(r["xmax"])), int(float(r["ymax"])), r["label"]])

        ct_rows = d[d["modality"] == "CT"]; pt_rows = d[d["modality"] == "PT"]
        if ct_rows.empty:
            return pid, "error", "no CT"
        stats_ = ct_rows.assign(annotated=ct_rows["sop_uid"].isin(box_by_sop),
                                geom=(ct_rows["ipp_z"].astype(str) != "")).groupby("series_uid").agg(
            n=("sop_uid", "size"), n_ann=("annotated", "sum"), geom=("geom", "mean"), study=("study_uid", "first"),
            for_uid=("for_uid", "first"), desc=("series_desc", "first"), manufacturer=("manufacturer", "first"),
            kernel=("kernel", "first")).reset_index()
        stats_["has_ann"] = (stats_["n_ann"] > 0).astype(int)
        stats_["has_geom"] = (stats_["geom"] > 0.9).astype(int)      # series without ImagePositionPatient cannot be aligned
        order = ["has_ann", "has_geom", "n_ann", "n"]
        # PET patients: prefer an annotated CT acquired in the PET/CT session (inherently co-registered),
        # and among those the one sharing the PET frame of reference.
        if not pt_rows.empty:
            pet_uid0 = pt_rows["series_uid"].value_counts().index[0]
            prow0 = pt_rows[pt_rows["series_uid"] == pet_uid0]
            pet_study0 = str(prow0["study_uid"].iloc[0]); pet_for0 = str(prow0["for_uid"].iloc[0])
            stats_["in_pet_study"] = (stats_["study"] == pet_study0).astype(int)
            stats_["same_for"] = ((stats_["for_uid"] == pet_for0) & (stats_["for_uid"] != "")).astype(int)
            order = ["has_ann", "has_geom", "same_for", "in_pet_study", "n_ann", "n"]
        stats_ = stats_.sort_values(order, ascending=False).reset_index(drop=True)
        ct_ser = None; ct_uid = None
        for ridx, cand_row in stats_.iterrows():
            if cand_row["has_geom"] == 0:          # e.g. Siemens secondary-capture RGB "Range" screenshots
                continue
            ser_try = load_series(ct_rows[ct_rows["series_uid"] == cand_row["series_uid"]])
            if ser_try is not None and len(ser_try["items"]) >= 3:
                ct_ser = ser_try; ct_uid = cand_row["series_uid"]
                stats_ = pd.concat([stats_.loc[[ridx]], stats_.drop(index=ridx)]).reset_index(drop=True)
                break
        if ct_ser is None:
            return pid, "error", "no readable CT series with geometry"
        ct_raw = volume_from_series(ct_ser, np.float32)
        n_ct = len(ct_ser["items"]); pos = ct_ser["pos"]; dz = ct_ser["dz"]
        sops = [it["sop"] for it in ct_ser["items"]]
        annotated_idx = [i for i, s in enumerate(sops) if s in box_by_sop]

        # ---- slice-thickness harmonisation
        thin = dz <= THIN_LIMIT
        step = max(1, int(round(TARGET_DZ / dz))) if thin else 1
        half = step // 2
        if thin and half > 0:
            cs = np.cumsum(np.concatenate([np.zeros((1,) + ct_raw.shape[1:], np.float64), ct_raw.astype(np.float64)]), axis=0)
            ct_vol = np.empty_like(ct_raw)
            for i in range(n_ct):
                a, b = max(0, i - half), min(n_ct, i + half + 1)
                ct_vol[i] = (cs[b] - cs[a]) / (b - a)
            del cs
        else:
            ct_vol = ct_raw
        ct_vol = np.clip(np.round(ct_vol), -2048, 4095).astype(np.int16)

        # ---- candidate slices
        if annotated_idx:
            ann_pos = pos[annotated_idx]
            near = [i for i in range(n_ct) if np.min(np.abs(ann_pos - pos[i])) <= NEIGHBOR_MM]
            cand = near[::step] if step > 1 else near
            # make sure annotated slices themselves are represented when sub-sampling
            if step > 1:
                keep = set(cand)
                for i in annotated_idx[::step]:
                    keep.add(i)
                cand = sorted(keep)
            cand_mode = f"within_{NEIGHBOR_MM:.0f}mm_of_annotation_step{step}"
        else:
            cand = list(range(0, n_ct, step)); cand_mode = "all_slices_no_annotation"
        if len(cand) > MAX_CAND:
            cand = [cand[int(round(t))] for t in np.linspace(0, len(cand) - 1, MAX_CAND)]
            cand_mode += f"_capped{MAX_CAND}"

        row0 = stats_.iloc[0]
        meta = {
            "pid": pid, "group": pid[0], "label": LABEL_MAP.get(pid[0], -1),
            "ct_series_uid": ct_uid, "ct_desc": str(row0["desc"]), "ct_study_uid": str(row0["study"]), "ct_for_uid": str(row0["for_uid"]),
            "ct_manufacturer": str(row0["manufacturer"]), "ct_kernel": str(row0["kernel"]),
            "ct_n_slices_total": n_ct, "ct_shape": list(ct_ser["shape"]), "ct_spacing_row_col": ct_ser["ps"],
            "ct_dz_native": dz, "ct_slab_slices": (2 * half + 1) if thin else 1, "ct_effective_dz": dz * ((2 * half + 1) if thin else 1),
            "ct_candidate_step": step, "ct_iop": [float(x) for x in ct_ser["iop"]],
            "n_annotated_slices_in_series": len(annotated_idx), "n_annotated_slices_patient": len(box_by_sop),
            "candidate_mode": cand_mode, "candidate_idx": cand,
            "slices": [{"idx": i, "sop": sops[i], "pos": float(pos[i]), "boxes": box_by_sop.get(sops[i], [])} for i in cand],
            "has_pet": False,
        }

        pet_out = None
        if not pt_rows.empty:
            pet_uid = pt_rows["series_uid"].value_counts().index[0]
            prow = pt_rows[pt_rows["series_uid"] == pet_uid]
            pet_ser = load_series(prow)
            if pet_ser is not None:
                act = volume_from_series(pet_ser, np.float32)
                factor, suv_info = suv_factor(pet_ser["items"][0]["ds"])
                suv = act * factor if factor is not None else act / max(float(np.percentile(act, 99.9)), 1e-6)
                pet_thresh = 0.3 if factor is not None else 0.05
                pet_img = sitk_image(suv.astype(np.float32), pet_ser)
                pet_for = str(prow["for_uid"].iloc[0]); pet_study = str(prow["study_uid"].iloc[0])
                align = {"pet_series_uid": pet_uid, "pet_for_uid": pet_for, "pet_study_uid": pet_study,
                         "pet_shape": list(pet_ser["shape"]), "pet_spacing_row_col": pet_ser["ps"], "pet_dz": pet_ser["dz"],
                         "pet_n_slices": len(pet_ser["items"]), **suv_info}
                same_for = bool(pet_for) and pet_for == meta["ct_for_uid"]
                same_study = pet_study == meta["ct_study_uid"]
                align["mode"] = "same_frame_of_reference" if same_for else ("same_study_scanner_coordinates" if same_study else "different_study_identity_start")
                tx = sitk.Transform()
                pet_out = resample_pet_on_slices(pet_img, ct_vol, ct_ser, cand, tx)
                dice0 = body_dice(ct_vol[cand], pet_out, pet_thresh)
                ldice0 = lung_dice(ct_vol[cand], pet_out, pet_thresh)
                align["dice_geometry"] = dice0; align["lung_dice_geometry"] = ldice0
                # Decision rules: scanner geometry is trusted when CT and PET share a frame of reference (or at
                # least a study) unless the overlap checks fail; a CT from another study is always registered and the
                # registered result is kept whenever the lung overlap (sensitive to z-shifts) does not get worse.
                # same session (shared frame of reference or same study): hardware alignment is trusted unless the
                # overlap checks clearly fail; a CT from another study is always registered.
                if same_for or same_study:
                    try_reg = dice0 < 0.80 or ldice0 < 0.10
                else:
                    try_reg = True
                align["dice_final"] = dice0; align["lung_dice_final"] = ldice0
                if try_reg:
                    try:
                        fixed_img = sitk_image(ct_vol.astype(np.float32), ct_ser)
                        tx2, metric, iters = register_rigid(fixed_img, pet_img, (-1000.0, 400.0), (0.0, 8.0))
                        pet2 = resample_pet_on_slices(pet_img, ct_vol, ct_ser, cand, tx2)
                        dice2 = body_dice(ct_vol[cand], pet2, pet_thresh); ldice2 = lung_dice(ct_vol[cand], pet2, pet_thresh)
                        align.update({"registration_tried": True, "dice_registered": dice2, "lung_dice_registered": ldice2,
                                      "reg_metric": metric, "reg_iterations": iters, "reg_params": list(tx2.GetParameters())})
                        if same_for or same_study:
                            accept = ldice2 > ldice0 + 0.15 and dice2 >= dice0 - 0.05
                        else:
                            accept = (ldice2 >= ldice0 - 0.05) and (dice2 >= 0.75)
                        if accept:
                            pet_out = pet2; align["mode"] += "+rigid_pet_to_ct_registration"
                            align["dice_final"] = dice2; align["lung_dice_final"] = ldice2
                    except Exception as exc:
                        align["registration_tried"] = True; align["reg_error"] = repr(exc)
                align["alignment_flag"] = "ok" if (align["dice_final"] >= 0.80 and align["lung_dice_final"] >= 0.10) else "check"
                meta["has_pet"] = True
                meta["pet_max_suv_in_candidates"] = float(pet_out.max()) if pet_out.size else 0.0
                meta["pet"] = align

        pdir = out_dir / pid
        pdir.mkdir(parents=True, exist_ok=True)
        np.save(pdir / "ct_hu.npy", ct_vol[cand])
        if pet_out is not None:
            np.save(pdir / "pet_suv.npy", pet_out.astype(np.float16))
        meta["seconds"] = round(time.time() - t0, 1)
        with open(pdir / "meta.json", "w", encoding="utf-8") as f:
            json.dump(meta, f, indent=1)
        extra = ""
        if pet_out is not None:
            extra = f" pet mode={meta['pet']['mode']} dice={meta['pet'].get('dice_final', 0):.2f}"
        return pid, "ok", f"{len(cand)} slices (dz={dz:.2f} step={step}){extra} {meta['seconds']}s"
    except Exception as exc:
        import traceback
        return pid, "error", repr(exc) + " | " + traceback.format_exc().splitlines()[-3]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pids", nargs="*", default=None)
    ap.add_argument("--workers", type=int, default=6)
    ap.add_argument("--force", action="store_true")
    ap.add_argument("--out", default=str(CACHE))
    args = ap.parse_args()
    out_dir = Path(args.out); out_dir.mkdir(parents=True, exist_ok=True)
    pats = pd.read_csv(IDX / "patient_summary.csv", dtype=str)
    pids = args.pids or sorted(pats["pid"].tolist())
    jobs = [(p, str(out_dir), args.force) for p in pids]
    t0 = time.time()
    with open(out_dir / "_build_log.txt", "a", encoding="utf-8") as log:
        if args.workers <= 1:
            results = map(process_patient, jobs)
        else:
            pool = Pool(args.workers); results = pool.imap_unordered(process_patient, jobs)
        for n, (pid, status, msg) in enumerate(results, 1):
            line = f"{pid}\t{status}\t{msg}"
            print(f"[{n}/{len(jobs)} {time.time() - t0:.0f}s] {line}", flush=True)
            log.write(line + "\n"); log.flush()


if __name__ == "__main__":
    main()
