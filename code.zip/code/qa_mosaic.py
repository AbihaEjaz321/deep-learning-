"""Contact sheets of CT+PET overlays (3 annotated slices per patient) for visual alignment QA.
   python qa_mosaic.py registered   -> patients whose PET needed registration or has Dice < 0.70
   python qa_mosaic.py all          -> every PET patient
"""
import sys
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = Path(__file__).resolve().parent
cache = HERE / "cache"; out = cache / "_qa"; out.mkdir(exist_ok=True)
mode = sys.argv[1] if len(sys.argv) > 1 else "registered"
sel = []
for mp in sorted(cache.glob("*/meta.json")):
    m = json.load(open(mp, encoding="utf-8"))
    if not m.get("has_pet"):
        continue
    pm = m["pet"]
    if mode == "flagged":
        if pm.get("alignment_flag") != "ok":
            sel.append(m)
    elif mode == "all" or "registration" in pm.get("mode", "") or pm.get("dice_final", 1) < 0.70:
        sel.append(m)
print(f"{len(sel)} patients selected")
PER_SHEET = 8
for sheet in range(0, len(sel), PER_SHEET):
    group = sel[sheet: sheet + PER_SHEET]
    fig, axes = plt.subplots(len(group), 3, figsize=(9.6, 3.1 * len(group)))
    axes = np.atleast_2d(axes)
    for r, m in enumerate(group):
        pdir = cache / m["pid"]
        ct = np.load(pdir / "ct_hu.npy"); pet = np.load(pdir / "pet_suv.npy").astype(np.float32)
        ann = [k for k, s in enumerate(m["slices"]) if s["boxes"]] or list(range(ct.shape[0]))
        ks = [ann[int(round(t))] for t in np.linspace(0, len(ann) - 1, 3)]
        for c, k in enumerate(ks):
            ax = axes[r, c]; s = m["slices"][k]
            ax.imshow(np.clip((ct[k].astype(np.float32) + 1350) / 1500, 0, 1), cmap="gray")
            thr = 1.0 if m["pet"].get("suv_mode") == "bw" else 0.1
            ax.imshow(np.ma.masked_less(pet[k], thr), cmap="hot", alpha=0.5, vmin=0, vmax=8)
            ax.contour(pet[k] > (0.3 if m["pet"].get("suv_mode") == "bw" else 0.05), levels=[0.5], colors="cyan", linewidths=0.5)
            for b in s["boxes"]:
                ax.add_patch(plt.Rectangle((b[0], b[1]), b[2] - b[0], b[3] - b[1], fill=False, color="lime", lw=1.0))
            # zoom to the box region for readability
            if s["boxes"]:
                b = max(s["boxes"], key=lambda b: (b[2] - b[0]) * (b[3] - b[1]))
                cx, cy = (b[0] + b[2]) / 2, (b[1] + b[3]) / 2; half = max(b[2] - b[0], b[3] - b[1]) * 1.6 + 30
                ax.set_xlim(cx - half, cx + half); ax.set_ylim(cy + half, cy - half)
            ax.axis("off")
            if c == 0:
                ax.set_title(f"{m['pid']} ({'SCLC' if m['label'] == 1 else 'NSCLC'}) {m['pet']['mode'].replace('_', ' ')[:48]}\nDice {m['pet'].get('dice_final', 0):.2f} lung-score {m['pet'].get('lung_dice_final', 0):.2f} maxSUV {m.get('pet_max_suv_in_candidates', 0):.1f}", fontsize=7, loc="left")
    fig.tight_layout(); fn = out / f"mosaic_{mode}_{sheet // PER_SHEET + 1:02d}.png"; fig.savefig(fn, dpi=90); plt.close(fig)
    print("saved", fn)
