"""Print counts of tracked changes and the accepted text of key paragraphs of the revised manuscript."""
import sys
import zipfile
from lxml import etree

W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
q = lambda t: "{%s}%s" % (W, t)
path = sys.argv[1]
root = etree.fromstring(zipfile.ZipFile(path).read("word/document.xml"))
print("tracked insertions", len(root.findall(".//" + q("ins"))), "| tracked deletions", len(root.findall(".//" + q("del"))))


def accepted_text(p):
    out = []
    for t in p.iter(q("t")):
        if t.getparent().getparent().tag == q("del"):
            continue
        out.append(t.text or "")
    return "".join(out)


starts = ("Abstract", "Distinguishing small", "Eligibility", "Table 3 reports", "Ablations", "Secondary clinico", "Scanner-shift",
          "Robustness to", "Limitations", "This study has important", "Comparison with prior", "To our knowledge", "We evaluated a weakly")
body = root.find(q("body"))
for el in body:
    if el.tag == q("p"):
        txt = accepted_text(el).strip()
        if txt.startswith(starts):
            print("\n>>", txt[:900])
    elif el.tag == q("tbl"):
        rows = el.findall(q("tr"))
        deleted = sum(1 for r in rows if r.find(q("trPr")) is not None and r.find(q("trPr")).find(q("del")) is not None)
        print(f"\n[table: {len(rows)} rows, {deleted} marked deleted] first row: " + " | ".join(accepted_text(c)[:22] for c in rows[0].findall(q("tc"))))
