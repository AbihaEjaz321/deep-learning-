"""Quick visual QA of the cache: CT lung window + tumour box + PET SUV overlay for a few candidate slices."""
import sys
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

cache = Path(sys.argv[1]); pids = sys.argv[2:]
out = cache / "_qa"; out.mkdir(exist_ok=True)
for pid in pids:
    pdir = cache / pid
    meta = json.load(open(pdir / "meta.json", encoding="utf-8"))
    ct = np.load(pdir / "ct_hu.npy"); pet = np.load(pdir / "pet_suv.npy") if (pdir / "pet_suv.npy").exists() else None
    n = ct.shape[0]; ks = [int(round(t)) for t in np.linspace(0, n - 1, min(5, n))]
    fig, axes = plt.subplots(1, len(ks), figsize=(3.2 * len(ks), 3.4))
    axes = np.atleast_1d(axes)
    for ax, k in zip(axes, ks):
        s = meta["slices"][k]
        lung = np.clip((ct[k].astype(np.float32) + 1350) / 1500, 0, 1)
        ax.imshow(lung, cmap="gray")
        if pet is not None:
            p = pet[k].astype(np.float32)
            ax.imshow(np.ma.masked_less(p, 1.0 if meta["pet"].get("suv_mode") == "bw" else 0.1), cmap="hot", alpha=0.5, vmin=0, vmax=8)
            ax.contour(p > (0.3 if meta["pet"].get("suv_mode") == "bw" else 0.05), levels=[0.5], colors="cyan", linewidths=0.6)
        for b in s["boxes"]:
            ax.add_patch(plt.Rectangle((b[0], b[1]), b[2] - b[0], b[3] - b[1], fill=False, color="lime", lw=1.2))
        ax.set_title(f"slice {s['idx']} z={s['pos']:.0f} {'ann' if s['boxes'] else ''}", fontsize=8); ax.axis("off")
    pet_txt = ""
    if pet is not None:
        a = meta["pet"]; pet_txt = f" | PET {a['mode']} dice={a.get('dice_final', 0):.2f} suv={a.get('suv_mode')} maxSUV={meta.get('pet_max_suv_in_candidates', 0):.1f}"
    fig.suptitle(f"{pid} {meta['ct_desc']} dz={meta['ct_dz_native']:.2f} eff={meta['ct_effective_dz']:.1f} n_cand={n} ann_in_series={meta['n_annotated_slices_in_series']}/{meta['n_annotated_slices_patient']}{pet_txt}", fontsize=8)
    fig.tight_layout(); fig.savefig(out / f"{pid}.png", dpi=110); plt.close(fig)
    print(pid, "->", out / f"{pid}.png")
