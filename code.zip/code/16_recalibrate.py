"""
Step 16: replace temperature scaling by two-parameter Platt (logistic) recalibration, fitted per outer fold on the
inner-fold out-of-fold logits of the outer-training patients only (so the outer test fold is still untouched).
Class-balanced sampling and focal loss inflate the raw probabilities (calibration intercept ~ -1.7); a slope+intercept
map corrects the base rate. Thresholds (Youden, F1-max, sens>=0.80) are re-selected on the recalibrated inner-fold
probabilities. Writes results/<name>_platt/ with the standard files; models/explain/robustness stay in the original dir.

  python 16_recalibrate.py --names final_b0_xattn ft_ctx ...
"""
import argparse
import json
import shutil
from pathlib import Path

import numpy as np
import pandas as pd

from common import select_thresholds, HERE

RESULTS = HERE / "results"


def fit_platt(logits, labels, l2=1e-3, iters=200):
    """Logistic regression y ~ sigmoid(a*logit + b) by Newton's method with a tiny ridge on a."""
    x = np.asarray(logits, float); y = np.asarray(labels, float)
    a, b = 1.0, 0.0
    for _ in range(iters):
        z = a * x + b; p = 1 / (1 + np.exp(-z)); w = p * (1 - p) + 1e-9
        g = np.array([np.sum((p - y) * x) + l2 * (a - 1), np.sum(p - y)])
        H = np.array([[np.sum(w * x * x) + l2, np.sum(w * x)], [np.sum(w * x), np.sum(w)]])
        step = np.linalg.solve(H, g)
        a -= step[0]; b -= step[1]
        if np.abs(step).max() < 1e-8:
            break
    return float(a), float(b)


def sig(z):
    return 1 / (1 + np.exp(-z))


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--names", nargs="+", required=True); args = ap.parse_args()
    for name in args.names:
        src = RESULTS / name; dst = RESULTS / f"{name}_platt"; dst.mkdir(parents=True, exist_ok=True)
        oof = pd.read_csv(src / "oof_predictions.csv"); fj = json.load(open(src / "folds.json", encoding="utf-8"))
        rows = []
        for finfo in fj["folds"]:
            rep, fold = finfo["rep"], finfo["fold"]
            f = src / f"inner_oof_r{rep}f{fold}.csv"
            if not f.exists():
                raise SystemExit(f"{name}: missing {f.name}")
            inner = pd.read_csv(f)
            a, b = fit_platt(inner["logit"].values, inner["label"].values)
            p_in = sig(a * inner["logit"].values + b)
            thr = select_thresholds(p_in, inner["label"].values, 0.80)
            inner["prob_cal"] = p_in; inner.to_csv(dst / f.name, index=False)
            finfo.update({"platt_a": a, "platt_b": b, "thresholds": thr, "calibration": "platt_on_inner_oof"})
            d = oof[(oof["rep"] == rep) & (oof["fold"] == fold)].copy()
            d["prob_cal"] = sig(a * d["logit_mean"].values + b)
            d["thr_youden"] = thr["youden"]; d["thr_f1max"] = thr["f1max"]; d["thr_sens80"] = thr["sens80"]
            d["platt_a"] = a; d["platt_b"] = b
            rows.append(d)
        out = pd.concat(rows).sort_index()
        out.to_csv(dst / "oof_predictions.csv", index=False)
        fj["config"]["name"] = f"{name}_platt"; fj["config"]["calibration"] = "platt_on_inner_oof"
        json.dump(fj, open(dst / "folds.json", "w", encoding="utf-8"), indent=1)
        from sklearn.metrics import roc_auc_score
        y = out["label"].values; p = out["prob_cal"].values
        pred = (p >= out["thr_youden"].values).astype(int); tp = ((pred == 1) & (y == 1)).sum(); fn = ((pred == 0) & (y == 1)).sum()
        tn = ((pred == 0) & (y == 0)).sum(); fp = ((pred == 1) & (y == 0)).sum()
        print(f"{name}_platt: AUC={roc_auc_score(y, p):.3f} mean prob={p.mean():.3f} (prevalence {y.mean():.3f}) "
              f"Youden sens={tp / (tp + fn):.3f} spec={tn / (tn + fp):.3f}  platt a,b (fold0) = {fj['folds'][0]['platt_a']:.2f}, {fj['folds'][0]['platt_b']:.2f}")


if __name__ == "__main__":
    main()
