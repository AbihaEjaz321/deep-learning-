"""
Shared code for the revision experiments: cached-data loading, bag dataset,
dual-stream cross-attention MIL model with missing-PET handling, losses,
prediction helpers, calibration and threshold selection.

Views
  detail  : square crop about 1.8x the radiologist box (scale-normalised lesion appearance)
  context : fixed 160 mm field of view centred on the box (keeps absolute size and surroundings)
  both    : the encoder sees both views (shared weights); embeddings are concatenated
"""
import json
import math
import random
from pathlib import Path

import cv2
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
import timm

HERE = Path(__file__).resolve().parent
CACHE = HERE / "cache"
IDX = HERE / "index"

IMG = 224
STORE = 256          # size of the pre-cropped windows kept in RAM
EXPAND_STORE = 2.6   # detail window side = EXPAND_STORE * max(box_w, box_h)
MIN_SIDE_PX = 96
EVAL_REL = 0.70      # detail evaluation crop = EVAL_REL * STORE (about 1.8x the box)
TRAIN_REL = (0.55, 0.90)
CTX_STORE_MM = 200.0 # physical side of the stored context window
CTX_EVAL_REL = 0.80  # context evaluation crop = 160 mm
CTX_TRAIN_REL = (0.70, 0.90)

LUNG_WIN = (-600.0, 1500.0)
MED_WIN = (40.0, 400.0)
SUV_SCALES = (10.0, 3.0)   # two PET channels: SUV/10 and SUV/3, clipped to [0, 1]
GEOM_DIM = 3               # log lesion diameter (mm), log cranio-caudal extent (mm), log box area (cm2)


def seed_everything(seed):
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed); torch.cuda.manual_seed_all(seed)


# =============================================================================== data
class PatientRecord:
    __slots__ = ("pid", "label", "group", "has_pet", "ct", "pet", "boxes", "ct_ctx", "pet_ctx", "boxes_ctx", "annotated",
                 "n_slices", "meta", "manufacturer", "pet_mode", "fallback_roi", "ps", "geom", "ct_whole", "pet_whole", "boxes_whole",
                 "ct_medi", "pet_medi", "boxes_medi")

    def __init__(self):
        self.ct = None; self.pet = None; self.boxes = None; self.ct_ctx = None; self.pet_ctx = None; self.boxes_ctx = None
        self.annotated = None; self.geom = None; self.ct_whole = None; self.pet_whole = None; self.boxes_whole = None
        self.ct_medi = None; self.pet_medi = None; self.boxes_medi = None


def _window(hu, level, width):
    lo = level - width / 2.0
    return np.clip((hu - lo) / width, 0.0, 1.0)


def _crop_resize(img, cx, cy, side, out, pad_value):
    """Square crop of `side` px centred at (cx, cy) (padding outside), resized to out x out."""
    H, W = img.shape
    x0 = int(round(cx - side / 2.0)); y0 = int(round(cy - side / 2.0))
    x1 = x0 + int(round(side)); y1 = y0 + int(round(side))
    px0, py0 = max(0, -x0), max(0, -y0)
    px1, py1 = max(0, x1 - W), max(0, y1 - H)
    sub = img[max(0, y0):min(H, y1), max(0, x0):min(W, x1)]
    if px0 or py0 or px1 or py1:
        sub = np.pad(sub.astype(np.float32), ((py0, py1), (px0, px1)), mode="constant", constant_values=pad_value)
    sub = sub.astype(np.float32)
    interp = cv2.INTER_AREA if sub.shape[0] > out else cv2.INTER_LINEAR
    return cv2.resize(sub, (out, out), interpolation=interp)


def load_patient(pid, cache_dir=CACHE, series_info=None):
    pdir = Path(cache_dir) / pid
    meta = json.load(open(pdir / "meta.json", encoding="utf-8"))
    ct_all = np.load(pdir / "ct_hu.npy", mmap_mode="r")
    pet_all = np.load(pdir / "pet_suv.npy", mmap_mode="r") if (pdir / "pet_suv.npy").exists() else None
    slices = meta["slices"]
    H, W = ct_all.shape[1:]
    ps = float(meta["ct_spacing_row_col"][0])

    ann_idx = [k for k, s in enumerate(slices) if s["boxes"]]
    rec = PatientRecord()
    rec.pid = pid; rec.label = int(meta["label"]); rec.group = meta["group"]; rec.ps = ps
    rec.has_pet = bool(meta.get("has_pet", False)) and pet_all is not None
    rec.pet_mode = meta.get("pet", {}).get("mode", "") if rec.has_pet else ""
    rec.manufacturer = (series_info or {}).get(meta["ct_series_uid"], "") or meta.get("ct_manufacturer", "")
    rec.fallback_roi = len(ann_idx) == 0
    n = len(slices)
    ct_store = np.zeros((n, STORE, STORE), dtype=np.int16); ct_ctx = np.zeros((n, STORE, STORE), dtype=np.int16)
    ct_whole = np.zeros((n, STORE, STORE), dtype=np.int16); ct_medi = np.zeros((n, STORE, STORE), dtype=np.int16)
    pet_store = np.zeros((n, STORE, STORE), dtype=np.float16) if rec.has_pet else None
    pet_ctx = np.zeros((n, STORE, STORE), dtype=np.float16) if rec.has_pet else None
    pet_whole = np.zeros((n, STORE, STORE), dtype=np.float16) if rec.has_pet else None
    pet_medi = np.zeros((n, STORE, STORE), dtype=np.float16) if rec.has_pet else None
    boxes = np.zeros((n, 4), dtype=np.float32); boxes_ctx = np.zeros((n, 4), dtype=np.float32); boxes_whole = np.zeros((n, 4), dtype=np.float32)
    boxes_medi = np.zeros((n, 4), dtype=np.float32)
    annotated = np.zeros(n, dtype=bool)
    diam_mm, area_cm2 = [], []
    side_ctx = CTX_STORE_MM / ps
    side_whole = float(max(H, W))
    side_medi = MEDI_STORE_MM / ps
    for k, s in enumerate(slices):
        if s["boxes"]:
            bxs = s["boxes"]; annotated[k] = True
        elif ann_idx:
            j = min(ann_idx, key=lambda a: abs(a - k)); bxs = slices[j]["boxes"]
        else:
            bxs = [[int(W * 0.2), int(H * 0.2), int(W * 0.8), int(H * 0.8), "NA"]]
        b = max(bxs, key=lambda b: (b[2] - b[0]) * (b[3] - b[1]))
        x0, y0, x1, y1 = float(b[0]), float(b[1]), float(b[2]), float(b[3])
        cx, cy = (x0 + x1) / 2.0, (y0 + y1) / 2.0
        if s["boxes"]:
            diam_mm.append(max(x1 - x0, y1 - y0) * ps); area_cm2.append((x1 - x0) * (y1 - y0) * ps * ps / 100.0)
        ct_np = np.asarray(ct_all[k], dtype=np.float32)
        pet_np = np.asarray(pet_all[k], dtype=np.float32) if rec.has_pet else None
        for store_arr, pet_arr, box_arr, side, ccx, ccy in (
                (ct_store, pet_store, boxes, max(max(x1 - x0, y1 - y0) * EXPAND_STORE, MIN_SIDE_PX), cx, cy),
                (ct_ctx, pet_ctx, boxes_ctx, side_ctx, cx, cy),
                (ct_whole, pet_whole, boxes_whole, side_whole, W / 2.0, H / 2.0),
                (ct_medi, pet_medi, boxes_medi, side_medi, W / 2.0, H / 2.0)):
            store_arr[k] = np.round(_crop_resize(ct_np, ccx, ccy, side, STORE, -1000.0)).astype(np.int16)
            if rec.has_pet:
                pet_arr[k] = _crop_resize(pet_np, ccx, ccy, side, STORE, 0.0).astype(np.float16)
            sc = STORE / side; ox, oy = ccx - side / 2.0, ccy - side / 2.0
            box_arr[k] = [(x0 - ox) * sc, (y0 - oy) * sc, (x1 - ox) * sc, (y1 - oy) * sc]
    rec.ct = ct_store; rec.pet = pet_store; rec.boxes = boxes
    rec.ct_ctx = ct_ctx; rec.pet_ctx = pet_ctx; rec.boxes_ctx = boxes_ctx
    rec.ct_whole = ct_whole; rec.pet_whole = pet_whole; rec.boxes_whole = boxes_whole
    rec.ct_medi = ct_medi; rec.pet_medi = pet_medi; rec.boxes_medi = boxes_medi
    rec.annotated = annotated; rec.n_slices = n
    pos = [s["pos"] for k, s in enumerate(slices) if annotated[k]]
    extent = (max(pos) - min(pos)) if len(pos) > 1 else 0.0
    extent += float(meta.get("ct_effective_dz", 5.0))
    rec.geom = np.array([math.log(max(diam_mm) if diam_mm else 30.0), math.log(extent), math.log(max(area_cm2) if area_cm2 else 5.0)], dtype=np.float32)
    rec.meta = {"ct_desc": meta.get("ct_desc", ""), "ct_dz": meta.get("ct_dz", meta.get("ct_dz_native")), "candidate_mode": meta.get("candidate_mode"),
                "pet_mode": rec.pet_mode, "suv_mode": meta.get("pet", {}).get("suv_mode", "")}
    return rec


def load_cohort(pids=None, cache_dir=CACHE, verbose=True):
    cache_dir = Path(cache_dir)
    if pids is None:
        pids = sorted(p.name for p in cache_dir.iterdir() if (p / "meta.json").exists())
    series_info = {}
    ss = IDX / "series_summary.csv"
    if ss.exists():
        df = pd.read_csv(ss, dtype=str, keep_default_na=False)
        series_info = dict(zip(df["series_uid"], df["manufacturer"]))
    recs = []
    for i, pid in enumerate(pids):
        try:
            recs.append(load_patient(pid, cache_dir, series_info))
        except Exception as exc:
            print(f"  ! failed to load {pid}: {exc!r}")
        if verbose and (i + 1) % 50 == 0:
            print(f"  loaded {i + 1}/{len(pids)} patients", flush=True)
    return recs


VIEWS = {"detail": ["detail"], "context": ["context"], "both": ["detail", "context"], "whole": ["whole"],
         "ctx_whole": ["context", "whole"], "all": ["detail", "context", "whole"],
         "medi": ["medi"], "ctx_medi": ["context", "medi"], "all4": ["detail", "context", "whole", "medi"]}
WHOLE_EVAL_REL = 1.0
WHOLE_TRAIN_REL = (0.85, 1.0)
MEDI_STORE_MM = 150.0   # central (mediastinal / hilar) field of view, image-centred, not lesion-centred


def _view_rels(view, train, rng):
    """Crop size (relative to the stored window) and jitter for a view."""
    if view == "detail":
        lo, hi, ev = TRAIN_REL[0], TRAIN_REL[1], EVAL_REL
    elif view == "context":
        lo, hi, ev = CTX_TRAIN_REL[0], CTX_TRAIN_REL[1], CTX_EVAL_REL
    else:
        lo, hi, ev = WHOLE_TRAIN_REL[0], WHOLE_TRAIN_REL[1], WHOLE_EVAL_REL
    if not train:
        return ev, 0.0, 0.0
    rel = rng.uniform(lo, hi); jit = (0.08 if view != "whole" else 0.04) * rel * STORE
    return rel, rng.uniform(-jit, jit), rng.uniform(-jit, jit)


class BagDataset(torch.utils.data.Dataset):
    def __init__(self, records, bag_size=8, train=True, use_pet=True, modality_dropout=0.25,
                 eval_max_slices=48, seed=0, pet_shift_px=0.0, view="detail"):
        self.recs = records; self.K = bag_size; self.train = train; self.use_pet = use_pet
        self.mdrop = modality_dropout; self.eval_max = eval_max_slices
        self.rng = random.Random(seed); self.pet_shift_px = pet_shift_px
        self.views = VIEWS[view]

    def __len__(self):
        return len(self.recs)

    def _pick(self, n):
        if self.train:
            if n >= self.K:
                return self.rng.sample(range(n), self.K)
            return [self.rng.randrange(n) for _ in range(self.K)]
        if n <= self.eval_max:
            return list(range(n))
        return [int(round(t)) for t in np.linspace(0, n - 1, self.eval_max)]

    def _one_view(self, rec, k, view, rel, dx, dy, angle, flip, gamma, pet_gain):
        if view == "detail":
            ct_src, pet_src, bx = rec.ct[k], (rec.pet[k] if rec.pet is not None else None), rec.boxes[k]
            cx, cy = (bx[0] + bx[2]) / 2.0, (bx[1] + bx[3]) / 2.0
        elif view == "context":
            ct_src, pet_src, bx = rec.ct_ctx[k], (rec.pet_ctx[k] if rec.pet_ctx is not None else None), rec.boxes_ctx[k]
            cx, cy = (bx[0] + bx[2]) / 2.0, (bx[1] + bx[3]) / 2.0
        elif view == "whole":   # whole slice: window is centred on the image centre, not on the lesion
            ct_src, pet_src, bx = rec.ct_whole[k], (rec.pet_whole[k] if rec.pet_whole is not None else None), rec.boxes_whole[k]
            cx, cy = STORE / 2.0, STORE / 2.0
        else:                   # medi: central 150 mm field of view (mediastinum / hila)
            ct_src, pet_src, bx = rec.ct_medi[k], (rec.pet_medi[k] if rec.pet_medi is not None else None), rec.boxes_medi[k]
            cx, cy = STORE / 2.0, STORE / 2.0
        ct = ct_src.astype(np.float32)
        side = rel * STORE
        cx = cx + dx; cy = cy + dy
        ct_c = _crop_resize(ct, cx, cy, side, IMG, -1000.0)
        pet_c = None
        if self.use_pet and rec.has_pet and pet_src is not None:
            # pet_shift_px is a fraction of the crop side (misalignment robustness experiments)
            pet_c = _crop_resize(pet_src.astype(np.float32), cx + self.pet_shift_px * side, cy, side, IMG, 0.0)
        if angle != 0.0:
            M = cv2.getRotationMatrix2D((IMG / 2.0, IMG / 2.0), angle, 1.0)
            ct_c = cv2.warpAffine(ct_c, M, (IMG, IMG), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT, borderValue=-1000.0)
            if pet_c is not None:
                pet_c = cv2.warpAffine(pet_c, M, (IMG, IMG), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT, borderValue=0.0)
        if flip:
            ct_c = ct_c[:, ::-1]
            if pet_c is not None:
                pet_c = pet_c[:, ::-1]
        ch_ct = np.stack([_window(ct_c, *LUNG_WIN), _window(ct_c, *MED_WIN)])
        if gamma != 1.0:
            ch_ct = np.power(ch_ct, gamma)
        if pet_c is not None:
            pet_c = np.maximum(pet_c * pet_gain, 0.0)
            ch_pt = np.stack([np.clip(pet_c / s, 0.0, 1.0) for s in SUV_SCALES])
        else:
            ch_pt = np.zeros((len(SUV_SCALES), IMG, IMG), dtype=np.float32)
        return np.ascontiguousarray(ch_ct, dtype=np.float32), np.ascontiguousarray(ch_pt, dtype=np.float32)

    def __getitem__(self, i):
        rec = self.recs[i]
        ks = self._pick(rec.n_slices)
        cts, pts = [], []
        pet_present = bool(self.use_pet and rec.has_pet)
        if self.train and pet_present and self.rng.random() < self.mdrop:
            pet_present = False
        for k in ks:
            if self.train:
                angle = self.rng.uniform(-10, 10) if self.rng.random() < 0.6 else 0.0
                flip = self.rng.random() < 0.5
                gamma = self.rng.uniform(0.85, 1.15) if self.rng.random() < 0.3 else 1.0
                pet_gain = self.rng.uniform(0.85, 1.15) if self.rng.random() < 0.3 else 1.0
            else:
                angle, flip, gamma, pet_gain = 0.0, False, 1.0, 1.0
            vc, vp = [], []
            for view in self.views:
                rel, dx, dy = _view_rels(view, self.train, self.rng)
                c, p = self._one_view(rec, k, view, rel, dx, dy, angle, flip, gamma, pet_gain)
                vc.append(c); vp.append(p)
            cts.append(np.stack(vc)); pts.append(np.stack(vp))
        ct = torch.from_numpy(np.stack(cts)); pt = torch.from_numpy(np.stack(pts))      # (K, V, 2, H, W)
        if not pet_present:
            pt.zero_()
        return ct, pt, torch.tensor(pet_present), torch.tensor(float(rec.label)), rec.pid, torch.tensor(ks), torch.from_numpy(rec.geom)


def collate_bags(batch):
    """Pads bags to a common size and returns a slice mask."""
    K = max(b[0].shape[0] for b in batch)
    B = len(batch)
    ct = torch.zeros((B, K) + batch[0][0].shape[1:]); pt = torch.zeros((B, K) + batch[0][1].shape[1:])
    mask = torch.zeros(B, K, dtype=torch.bool)
    pet_mask = torch.zeros(B, dtype=torch.bool); y = torch.zeros(B); pids = []; idxs = []; geom = torch.zeros(B, GEOM_DIM)
    for i, (c, p, pm, yy, pid, ks, g) in enumerate(batch):
        n = c.shape[0]; ct[i, :n] = c; pt[i, :n] = p; mask[i, :n] = True; pet_mask[i] = pm; y[i] = yy; geom[i] = g
        pids.append(pid); idxs.append(ks)
    return ct, pt, pet_mask, mask, y, pids, idxs, geom


# =============================================================================== model
class Encoder(nn.Module):
    def __init__(self, backbone, in_chans, pretrained=True, drop_path=0.1):
        super().__init__()
        self.net = timm.create_model(backbone, pretrained=pretrained, in_chans=in_chans, num_classes=0,
                                     global_pool="", drop_path_rate=drop_path)
        self.out_dim = self.net.num_features

    def forward(self, x):                       # (N, C, H, W) -> tokens (N, T, D)
        f = self.net.forward_features(x)
        return f.flatten(2).transpose(1, 2)


class CrossModalBlock(nn.Module):
    """Queries from modality a attend to keys/values of modality b (multi-head), residual + MLP."""
    def __init__(self, d, heads=8, drop=0.1):
        super().__init__()
        self.ln_q = nn.LayerNorm(d); self.ln_kv = nn.LayerNorm(d); self.ln_m = nn.LayerNorm(d)
        self.attn = nn.MultiheadAttention(d, heads, dropout=drop, batch_first=True)
        self.mlp = nn.Sequential(nn.Linear(d, 2 * d), nn.GELU(), nn.Dropout(drop), nn.Linear(2 * d, d))
        self.drop = nn.Dropout(drop)

    def forward(self, a, b, need_weights=False):
        q = self.ln_q(a); kv = self.ln_kv(b)
        out, w = self.attn(q, kv, kv, need_weights=need_weights, average_attn_weights=True)
        a = a + self.drop(out)
        a = a + self.drop(self.mlp(self.ln_m(a)))
        return a, w


class GatedAttention(nn.Module):
    """Attention-gated MIL pooling (Ilse et al. 2018)."""
    def __init__(self, d, hidden=128, drop=0.1):
        super().__init__()
        self.V = nn.Linear(d, hidden); self.U = nn.Linear(d, hidden); self.w = nn.Linear(hidden, 1)
        self.drop = nn.Dropout(drop)

    def forward(self, h, mask):                 # h (B, K, D), mask (B, K)
        a = self.w(self.drop(torch.tanh(self.V(h)) * torch.sigmoid(self.U(h)))).squeeze(-1)
        a = a.masked_fill(~mask, float("-inf"))
        a = torch.softmax(a, dim=1)
        return torch.sum(h * a.unsqueeze(-1), dim=1), a


class MILFusionNet(nn.Module):
    """
    fusion:
      'xattn'    dual EfficientNet encoders + bidirectional multi-head cross-attention + gated MIL (proposed)
      'concat'   dual encoders, pooled features concatenated (no cross-attention)
      'ct_only'  CT encoder only
      'pet_only' PET encoder only
      'early'    single encoder on channel-stacked CT windows + PET (pixel-level fusion)
    views: number of image views per slice (1 = detail or context, 2 = both); encoders are shared across views.
    use_geom: append a small embedding of lesion-geometry descriptors (log diameter, extent, area) to the bag vector.
    """
    def __init__(self, backbone="tf_efficientnet_b0.ns_jft_in1k", fusion="xattn", d=256, heads=8, drop=0.2,
                 pretrained=True, n_pet_ch=2, views=1, use_geom=False, drop_path=0.1):
        super().__init__()
        self.fusion = fusion; self.d = d; self.views = views; self.use_geom = use_geom
        if fusion == "early":
            self.enc = Encoder(backbone, 2 + n_pet_ch, pretrained, drop_path)
            self.proj = nn.Linear(self.enc.out_dim, d)
            emb = d
        else:
            if fusion != "pet_only":
                self.enc_ct = Encoder(backbone, 2, pretrained, drop_path); self.proj_ct = nn.Linear(self.enc_ct.out_dim, d)
            if fusion != "ct_only":
                self.enc_pt = Encoder(backbone, n_pet_ch, pretrained, drop_path); self.proj_pt = nn.Linear(self.enc_pt.out_dim, d)
            if fusion == "xattn":
                self.x_ct = CrossModalBlock(d, heads, drop * 0.5); self.x_pt = CrossModalBlock(d, heads, drop * 0.5)
            self.missing_pt = nn.Parameter(torch.zeros(d))
            emb = d if fusion in ("ct_only", "pet_only") else 2 * d
        emb = emb * views
        self.mil = GatedAttention(emb, 128, drop * 0.5)
        head_in = emb
        if use_geom:
            self.geom_mlp = nn.Sequential(nn.Linear(GEOM_DIM, 32), nn.GELU(), nn.Dropout(drop * 0.5))
            head_in = emb + 32
        self.head = nn.Sequential(nn.LayerNorm(head_in), nn.Dropout(drop), nn.Linear(head_in, 1))

    def slice_embeddings(self, ct, pt, pet_mask, return_attn=False):
        B, K, V = ct.shape[:3]
        N = B * K * V
        xattn_w = None
        if self.fusion == "early":
            x = torch.cat([ct, pt], dim=3).flatten(0, 2)
            z = self.proj(self.enc(x)).mean(1)
            return z.view(B, K, -1), None
        pm = pet_mask.repeat_interleave(K * V).unsqueeze(-1)            # (N, 1)
        if self.fusion == "pet_only":
            z = self.proj_pt(self.enc_pt(pt.flatten(0, 2))).mean(1)
            return z.view(B, K, -1), None
        t_ct = self.proj_ct(self.enc_ct(ct.flatten(0, 2)))             # (N, T, d)
        z_ct_self = t_ct.mean(1)
        if self.fusion == "ct_only":
            return z_ct_self.view(B, K, -1), None
        t_pt = self.proj_pt(self.enc_pt(pt.flatten(0, 2)))
        z_pt_self = t_pt.mean(1)
        if self.fusion == "xattn":
            a_ct, w_ct = self.x_ct(t_ct, t_pt, need_weights=return_attn)
            a_pt, w_pt = self.x_pt(t_pt, t_ct, need_weights=return_attn)
            z_ct = torch.where(pm, a_ct.mean(1), z_ct_self)
            z_pt = torch.where(pm, a_pt.mean(1), self.missing_pt.expand_as(z_pt_self))
            xattn_w = (w_ct, w_pt) if return_attn else None
        else:   # concat
            z_ct = z_ct_self
            z_pt = torch.where(pm, z_pt_self, self.missing_pt.expand_as(z_pt_self))
        z = torch.cat([z_ct.view(B * K, V * self.d), z_pt.view(B * K, V * self.d)], dim=1)
        return z.view(B, K, -1), xattn_w

    def forward(self, ct, pt, pet_mask, slice_mask, geom=None, return_attn=False):
        h, xw = self.slice_embeddings(ct, pt, pet_mask, return_attn)
        bag, a = self.mil(h, slice_mask)
        if self.use_geom:
            bag = torch.cat([bag, self.geom_mlp(geom.to(bag.dtype))], dim=1)
        logit = self.head(bag).squeeze(-1)
        return logit, a, xw


# =============================================================================== losses
class WeightedFocalLoss(nn.Module):
    """Binary focal loss with class weighting (alpha for the positive = SCLC class)."""
    def __init__(self, alpha_pos=0.6, gamma=2.0, label_smoothing=0.0):
        super().__init__()
        self.alpha = alpha_pos; self.gamma = gamma; self.ls = label_smoothing

    def forward(self, logit, y):
        y_s = y * (1 - self.ls) + 0.5 * self.ls
        bce = F.binary_cross_entropy_with_logits(logit, y_s, reduction="none")
        p = torch.sigmoid(logit)
        p_t = p * y + (1 - p) * (1 - y)
        alpha_t = self.alpha * y + (1 - self.alpha) * (1 - y)
        return (alpha_t * (1 - p_t).pow(self.gamma) * bce).mean()


class WeightedBCE(nn.Module):
    def __init__(self, pos_weight=1.0, label_smoothing=0.0):
        super().__init__()
        self.register_buffer("pw", torch.tensor(float(pos_weight))); self.ls = label_smoothing

    def forward(self, logit, y):
        y_s = y * (1 - self.ls) + 0.5 * self.ls
        return F.binary_cross_entropy_with_logits(logit, y_s, pos_weight=self.pw)


# =============================================================================== calibration / thresholds
def fit_temperature(logits, labels):
    """Temperature scaling by minimising NLL on held-out logits."""
    z = torch.tensor(np.asarray(logits), dtype=torch.float64); y = torch.tensor(np.asarray(labels), dtype=torch.float64)
    log_t = torch.zeros(1, dtype=torch.float64, requires_grad=True)
    opt = torch.optim.LBFGS([log_t], lr=0.1, max_iter=200)

    def closure():
        opt.zero_grad()
        loss = F.binary_cross_entropy_with_logits(z / torch.exp(log_t), y)
        loss.backward()
        return loss
    opt.step(closure)
    T = float(torch.exp(log_t).item())
    return float(np.clip(T, 0.05, 20.0))


def select_thresholds(probs, labels, target_sens=0.80):
    probs = np.asarray(probs, float); labels = np.asarray(labels, int)
    cands = np.unique(np.concatenate([[0.0, 1.0], probs]))
    best = {"youden": (-9, 0.5), "f1": (-9, 0.5)}
    sens_ok = []
    for t in cands:
        pred = probs >= t
        tp = int(((pred == 1) & (labels == 1)).sum()); fn = int(((pred == 0) & (labels == 1)).sum())
        fp = int(((pred == 1) & (labels == 0)).sum()); tn = int(((pred == 0) & (labels == 0)).sum())
        sens = tp / max(tp + fn, 1); spec = tn / max(tn + fp, 1)
        j = sens + spec - 1
        f1 = 2 * tp / max(2 * tp + fp + fn, 1)
        if j > best["youden"][0] + 1e-12:
            best["youden"] = (j, float(t))
        if f1 > best["f1"][0] + 1e-12:
            best["f1"] = (f1, float(t))
        if sens >= target_sens:
            sens_ok.append((spec, float(t)))
    t_sens = max(sens_ok)[1] if sens_ok else 0.0   # highest specificity among thresholds meeting the sensitivity target
    return {"youden": best["youden"][1], "f1max": best["f1"][1], f"sens{int(target_sens * 100)}": t_sens}


# =============================================================================== prediction
@torch.no_grad()
def predict(model, records, device, use_pet=True, bag_size_eval=48, tta_flip=True, amp_dtype=torch.bfloat16,
            pet_shift_px=0.0, return_attention=False, view="detail", batch=4):
    model.eval()
    ds = BagDataset(records, train=False, use_pet=use_pet, eval_max_slices=bag_size_eval, pet_shift_px=pet_shift_px, view=view)
    out = []
    dl = torch.utils.data.DataLoader(ds, batch_size=batch, shuffle=False, num_workers=0, collate_fn=collate_bags)
    for ct, pt, pm, mask, y, pids, idxs, geom in dl:
        ct = ct.to(device, non_blocking=True); pt = pt.to(device, non_blocking=True)
        pm = pm.to(device); mask = mask.to(device); geom = geom.to(device)
        with torch.autocast("cuda", dtype=amp_dtype, enabled=device.type == "cuda"):
            logit, a, _ = model(ct, pt, pm, mask, geom)
            logits = [logit.float()]
            if tta_flip:
                l2, _, _ = model(torch.flip(ct, dims=[-1]), torch.flip(pt, dims=[-1]), pm, mask, geom)
                logits.append(l2.float())
        lg = torch.stack(logits).mean(0).cpu().numpy()
        for i, pid in enumerate(pids):
            n = int(mask[i].sum().item())
            rec = {"pid": pid, "label": int(y[i].item()), "logit": float(lg[i]), "pet_used": bool(pm[i].item()), "n_slices_eval": n}
            if return_attention:
                rec["attention"] = a[i, :n].float().cpu().numpy().tolist(); rec["slice_idx"] = idxs[i].tolist()
            out.append(rec)
    return out
