"""
Step 8: TRIPOD-style participant table (baseline characteristics by class) and a sample-size / precision note.

Outputs docs/cohort_table.csv, docs/cohort_table.md, docs/sample_size_note.md
"""
from pathlib import Path
import numpy as np
import pandas as pd
from scipy import stats

HERE = Path(__file__).resolve().parent
DOCS = HERE / "docs"; DOCS.mkdir(exist_ok=True)

clin = pd.read_excel(HERE / "index" / "statistics-clinical-20201221.xlsx")
clin.columns = [str(c).strip() for c in clin.columns]
clin = clin.rename(columns={"NewPatientID": "pid", "weight (kg)": "weight_kg", "T-Stage": "T", "N-Stage": "N",
                            "Ｍ-Stage": "M", "M-Stage": "M", "Histopathological grading": "grade", "Smoking History": "smoking"})
cache = pd.read_csv(HERE / "index" / "cache_summary.csv")
df = cache.merge(clin, on="pid", how="left")
df["class"] = np.where(df["label"] == 1, "SCLC", "NSCLC")
df["T_major"] = df["T"].astype(str).str.extract(r"(\d)")[0]
df["N_any"] = pd.to_numeric(df["N"].astype(str).str.extract(r"(\d)")[0], errors="coerce")
df["M_any"] = pd.to_numeric(df["M"].astype(str).str.extract(r"(\d)")[0], errors="coerce")
df["Age"] = pd.to_numeric(df["Age"], errors="coerce"); df["weight_kg"] = pd.to_numeric(df["weight_kg"], errors="coerce")
df["smoking"] = pd.to_numeric(df["smoking"], errors="coerce")


def cont_row(name, col):
    a = df.loc[df["class"] == "NSCLC", col].dropna(); b = df.loc[df["class"] == "SCLC", col].dropna()
    p = stats.mannwhitneyu(a, b).pvalue if len(a) and len(b) else np.nan
    f = lambda s: f"{s.median():.0f} ({s.quantile(.25):.0f}-{s.quantile(.75):.0f}); n={len(s)}"
    return {"characteristic": name, "all": f(df[col].dropna()), "NSCLC": f(a), "SCLC": f(b), "p": p, "test": "Mann-Whitney U"}


def cat_row(name, col, levels=None):
    rows = []
    sub = df[[col, "class"]].dropna()
    ct = pd.crosstab(sub[col], sub["class"])
    if levels is not None:
        ct = ct.reindex(levels).fillna(0)
    try:
        p = stats.chi2_contingency(ct)[1] if ct.shape[0] > 1 else np.nan
        if ct.shape == (2, 2):
            p = stats.fisher_exact(ct)[1]
    except Exception:
        p = np.nan
    for lvl, r in ct.iterrows():
        n_all = int(r.sum()); n0 = int(r.get("NSCLC", 0)); n1 = int(r.get("SCLC", 0))
        rows.append({"characteristic": f"{name}: {lvl}", "all": f"{n_all} ({100 * n_all / len(sub):.0f}%)",
                     "NSCLC": f"{n0} ({100 * n0 / max((sub['class'] == 'NSCLC').sum(), 1):.0f}%)",
                     "SCLC": f"{n1} ({100 * n1 / max((sub['class'] == 'SCLC').sum(), 1):.0f}%)",
                     "p": p if lvl == ct.index[0] else "", "test": ("Fisher" if ct.shape == (2, 2) else "chi-square") if lvl == ct.index[0] else ""})
    return rows


rows = [{"characteristic": "Patients, n", "all": len(df), "NSCLC": int((df["class"] == "NSCLC").sum()), "SCLC": int((df["class"] == "SCLC").sum()), "p": "", "test": ""}]
rows += cat_row("Histology", "group", ["A", "G", "E", "B"])
rows.append(cont_row("Age, years (median, IQR)", "Age"))
rows += cat_row("Sex", "Sex")
rows.append(cont_row("Weight, kg (median, IQR)", "weight_kg"))
rows += cat_row("Smoking history", "smoking")
rows += cat_row("T stage (major)", "T_major")
rows += cat_row("Nodal stage N>0", "N_any")
rows += cat_row("Distant metastasis M>0", "M_any")
rows += cat_row("Histopathological grade", "grade")
rows += cat_row("PET available", "has_pet")
rows += cat_row("CT manufacturer", "ct_manufacturer")
rows += cat_row("Effective CT slice thickness (mm)", df["dz_effective"].round(0).astype(int).rename("dz_round")) if False else []
df["dz_round"] = df["dz_effective"].round(0).astype(int)
rows += cat_row("Effective CT slice thickness, mm", "dz_round")
rows.append(cont_row("Annotated tumour slices per patient (median, IQR)", "n_ann_patient"))
rows.append(cont_row("Candidate slices in bag (median, IQR)", "n_cand"))
tab = pd.DataFrame(rows)
tab["p"] = tab["p"].apply(lambda v: f"{v:.3f}" if isinstance(v, (float, np.floating)) and not np.isnan(v) else ("<0.001" if isinstance(v, (float, np.floating)) else v))
tab.to_csv(DOCS / "cohort_table.csv", index=False)
with open(DOCS / "cohort_table.md", "w", encoding="utf-8") as f:
    f.write("| Characteristic | All (n=355) | NSCLC | SCLC | p | test |\n|---|---|---|---|---|---|\n")
    for _, r in tab.iterrows():
        f.write(f"| {r['characteristic']} | {r['all']} | {r['NSCLC']} | {r['SCLC']} | {r['p']} | {r['test']} |\n")
print(tab.to_string(index=False))

# ---- sample size / precision note (Hanley & McNeil SE of AUC; events-per-variable style statement)
n1 = int((df["class"] == "SCLC").sum()); n0 = int((df["class"] == "NSCLC").sum())
def hm_se(auc, n1, n0):
    q1 = auc / (2 - auc); q2 = 2 * auc ** 2 / (1 + auc)
    return np.sqrt((auc * (1 - auc) + (n1 - 1) * (q1 - auc ** 2) + (n0 - 1) * (q2 - auc ** 2)) / (n1 * n0))
lines = ["# Sample-size / precision note (for TRIPOD item 'sample size')", "",
         f"The analysis used all {n0 + n1} eligible patients of Lung-PET-CT-Dx ({n1} SCLC, {n0} NSCLC); no new data could be collected, "
         "so the sample size was fixed by data availability and we report the precision it affords instead of an a-priori calculation.", ""]
for auc in (0.70, 0.75, 0.80, 0.85, 0.90):
    se = hm_se(auc, n1, n0)
    lines.append(f"- Expected AUC {auc:.2f}: Hanley-McNeil SE = {se:.3f}, 95% CI half-width about +/-{1.96 * se:.3f} (whole cohort, {n1} events).")
se_pet = hm_se(0.80, 9, 124)
lines += ["", f"- Paired CT+PET subset (9 SCLC vs 124 NSCLC): at AUC 0.80 the SE is {se_pet:.3f} (95% CI half-width about +/-{1.96 * se_pet:.2f}); "
          "estimates on this subset are therefore reported as exploratory.",
          f"- Sensitivity with {n1} SCLC patients: observing 30/38 (79%) gives a Wilson 95% CI of about 63-89%; each additional detected case moves the estimate by 2.6 points.",
          "- With 38 events, a conventional events-per-candidate-predictor heuristic (>=10 EPV) would allow at most 3-4 free predictors in a regression model; "
          "the deep model is therefore trained with strong priors (ImageNet initialisation, weight decay, early stopping, modality dropout) and evaluated only out-of-fold."]
with open(DOCS / "sample_size_note.md", "w", encoding="utf-8") as f:
    f.write("\n".join(lines))
print("\n".join(lines))
