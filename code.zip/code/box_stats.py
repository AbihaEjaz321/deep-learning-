"""How informative are simple lesion-geometry descriptors derived from the radiologist boxes (size, extent, centrality)?
Reports per-descriptor AUC for SCLC vs NSCLC - used only to guide the choice of crop field of view."""
import json
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.metrics import roc_auc_score

HERE = Path(__file__).resolve().parent
rows = []
for mp in sorted((HERE / "cache").glob("*/meta.json")):
    m = json.load(open(mp, encoding="utf-8"))
    ps = float(m["ct_spacing_row_col"][0]); H, W = m["ct_shape"]
    boxes = [(s["pos"], b) for s in m["slices"] for b in s["boxes"]]
    if not boxes:
        continue
    diam = [max(b[2] - b[0], b[3] - b[1]) * ps for _, b in boxes]
    area = [(b[2] - b[0]) * (b[3] - b[1]) * ps * ps for _, b in boxes]
    cx = [((b[0] + b[2]) / 2 - W / 2) * ps for _, b in boxes]; cy = [((b[1] + b[3]) / 2 - H / 2) * ps for _, b in boxes]
    zs = sorted({p for p, _ in boxes})
    # craniocaudal extent of annotated slices in the whole patient (all series) ~ n_annotated_patient * native dz is not available; use series extent
    extent = (max(zs) - min(zs)) if len(zs) > 1 else m["ct_effective_dz"]
    rows.append({"pid": m["pid"], "label": m["label"], "has_pet": m["has_pet"], "max_diam_mm": max(diam), "median_diam_mm": float(np.median(diam)),
                 "max_area_cm2": max(area) / 100, "cc_extent_mm": extent, "n_ann_patient": m["n_annotated_slices_patient"],
                 "abs_cx_mm": float(np.median(np.abs(cx))), "cy_mm": float(np.median(cy)), "ps": ps,
                 "dist_center_mm": float(np.median(np.hypot(cx, cy))), "max_suv": m.get("pet_max_suv_in_candidates", np.nan)})
df = pd.DataFrame(rows)
df.to_csv(HERE / "index" / "box_stats.csv", index=False)
print(df.groupby("label")[["max_diam_mm", "max_area_cm2", "cc_extent_mm", "n_ann_patient", "abs_cx_mm", "dist_center_mm", "max_suv"]].median().round(1))
print("\nunivariate AUC (SCLC vs NSCLC):")
for c in ["max_diam_mm", "median_diam_mm", "max_area_cm2", "cc_extent_mm", "n_ann_patient", "abs_cx_mm", "dist_center_mm", "max_suv"]:
    d = df.dropna(subset=[c])
    auc = roc_auc_score(d["label"], d[c])
    print(f"  {c:16s} AUC={max(auc, 1 - auc):.3f} ({'higher' if auc >= 0.5 else 'lower'} in SCLC)  n={len(d)}")
print("\nbox diameter percentiles (mm): ", np.percentile(df["max_diam_mm"], [5, 25, 50, 75, 95]).round(0))
print("pixel spacing: ", df["ps"].describe().round(3).to_dict())
